# KẾ HOẠCH NÂNG CẤP TOÀN DIỆN RUSTATIO ANDROID: BACKEND CLIENT ENGINE & SOFT NEUMORPHISM 2.0

## I. MỤC TIÊU DỰ ÁN
1. **Khắc phục triệt để luồng xử lý Backend Client/Version/OS/Port**:
   - Đảm bảo khi người dùng thay đổi Phần mềm tải (Client: qBittorrent, uTorrent, Transmission, Deluge, BitTorrent, rTorrent), Phiên bản (Version), Hệ điều hành (Windows 7, 10, 12), hoặc Cổng kết nối (Port) trong Cài đặt:
     - Tái tạo lập tức tiền tố Peer-ID chuẩn xác theo từng Client (`-qB...-`, `-UT...-`, `-TR...-`, `-DE...-`, `-BT...-`, `-RT...-`) kèm 12 ký tự ngẫu nhiên.
     - Cập nhật tức thì chuỗi `User-Agent` và HTTP Header phụ `X-Client-OS`.
     - Cập nhật cổng kết nối trong `ClientConfig`, lưu trữ vào cơ sở dữ liệu Room, và đổi cổng lắng nghe TCP trong `PeerListenerService`.
     - Tự động kích hoạt gói tin báo cáo Announce mới tới máy chủ Tracker đối với tất cả các torrent đang chạy, đảm bảo Tracker nhận diện chính xác 100% Client và OS mới thay vì bị kẹt ở Transmission 4.1.4 mặc định.
2. **Nâng cấp Hệ thống Thiết kế Premium Soft Neumorphism 2.0 (Unified Light & Dark Experience)**:
   - Áp dụng triệt để bộ màu Soft Pastel Mint cho Light Mode (`#F1F5F2`, `#F9FBF9`, `#35B889`) và Deep Emerald cho Dark Mode (`#171D1B`, `#202925`, `#42C99A`).
   - Xây dựng thư viện Neumorphic Components dùng chung (Cards, Buttons, Inputs, Selection Grid, Accordion Expandable Section).
   - Thiết kế Accordion thu gọn/mở rộng cho mục "Cấu hình chung" tại màn hình Cài đặt; loại bỏ hoàn toàn cuộn ngang (horizontal scroll), thay thế bằng Responsive Grid tự xuống dòng.
   - Tối ưu hóa mật độ hiển thị màn hình Torrent, hiển thị tối đa số lượng torrent trên màn hình điện thoại với số liệu trực quan, rõ ràng.

---

## II. CHI TIẾT CÁC BƯỚC TRIỂN KHAI

### BƯỚC 1: SỬA LÕI BACKEND & CƠ CHẾ CẬP NHẬT TRACKER TỨC THÌ
- **Tập tin**: `core/faker/RatioFaker.kt`, `data/repository/RustatioRepository.kt`, `core/torrent/ClientConfig.kt`
- **Nội dung thực hiện**:
  1. Trong `RatioFakerSession.updateConfiguration()`:
     - Cập nhật lại toàn diện `clientConfig` dựa trên Client, Version, OS và Port mới.
     - Tái tạo `peerId` với tiền tố Client chính xác của từng ứng dụng:
       - qBittorrent: `-qB[ver]-`
       - uTorrent: `-UT[ver]-`
       - Transmission: `-TR[ver]-`
       - Deluge: `-DE[ver]-`
       - BitTorrent: `-BT[ver]-`
       - rTorrent: `-RT[ver]-`
     - Cập nhật `keyHex`, `userAgent`, và `osHeader`.
     - Bổ sung hàm `forceReannounce(event: TrackerEvent)`: nếu phiên đang ở trạng thái `RUNNING` hoặc `STARTING`, lập tức gửi bản tin Announce cập nhật tới Tracker với `peer_id`, `port`, `user-agent` và `X-Client-OS` mới.
  2. Trong `RustatioRepository.updateGlobalConfig()`:
     - Lưu cấu hình chung mới vào `app_preferences` và cập nhật cấu hình của tất cả các phiên torrent trong `activeSessions` lẫn cơ sở dữ liệu `torrents`.
     - Cập nhật cổng lắng nghe `peerListener.ensureListening(validPort)`.
     - Kích hoạt gửi lại Announce đồng loạt cho tất cả các torrent đang chạy để đồng bộ ngay lập tức với Tracker.

### BƯỚC 2: XÂY DỰNG DESIGN TOKENS & THƯ VIỆN SOFT NEUMORPHISM 2.0
- **Tập tin**: `ui/theme/Color.kt`, `ui/theme/Theme.kt`, `ui/components/NeumorphicComponents.kt`
- **Nội dung thực hiện**:
  1. Cập nhật `Color.kt` theo đúng bảng màu Design System:
     - **Light Mode**: Nền `#F1F5F2`, Bề mặt `#F9FBF9`, Bề mặt phụ `#E9F0EB`, Primary `#35B889`, Primary Dark `#168C67`, Accent Mint `#D8F2E7`, Text Primary `#26352F`, Text Secondary `#74827A`, Divider `#DCE6DF`.
     - **Dark Mode**: Nền `#171D1B`, Bề mặt `#202925`, Bề mặt phụ `#252F2A`, Primary `#42C99A`, Primary Dark `#209B73`, Accent Mint `#244B3D`, Text Primary `#E5EEE8`, Text Secondary `#9BAAA1`, Divider `#344039`.
  2. Tạo bộ component Neumorphic dùng chung:
     - `NeumorphicCard`: Card với viền nhẹ và bóng đổ đa tầng dịu mắt (soft shadow).
     - `NeumorphicButton`: Nút chính và phụ có độ nổi mềm, phản hồi nhấn xúc giác lõm nhẹ (convex/concave).
     - `NeumorphicIconButton`: Nút biểu tượng bo tròn mềm mại.
     - `NeumorphicInput`: Trường nhập văn bản chìm nhẹ tạo chiều sâu thanh thoát.
     - `SelectionGrid`: Lưới chọn tự co giãn và xuống dòng linh hoạt (không bao giờ cuộn ngang).
     - `ExpandableSection`: Khối Accordion có animation đóng/mở mượt mà.

### BƯỚC 3: MÀN HÌNH CÀI ĐẶT – ACCORDION CẤU HÌNH CHUNG RESPONSIVE
- **Tập tin**: `ui/screens/GlobalSettingsScreen.kt`
- **Nội dung thực hiện**:
  1. Xây dựng khu vực **Cấu hình chung** dạng Accordion:
     - Trạng thái mặc định: Thu gọn, hiển thị tóm tắt ngắn gọn cấu hình đang áp dụng (`Client Version · OS · Cổng Port · Preset`) kèm nút Mở rộng/Thu gọn rõ ràng.
     - Trạng thái mở rộng: Trải đều theo chiều dọc các phần:
       - **Client**: Lưới Responsive hiển thị 6 client (qBittorrent, uTorrent, Transmission, Deluge, BitTorrent, rTorrent).
       - **Version**: Lưới Responsive hiển thị danh sách phiên bản tương ứng của client đang chọn.
       - **Operating System**: Lựa chọn Windows 7, Windows 10, Windows 12 dạng lưới dọc responsive.
       - **Port**: Nhập cổng, kiểm tra hợp lệ 1-65535, tạo cổng ngẫu nhiên, lưu cấu hình.
       - **Preset**: Xem Preset đang áp dụng và nút truy cập màn hình Bộ cấu hình.
  2. Tích hợp chuyển đổi Dark Mode / Light Mode tức thì, đồng nhất trên toàn ứng dụng.

### BƯỚC 4: MÀN HÌNH TORRENT – MẬT ĐỘ THÔNG TIN CAO & THIẾT KẾ MỀM NỔI
- **Tập tin**: `ui/screens/TorrentListScreen.kt`, `ui/components/TorrentDetailSheet.kt`
- **Nội dung thực hiện**:
  1. Thẻ torrent mật độ cao:
     - Dòng 1: Chấm trạng thái tinh tế + Tên torrent (rút gọn ellipsis 1 dòng) + Nút `⋮` mở menu tác vụ.
     - Dòng 2: Ba chỉ số nổi bật với màu sắc chuyên biệt: `↑ [Upload]`, `↓ [Download]`, `⇅ [Speed]` cùng thông tin `[Seed/Leech]`.
     - Khoảng cách được tối ưu hóa cho màn hình điện thoại, hiển thị được nhiều torrent nhất có thể mà không bị rối mắt.
  2. Thanh công cụ gọn gàng: Các nút *Thêm torrent*, *Tìm kiếm*, *Chạy tất cả*, *Tạm dừng tất cả*, *Dừng tất cả* với phong cách Soft Neumorphic.
  3. Chi tiết torrent dạng Modal Bottom Sheet với các thông số kỹ thuật đầy đủ.

### BƯỚC 5: MÀN HÌNH BỘ CẤU HÌNH (PRESET MANAGEMENT)
- **Tập tin**: `ui/screens/PresetsSettingsScreen.kt`
- **Nội dung thực hiện**:
  - Áp dụng thẻ Neumorphic cho từng Preset.
  - Bộ lọc: *Tất cả*, *Có sẵn (4)*, *Tùy chỉnh*.
  - Các thao tác: *Áp dụng*, *Đặt mặc định*, *Sao chép/Nhân bản*, *Xuất JSON*, *Nhập JSON*, *Tạo mới*.
  - Mục Ghi chú kỹ thuật mặc định thu gọn, nhấn để mở rộng theo chiều dọc (không cuộn ngang).

### BƯỚC 6: CẬP NHẬT MAINACTIVITY & ĐIỀU HƯỚNG
- **Tập tin**: `MainActivity.kt`
- **Nội dung thực hiện**:
  - Top App Bar Soft Neumorphic hiển thị thương hiệu Rustatio, tốc độ tổng thể, tìm kiếm, nút nạp `.torrent` trực tiếp, và nút Cài đặt.
  - Thanh Bottom Navigation 3 tab: *Torrent*, *Bộ cấu hình*, *Cài đặt* đồng nhất ở cả 2 chế độ sáng và tối.
  - Xử lý `BackHandler` trở về tab Torrent khi nhấn nút Back hệ thống.

### BƯỚC 7: KIỂM THỬ TỰ ĐỘNG & BIÊN DỊCH TOÀN DIỆN (STAGE 4 & QA)
- **Tập tin**: `ExampleRobolectricTest.kt`
- **Nội dung thực hiện**:
  1. Thêm test case xác thực cơ chế Backend: khi cập nhật cấu hình chung sang qBittorrent, uTorrent, Deluge, rTorrent, BitTorrent:
     - Kiểm tra `peerId` bắt đầu đúng chuẩn tiền tố từng Client (`-qB...-`, `-UT...-`, v.v.).
     - Kiểm tra `userAgent` và `osHeader` thay đổi tương ứng.
     - Kiểm tra `port` và `peerListener` được đồng bộ.
  2. Chạy `compile_applet` và `gradle :app:testDebugUnitTest` đảm bảo 100% test case pass và ứng dụng biên dịch thành công.

---

## III. TIÊU CHÍ HOÀN THÀNH (DEFINITION OF DONE)
1. Backend phản hồi thực sự: Việc thay đổi Client/Version/OS/Port tác động trực tiếp tới các thông số kết nối Tracker thật, không còn hiện tượng kẹt ở Transmission 4.1.4.
2. Áp dụng hoàn chỉnh phong cách Premium Soft Neumorphism 2.0 cho cả Light Mode và Dark Mode.
3. Không có bất kỳ thành phần cuộn ngang nào ở các khu vực cấu hình.
4. Khu vực Cấu hình chung trong Cài đặt có Accordion đóng/mở mượt mà.
5. Danh sách Torrent hiển thị mật độ cao, số liệu sắc nét.
6. Toàn bộ ứng dụng sử dụng 100% tiếng Việt chuẩn xác.
7. Biên dịch và kiểm thử tự động thành công tuyệt đối.
