package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.faker.FakerState
import com.example.core.presets.BuiltInPresets
import com.example.core.presets.Preset
import com.example.core.presets.PresetSettings
import com.example.core.torrent.ClientType
import com.example.core.torrent.OperatingSystem
import com.example.core.util.FormatUtils
import com.example.data.repository.GlobalConfig
import com.example.data.repository.RustatioRepository
import com.example.data.repository.TorrentFilterCategory
import com.example.data.repository.TorrentSortOption
import com.example.data.repository.TorrentUiItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.EnumMap

data class PendingTorrentDraft(
    val rawBytes: ByteArray,
    val info: com.example.core.torrent.TorrentInfo
)

data class GlobalTorrentSummary(
    val totalCount: Int = 0,
    val runningCount: Int = 0,
    val uploadSpeedKBs: Double = 0.0,
    val downloadSpeedKBs: Double = 0.0,
    val uploadSpeedFormatted: String = "0.0 KB/s",
    val downloadSpeedFormatted: String = "0.0 KB/s"
)

class RustatioViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = RustatioRepository.getInstance(application)

    val torrents: StateFlow<List<TorrentUiItem>> = repository.torrentsState

    val globalConfig: StateFlow<GlobalConfig> = repository.globalConfigState

    val allPresets: StateFlow<List<Preset>> = repository.allPresetsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BuiltInPresets.all)

    val customPresets: StateFlow<List<Preset>> = repository.customPresetsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val defaultPresetId: StateFlow<String?> = repository.defaultPresetIdFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "balanced")

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isSearchVisible = MutableStateFlow(false)
    val isSearchVisible: StateFlow<Boolean> = _isSearchVisible.asStateFlow()

    private val _selectedFilter = MutableStateFlow(TorrentFilterCategory.ALL)
    val selectedFilter: StateFlow<TorrentFilterCategory> = _selectedFilter.asStateFlow()

    private val _sortOption = MutableStateFlow(TorrentSortOption.NAME)
    val sortOption: StateFlow<TorrentSortOption> = _sortOption.asStateFlow()

    private val _sortAscending = MutableStateFlow(true)
    val sortAscending: StateFlow<Boolean> = _sortAscending.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _pendingExportJson = MutableStateFlow<Pair<String, String>?>(null)
    val pendingExportJson: StateFlow<Pair<String, String>?> = _pendingExportJson.asStateFlow()

    val globalSummary: StateFlow<GlobalTorrentSummary> = torrents
        .map { list ->
            var running = 0
            var upSpeed = 0.0
            var downSpeed = 0.0
            for (item in list) {
                val st = item.stats.state
                if (st == FakerState.RUNNING || st == FakerState.STARTING) {
                    running++
                }
                upSpeed += item.stats.currentUploadRateKBs
                downSpeed += item.stats.currentDownloadRateKBs
            }
            GlobalTorrentSummary(
                totalCount = list.size,
                runningCount = running,
                uploadSpeedKBs = upSpeed,
                downloadSpeedKBs = downSpeed,
                uploadSpeedFormatted = FormatUtils.formatSpeedKBs(upSpeed),
                downloadSpeedFormatted = FormatUtils.formatSpeedKBs(downSpeed)
            )
        }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), GlobalTorrentSummary())

    val filterCounts: StateFlow<Map<TorrentFilterCategory, Int>> = torrents
        .map { list ->
            val counts = EnumMap<TorrentFilterCategory, Int>(TorrentFilterCategory::class.java)
            for (cat in TorrentFilterCategory.entries) {
                counts[cat] = 0
            }
            counts[TorrentFilterCategory.ALL] = list.size
            for (item in list) {
                val cat = item.filterCategory
                counts[cat] = (counts[cat] ?: 0) + 1
            }
            counts
        }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val filteredTorrents: StateFlow<List<TorrentUiItem>> = combine(
        torrents,
        _searchQuery,
        _selectedFilter,
        _sortOption,
        _sortAscending
    ) { list, query, filter, sort, ascending ->
        val trimmedQuery = query.trim()
        val filtered = list.filter { item ->
            val matchesFilter = (filter == TorrentFilterCategory.ALL) || (item.filterCategory == filter)
            val matchesSearch = trimmedQuery.isEmpty() || item.name.contains(trimmedQuery, ignoreCase = true)
            matchesFilter && matchesSearch
        }

        val comparator: Comparator<TorrentUiItem> = when (sort) {
            TorrentSortOption.NAME -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.name }
            TorrentSortOption.UPLOAD_SPEED -> compareBy<TorrentUiItem> { it.stats.currentUploadRateKBs }
                .thenBy(String.CASE_INSENSITIVE_ORDER) { it.name }
            TorrentSortOption.DOWNLOAD_SPEED -> compareBy<TorrentUiItem> { it.stats.currentDownloadRateKBs }
                .thenBy(String.CASE_INSENSITIVE_ORDER) { it.name }
            TorrentSortOption.UPLOADED -> compareBy<TorrentUiItem> { it.stats.uploadedBytes }
                .thenBy(String.CASE_INSENSITIVE_ORDER) { it.name }
            TorrentSortOption.DOWNLOADED -> compareBy<TorrentUiItem> { it.stats.downloadedBytes }
                .thenBy(String.CASE_INSENSITIVE_ORDER) { it.name }
        }

        if (ascending) {
            filtered.sortedWith(comparator)
        } else {
            filtered.sortedWith(comparator.reversed())
        }
    }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun showMessage(msg: String) {
        _statusMessage.value = msg
    }

    fun toggleSearchVisibility() {
        val next = !_isSearchVisible.value
        _isSearchVisible.value = next
        if (!next) {
            _searchQuery.value = ""
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun clearSearchQuery() {
        _searchQuery.value = ""
    }

    fun setFilterCategory(category: TorrentFilterCategory) {
        _selectedFilter.value = category
    }

    fun setSortOption(option: TorrentSortOption) {
        if (_sortOption.value == option) {
            _sortAscending.value = !_sortAscending.value
        } else {
            _sortOption.value = option
            // Mặc định sắp xếp Tên A-Z (tăng dần), các thông số tốc độ/dung lượng giảm dần (lớn nhất lên đầu)
            _sortAscending.value = (option == TorrentSortOption.NAME)
        }
    }

    /**
     * Nạp trực tiếp các tệp .torrent vào danh sách bằng Cấu hình Chung (Global Configuration)
     * mà không cần mở hộp thoại cấu hình riêng cho từng torrent.
     */
    fun onTorrentFilesPicked(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val resolver = getApplication<Application>().contentResolver
            var addedCount = 0
            var duplicateCount = 0
            var firstError: String? = null

            for (uri in uris) {
                val rawResult = withContext(Dispatchers.IO) {
                    runCatching {
                        resolver.openInputStream(uri)?.use { it.readBytes() }
                            ?: throw IllegalArgumentException("Không thể đọc tệp từ bộ nhớ")
                    }
                }
                rawResult.onSuccess { bytes ->
                    val addRes = repository.addRealTorrentWithGlobalConfig(
                        rawBytes = bytes,
                        autoStart = true
                    )
                    addRes.onSuccess { outcome ->
                        if (outcome.isDuplicate) {
                            duplicateCount++
                        } else {
                            addedCount++
                        }
                    }.onFailure { err ->
                        if (firstError == null) {
                            firstError = err.message ?: "Tệp .torrent không hợp lệ"
                        }
                    }
                }.onFailure { err ->
                    if (firstError == null) {
                        firstError = err.message ?: "Không thể đọc tệp .torrent"
                    }
                }
            }

            _statusMessage.value = when {
                addedCount > 0 && duplicateCount > 0 ->
                    "Đã thêm $addedCount torrent (bỏ qua $duplicateCount torrent trùng lặp)"
                addedCount > 0 ->
                    "Đã thêm và chạy $addedCount torrent theo Cấu hình Chung"
                duplicateCount > 0 ->
                    "Torrent đã tồn tại trong danh sách"
                firstError != null ->
                    "Lỗi nạp tệp: $firstError"
                else -> null
            }
        }
    }

    fun startTorrent(id: String) {
        viewModelScope.launch {
            repository.startTorrent(id)
        }
    }

    fun pauseOrResumeTorrent(id: String) {
        viewModelScope.launch {
            repository.pauseOrResumeTorrent(id)
        }
    }

    fun pauseTorrent(id: String) {
        viewModelScope.launch {
            repository.pauseTorrent(id)
        }
    }

    fun stopTorrent(id: String) {
        viewModelScope.launch {
            repository.stopTorrent(id)
            _statusMessage.value = "Đã dừng phiên báo cáo Tracker"
        }
    }

    fun deleteTorrent(id: String, name: String) {
        viewModelScope.launch {
            repository.deleteTorrent(id)
            _statusMessage.value = "Đã xóa \"$name\""
        }
    }

    fun startAllTorrents() {
        viewModelScope.launch {
            repository.startAllTorrents()
            _statusMessage.value = "Đang chạy tất cả torrent"
        }
    }

    fun pauseAllTorrents() {
        viewModelScope.launch {
            repository.pauseAllTorrents()
            _statusMessage.value = "Đã tạm dừng tất cả torrent"
        }
    }

    fun stopAllTorrents() {
        viewModelScope.launch {
            repository.stopAllTorrents()
            _statusMessage.value = "Đã dừng tất cả torrent"
        }
    }

    fun updateGlobalClient(clientType: ClientType) {
        viewModelScope.launch {
            val updated = repository.updateGlobalConfig(
                clientType = clientType,
                clientVersion = clientType.defaultVersion,
                port = clientType.defaultPort
            )
            _statusMessage.value = "Đã đổi Phần mềm tải sang ${updated.clientType.displayName} ${updated.clientVersion}"
        }
    }

    fun updateGlobalClientVersion(version: String) {
        viewModelScope.launch {
            val updated = repository.updateGlobalConfig(clientVersion = version)
            _statusMessage.value = "Đã cập nhật phiên bản ${updated.clientType.displayName} ${updated.clientVersion}"
        }
    }

    fun updateGlobalOperatingSystem(os: OperatingSystem) {
        viewModelScope.launch {
            val updated = repository.updateGlobalConfig(operatingSystem = os)
            _statusMessage.value = "Đã đặt Hệ điều hành chung: ${updated.operatingSystem.displayName}"
        }
    }

    fun updateGlobalPort(port: Int) {
        viewModelScope.launch {
            val validPort = port.coerceIn(1, 65535)
            repository.updateGlobalConfig(port = validPort)
            _statusMessage.value = "Đã cập nhật Cổng kết nối chung: $validPort"
        }
    }

    fun updateDarkMode(darkMode: Boolean) {
        viewModelScope.launch {
            repository.updateGlobalConfig(darkMode = darkMode)
        }
    }

    fun applyPreset(preset: Preset, targetTorrentId: String? = null) {
        viewModelScope.launch {
            val count = repository.applyPresetToTorrents(preset, targetTorrentId)
            _statusMessage.value = if (count > 0) {
                "Đã áp dụng bộ cấu hình \"${preset.name}\" cho toàn bộ $count torrent"
            } else {
                "Đã đặt \"${preset.name}\" làm bộ cấu hình mặc định"
            }
        }
    }

    fun toggleDefaultPreset(preset: Preset) {
        viewModelScope.launch {
            repository.setDefaultPreset(preset.id)
            _statusMessage.value = "Đã đặt \"${preset.name}\" làm bộ cấu hình mặc định"
        }
    }

    fun saveCustomPreset(
        name: String,
        description: String,
        settings: PresetSettings,
        existingId: String? = null,
        setAsDefault: Boolean = false
    ) {
        viewModelScope.launch {
            val saved = repository.saveCustomPreset(name, description, settings, existingId)
            if (setAsDefault) {
                repository.setDefaultPreset(saved.id)
            }
            _statusMessage.value = "Đã lưu bộ cấu hình \"${saved.name}\""
        }
    }

    fun duplicatePreset(preset: Preset) {
        viewModelScope.launch {
            val copy = repository.duplicatePreset(preset)
            _statusMessage.value = "Đã nhân bản thành \"${copy.name}\""
        }
    }

    fun deleteCustomPreset(preset: Preset) {
        viewModelScope.launch {
            repository.deleteCustomPreset(preset.id)
            _statusMessage.value = "Đã xóa bộ cấu hình \"${preset.name}\""
        }
    }

    fun importPresetFromUri(uri: Uri) {
        viewModelScope.launch {
            val resolver = getApplication<Application>().contentResolver
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val text = resolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: throw IllegalArgumentException("Không thể đọc tệp JSON")
                    repository.importPresetsFromJson(text).getOrThrow()
                }
            }
            result.onSuccess { count ->
                _statusMessage.value = "Đã nhập thành công $count bộ cấu hình từ tệp JSON"
            }.onFailure { err ->
                _statusMessage.value = "Lỗi nhập JSON: ${err.message}"
            }
        }
    }

    fun importPresetFromRawText(jsonText: String) {
        viewModelScope.launch {
            val res = repository.importPresetsFromJson(jsonText)
            res.onSuccess { count ->
                _statusMessage.value = "Đã nhập thành công $count bộ cấu hình"
            }.onFailure { err ->
                _statusMessage.value = "JSON không hợp lệ: ${err.message}"
            }
        }
    }

    fun prepareExportPreset(preset: Preset) {
        val safeName = preset.name.lowercase()
            .replace(Regex("[^a-z0-9\\-_]+"), "-")
            .trim('-')
            .ifEmpty { "custom-preset" }
        val fileName = "rustatio-$safeName.json"
        _pendingExportJson.value = fileName to preset.toExportJsonString()
    }

    fun prepareExportAllCustomPresets() {
        val list = customPresets.value
        if (list.isEmpty()) {
            _statusMessage.value = "Chưa có bộ cấu hình tùy chỉnh nào để xuất"
            return
        }
        val json = repository.exportAllCustomPresetsJson(list)
        _pendingExportJson.value = "rustatio-custom-presets.json" to json
    }

    fun writePendingExportToUri(uri: Uri?) {
        val pending = _pendingExportJson.value
        _pendingExportJson.value = null
        if (uri == null || pending == null) return

        viewModelScope.launch {
            val resolver = getApplication<Application>().contentResolver
            val res = withContext(Dispatchers.IO) {
                runCatching {
                    resolver.openOutputStream(uri)?.use { out ->
                        out.write(pending.second.toByteArray(Charsets.UTF_8))
                        out.flush()
                    } ?: throw IllegalStateException("Không thể ghi vào tệp đã chọn")
                }
            }
            res.onSuccess {
                _statusMessage.value = "Đã xuất tệp JSON thành công (${pending.first})"
            }.onFailure { e ->
                _statusMessage.value = "Lỗi xuất tệp JSON: ${e.message}"
            }
        }
    }
}
