package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.faker.FakerState
import com.example.core.util.FormatUtils
import com.example.data.repository.TorrentFilterCategory
import com.example.data.repository.TorrentUiItem
import com.example.ui.theme.CoralError
import com.example.ui.theme.DownloadBlue
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SpeedPurple
import com.example.ui.theme.StatusConnectingOrange
import com.example.ui.theme.StatusDownloadingBlue
import com.example.ui.theme.StatusErrorRed
import com.example.ui.theme.StatusSeedingGreen
import com.example.ui.theme.StatusStoppedGrey
import com.example.ui.theme.UploadGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TorrentDetailSheet(
    torrent: TorrentUiItem,
    onDismiss: () -> Unit,
    onStartOrResume: () -> Unit,
    onPause: () -> Unit,
    onStop: () -> Unit,
    onRequestDelete: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val stats = torrent.stats
    val isRunning = stats.state == FakerState.RUNNING || stats.state == FakerState.STARTING
    val isPaused = stats.state == FakerState.PAUSED
    val isStopped = stats.state == FakerState.STOPPED || stats.state == FakerState.STOPPING

    val statusDotColor = when {
        !stats.lastError.isNullOrBlank() -> StatusErrorRed
        stats.state == FakerState.STARTING -> StatusConnectingOrange
        torrent.filterCategory == TorrentFilterCategory.DOWNLOADING -> StatusDownloadingBlue
        torrent.filterCategory == TorrentFilterCategory.SEEDING -> StatusSeedingGreen
        else -> StatusStoppedGrey
    }

    val statusTextVi = when {
        !stats.lastError.isNullOrBlank() -> "Lỗi kết nối Tracker"
        stats.state == FakerState.STARTING -> "Đang kết nối Tracker..."
        torrent.filterCategory == TorrentFilterCategory.DOWNLOADING -> "Đang tải xuống"
        torrent.filterCategory == TorrentFilterCategory.SEEDING -> "Đang chia sẻ (Seeding)"
        isPaused -> "Tạm dừng"
        else -> "Đã dừng"
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.testTag("torrent_detail_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Tiêu đề & Trạng thái
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(statusDotColor)
                    )
                    Text(
                        text = statusTextVi,
                        style = MaterialTheme.typography.labelLarge,
                        color = statusDotColor,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Text(
                    text = torrent.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold
                )
            }

            // Nút điều khiển nhanh trong Bottom Sheet
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onStartOrResume,
                    enabled = !isRunning,
                    colors = ButtonDefaults.buttonColors(containerColor = UploadGreen),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("sheet_start_button")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isPaused) "Tiếp tục" else "Chạy", fontWeight = FontWeight.SemiBold)
                }

                OutlinedButton(
                    onClick = onPause,
                    enabled = isRunning,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("sheet_pause_button")
                ) {
                    Icon(Icons.Default.Pause, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Tạm dừng")
                }

                OutlinedButton(
                    onClick = onStop,
                    enabled = !isStopped,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("sheet_stop_button")
                ) {
                    Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Dừng")
                }

                OutlinedButton(
                    onClick = onRequestDelete,
                    border = BorderStroke(1.dp, CoralError.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("sheet_delete_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Xóa torrent",
                        tint = CoralError,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            if (!stats.lastError.isNullOrBlank()) {
                Surface(
                    color = CoralError.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, CoralError.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Chi tiết lỗi: ${stats.lastError}",
                        style = MaterialTheme.typography.bodySmall,
                        color = CoralError,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline)

            // Cụm 6 ô thông số Lưu lượng & Tốc độ
            Text(
                text = "THỐNG KÊ LƯU LƯỢNG & TỐC ĐỘ",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DetailMetricBox(
                    label = "Đã tải lên",
                    value = torrent.uploadedFormatted,
                    accentColor = UploadGreen,
                    modifier = Modifier.weight(1f)
                )
                DetailMetricBox(
                    label = "Đã tải xuống",
                    value = torrent.downloadedFormatted,
                    accentColor = DownloadBlue,
                    modifier = Modifier.weight(1f)
                )
                DetailMetricBox(
                    label = "Tỷ lệ (Ratio)",
                    value = FormatUtils.formatRatio(stats.ratio),
                    accentColor = SpeedPurple,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DetailMetricBox(
                    label = "Tốc độ tải lên",
                    value = FormatUtils.formatSpeedKBs(stats.currentUploadRateKBs),
                    accentColor = UploadGreen,
                    modifier = Modifier.weight(1f)
                )
                DetailMetricBox(
                    label = "Tốc độ tải xuống",
                    value = FormatUtils.formatSpeedKBs(stats.currentDownloadRateKBs),
                    accentColor = DownloadBlue,
                    modifier = Modifier.weight(1f)
                )
                DetailMetricBox(
                    label = "Tổng dung lượng",
                    value = FormatUtils.formatBytes(torrent.totalSize),
                    accentColor = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline)

            // Chi tiết Tracker & InfoHash
            Text(
                text = "THÔNG TIN TRACKER & PHIÊN KẾT NỐI",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DetailKeyValueRow(
                        label = "Máy chủ Tracker",
                        value = torrent.trackerHost
                    )
                    DetailKeyValueRow(
                        label = "Seeders / Leechers",
                        value = "${stats.seeders} Seeders · ${stats.leechers} Leechers"
                    )
                    DetailKeyValueRow(
                        label = "Số lần báo cáo (Announce)",
                        value = "${stats.announceCount} lần · Tiếp theo sau ${FormatUtils.formatDurationShort(stats.nextAnnounceInSecs)}"
                    )
                    DetailKeyValueRow(
                        label = "Mã băm (InfoHash)",
                        value = torrent.infoHashHex,
                        monospace = true
                    )
                }
            }

            // Cấu hình Chung đang áp dụng
            Text(
                text = "CẤU HÌNH CHUNG ĐANG ÁP DỤNG",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DetailKeyValueRow(
                        label = "Bộ cấu hình (Preset)",
                        value = torrent.presetName
                    )
                    DetailKeyValueRow(
                        label = "Phần mềm tải (Client)",
                        value = "${torrent.clientDisplayName} ${torrent.clientVersion}"
                    )
                    DetailKeyValueRow(
                        label = "Hệ điều hành",
                        value = torrent.operatingSystem.displayName
                    )
                    DetailKeyValueRow(
                        label = "Cổng kết nối (Port)",
                        value = torrent.port.toString(),
                        monospace = true
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
        }
    }
}

@Composable
private fun DetailMetricBox(
    label: String,
    value: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                color = accentColor,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun DetailKeyValueRow(
    label: String,
    value: String,
    monospace: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.42f)
        )
        Text(
            text = value,
            style = if (monospace) {
                MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily)
            } else {
                MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
            },
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(0.58f)
        )
    }
}
