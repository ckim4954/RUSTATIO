package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val RustatioDarkColorScheme = darkColorScheme(
    primary = DarkNeuPrimary,
    onPrimary = Color(0xFF042F20),
    primaryContainer = DarkNeuAccentMint,
    onPrimaryContainer = DarkNeuPrimary,
    secondary = DownloadBlue,
    onSecondary = Color(0xFF082F49),
    secondaryContainer = DarkNeuSurfaceSecondary,
    onSecondaryContainer = DownloadBlue,
    tertiary = SpeedPurple,
    onTertiary = Color.White,
    tertiaryContainer = DarkNeuAccentLavender,
    onTertiaryContainer = Color(0xFFE9D5FF),
    background = DarkNeuBg,
    onBackground = DarkNeuTextPrimary,
    surface = DarkNeuSurface,
    onSurface = DarkNeuTextPrimary,
    surfaceVariant = DarkNeuSurfaceSecondary,
    onSurfaceVariant = DarkNeuTextSecondary,
    outline = DarkNeuDivider,
    error = CoralError,
    onError = Color.White,
    errorContainer = Color(0xFF492121),
    onErrorContainer = Color(0xFFFECACA)
)

private val RustatioLightColorScheme = lightColorScheme(
    primary = LightNeuPrimary,
    onPrimary = Color.White,
    primaryContainer = LightNeuAccentMint,
    onPrimaryContainer = LightNeuPrimaryDark,
    secondary = DownloadBlue,
    onSecondary = Color.White,
    secondaryContainer = LightNeuAccentMint,
    onSecondaryContainer = LightNeuPrimaryDark,
    tertiary = SpeedPurple,
    onTertiary = Color.White,
    tertiaryContainer = LightNeuAccentLavender,
    onTertiaryContainer = Color(0xFF4C1D95),
    background = LightNeuBg,
    onBackground = LightNeuTextPrimary,
    surface = LightNeuSurface,
    onSurface = LightNeuTextPrimary,
    surfaceVariant = LightNeuSurfaceSecondary,
    onSurfaceVariant = LightNeuTextSecondary,
    outline = LightNeuDivider,
    error = CoralError,
    onError = Color.White,
    errorContainer = Color(0xFFFEE2E2),
    onErrorContainer = Color(0xFF991B1B)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) RustatioDarkColorScheme else RustatioLightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
