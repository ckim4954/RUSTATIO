package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Balance
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.presets.Preset
import com.example.core.util.FormatUtils
import com.example.ui.components.NeumorphicCard
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CoralError
import com.example.ui.theme.DownloadBlue
import com.example.ui.theme.EmeraldDim
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.PurpleDim
import com.example.ui.theme.PurpleTertiary
import com.example.ui.theme.SkySecondary

private enum class PresetFilterTab(val labelVi: String) {
    ALL("Tất cả"),
    BUILT_IN("Có sẵn (4)"),
    CUSTOM("Tùy chỉnh")
}

@Composable
fun PresetsSettingsScreen(
    allPresets: List<Preset>,
    customPresets: List<Preset>,
    defaultPresetId: String?,
    onApplyPreset: (Preset) -> Unit,
    onToggleDefaultPreset: (Preset) -> Unit,
    onCreateNewCustomPreset: () -> Unit,
    onEditPreset: (Preset) -> Unit,
    onDuplicatePreset: (Preset) -> Unit,
    onDeleteCustomPreset: (Preset) -> Unit,
    onOpenImportJson: () -> Unit,
    onExportSinglePreset: (Preset) -> Unit,
    onExportAllCustomPresets: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(PresetFilterTab.ALL) }
    var presetPendingDelete by remember { mutableStateOf<Preset?>(null) }

    val displayedPresets = remember(allPresets, selectedTab) {
        when (selectedTab) {
            PresetFilterTab.ALL -> allPresets
            PresetFilterTab.BUILT_IN -> allPresets.filter { !it.custom }
            PresetFilterTab.CUSTOM -> allPresets.filter { it.custom }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("presets_settings_screen"),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "presets_header") {
            PresetsHeaderPanel(
                customCount = customPresets.size,
                defaultPreset = allPresets.firstOrNull { it.id == defaultPresetId },
                onCreateNew = onCreateNewCustomPreset,
                onImportJson = onOpenImportJson,
                onExportAllJson = onExportAllCustomPresets
            )
        }

        item(key = "presets_filter_tabs") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PresetFilterTab.entries.forEach { tab ->
                    val isSelected = selectedTab == tab
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        label = { Text(tab.labelVi) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldPrimary.copy(alpha = 0.2f),
                            selectedLabelColor = EmeraldPrimary,
                            containerColor = MaterialTheme.colorScheme.surface,
                            labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        modifier = Modifier.testTag("preset_tab_${tab.name.lowercase()}")
                    )
                }
            }
        }

        if (displayedPresets.isEmpty()) {
            item(key = "empty_custom_presets") {
                NeumorphicCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Chưa có bộ cấu hình tùy chỉnh nào",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Tạo bộ cấu hình tốc độ và điều kiện dừng riêng hoặc nhập tệp .json.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = onOpenImportJson,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                            ) {
                                Icon(Icons.Default.FileDownload, contentDescription = null, tint = SkySecondary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Nhập JSON")
                            }
                            Button(
                                onClick = onCreateNewCustomPreset,
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Tạo mới", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        } else {
            items(
                items = displayedPresets,
                key = { it.id }
            ) { preset ->
                PresetDetailCard(
                    preset = preset,
                    isDefault = preset.id == defaultPresetId,
                    onApply = { onApplyPreset(preset) },
                    onToggleDefault = { onToggleDefaultPreset(preset) },
                    onEdit = { onEditPreset(preset) },
                    onDuplicate = { onDuplicatePreset(preset) },
                    onExportJson = { onExportSinglePreset(preset) },
                    onRequestDelete = { presetPendingDelete = preset }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    presetPendingDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { presetPendingDelete = null },
            containerColor = MaterialTheme.colorScheme.surface,
            titleContentColor = MaterialTheme.colorScheme.onSurface,
            textContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
            title = {
                Text("Xác nhận xóa bộ cấu hình", fontWeight = FontWeight.Bold)
            },
            text = {
                Text("Bạn có chắc chắn muốn xóa bộ cấu hình tùy chỉnh \"${target.name}\" không?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val toDelete = target
                        presetPendingDelete = null
                        onDeleteCustomPreset(toDelete)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CoralError),
                    modifier = Modifier.testTag("confirm_delete_preset_button")
                ) {
                    Text("Xóa", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { presetPendingDelete = null }) {
                    Text("Hủy")
                }
            }
        )
    }
}

@Composable
private fun PresetsHeaderPanel(
    customCount: Int,
    defaultPreset: Preset?,
    onCreateNew: () -> Unit,
    onImportJson: () -> Unit,
    onExportAllJson: () -> Unit
) {
    NeumorphicCard(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "QUẢN LÝ BỘ CẤU HÌNH (PRESETS)",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (defaultPreset != null) {
                            "Đang áp dụng: ${defaultPreset.name}"
                        } else {
                            "Đang áp dụng: Cân Bằng"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = onCreateNew,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("create_custom_preset_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Tạo mới", fontWeight = FontWeight.Bold)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onImportJson,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("import_preset_json_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.FileDownload,
                        contentDescription = "Nhập bộ cấu hình JSON",
                        tint = DownloadBlue,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Nhập JSON", color = MaterialTheme.colorScheme.onSurface)
                }

                OutlinedButton(
                    onClick = onExportAllJson,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("export_all_presets_json_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.FileUpload,
                        contentDescription = "Xuất bộ cấu hình JSON",
                        tint = PurpleTertiary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Xuất JSON ($customCount)", color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PresetDetailCard(
    preset: Preset,
    isDefault: Boolean,
    onApply: () -> Unit,
    onToggleDefault: () -> Unit,
    onEdit: () -> Unit,
    onDuplicate: () -> Unit,
    onExportJson: () -> Unit,
    onRequestDelete: () -> Unit
) {
    var showTips by remember { mutableStateOf(false) }
    val cfg = preset.settings

    val iconVector = when (preset.icon) {
        "scale" -> Icons.Default.Balance
        "rocket" -> Icons.Default.RocketLaunch
        "server" -> Icons.Default.Storage
        "eye-off" -> Icons.Default.Shield
        else -> Icons.Default.Star
    }

    NeumorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("preset_card_${preset.id}"),
        borderColor = if (isDefault) AmberWarning.copy(alpha = 0.7f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.55f),
        elevation = if (isDefault) 3.dp else 1.5.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (preset.custom) PurpleDim else EmeraldDim),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = iconVector,
                            contentDescription = null,
                            tint = if (preset.custom) PurpleTertiary else EmeraldPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = preset.name,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = preset.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (isDefault) {
                        PresetStatusBadge(text = "MẶC ĐỊNH", color = AmberWarning)
                    }
                    if (preset.recommended) {
                        PresetStatusBadge(text = "KHUYÊN DÙNG", color = EmeraldPrimary)
                    } else if (preset.custom) {
                        PresetStatusBadge(text = "TÙY CHỈNH", color = PurpleTertiary)
                    }
                }
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val upLabel = if (cfg.progressiveRatesEnabled) {
                    "↑ ${FormatUtils.formatSpeedKBs(cfg.uploadRate)} → ${FormatUtils.formatSpeedKBs(cfg.targetUploadRate)} (${cfg.progressiveDurationHours}g)"
                } else {
                    "↑ ${FormatUtils.formatSpeedKBs(cfg.uploadRate)}"
                }
                PresetParamChip(text = upLabel, highlightColor = EmeraldPrimary)

                if (cfg.downloadRate > 0.0) {
                    PresetParamChip(
                        text = "↓ ${FormatUtils.formatSpeedKBs(cfg.downloadRate)}",
                        highlightColor = DownloadBlue
                    )
                }
                if (cfg.randomizeRates) {
                    PresetParamChip(
                        text = "Ngẫu nhiên ±${cfg.randomRangePercent.toInt()}%",
                        highlightColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (cfg.stopAtRatioEnabled) {
                    PresetParamChip(
                        text = "Dừng ở Ratio ${cfg.stopAtRatio}",
                        highlightColor = AmberWarning
                    )
                }
                if (cfg.stopAtUploadedEnabled) {
                    PresetParamChip(
                        text = "Dừng ở ${cfg.stopAtUploadedGB} GB",
                        highlightColor = AmberWarning
                    )
                }
                if (cfg.idleWhenNoLeechers) {
                    PresetParamChip(
                        text = "Nghỉ khi 0 Leecher",
                        highlightColor = DownloadBlue
                    )
                }
            }

            if (preset.tips.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { showTips = !showTips }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = if (showTips) "▼ Ẩn ghi chú kỹ thuật" else "▶ Xem ghi chú kỹ thuật (${preset.tips.size})",
                        style = MaterialTheme.typography.labelSmall,
                        color = DownloadBlue
                    )
                    AnimatedVisibility(visible = showTips) {
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            preset.tips.forEach { tip ->
                                Text(
                                    text = "• $tip",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onApply,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("apply_preset_button_${preset.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Áp dụng", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onToggleDefault,
                    border = BorderStroke(
                        1.dp,
                        if (isDefault) AmberWarning else MaterialTheme.colorScheme.outline
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("default_preset_button_${preset.id}")
                ) {
                    Icon(
                        imageVector = if (isDefault) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = null,
                        tint = if (isDefault) AmberWarning else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isDefault) "Mặc định" else "Đặt mặc định",
                        color = if (isDefault) AmberWarning else MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.labelLarge
                    )
                }

                if (preset.custom) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .testTag("edit_preset_${preset.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Chỉnh sửa bộ cấu hình",
                            tint = DownloadBlue,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                IconButton(
                    onClick = onDuplicate,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .testTag("duplicate_preset_${preset.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Nhân bản bộ cấu hình",
                        tint = DownloadBlue,
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = onExportJson,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .testTag("export_preset_${preset.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.FileUpload,
                        contentDescription = "Xuất JSON",
                        tint = PurpleTertiary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                if (preset.custom) {
                    IconButton(
                        onClick = onRequestDelete,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .testTag("delete_preset_${preset.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Xóa bộ cấu hình",
                            tint = CoralError,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PresetStatusBadge(text: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.14f),
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.45f))
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun PresetParamChip(
    text: String,
    highlightColor: Color
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = highlightColor,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}
