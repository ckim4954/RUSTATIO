package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.faker.FakerState
import com.example.data.repository.TorrentFilterCategory
import com.example.data.repository.TorrentSortOption
import com.example.data.repository.TorrentUiItem
import com.example.ui.components.TorrentDetailSheet
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CoralError
import com.example.ui.theme.DownloadBlue
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SpeedPurple
import com.example.ui.theme.StatusConnectingOrange
import com.example.ui.theme.StatusDownloadingBlue
import com.example.ui.theme.StatusErrorRed
import com.example.ui.theme.StatusSeedingGreen
import com.example.ui.theme.StatusStoppedGrey
import com.example.ui.theme.UploadGreen

@Composable
fun TorrentListScreen(
    torrents: List<TorrentUiItem>,
    totalUnfilteredCount: Int,
    searchQuery: String,
    isSearchVisible: Boolean,
    selectedFilter: TorrentFilterCategory,
    filterCounts: Map<TorrentFilterCategory, Int>,
    sortOption: TorrentSortOption,
    sortAscending: Boolean,
    onSearchQueryChange: (String) -> Unit,
    onClearSearch: () -> Unit,
    onSelectFilter: (TorrentFilterCategory) -> Unit,
    onSelectSort: (TorrentSortOption) -> Unit,
    onPickTorrentFile: () -> Unit,
    onStartTorrent: (String) -> Unit,
    onPauseResumeTorrent: (String) -> Unit,
    onPauseTorrent: (String) -> Unit,
    onStopTorrent: (String) -> Unit,
    onDeleteTorrent: (TorrentUiItem) -> Unit,
    onStartAll: () -> Unit,
    onPauseAll: () -> Unit,
    onStopAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()
    var selectedDetailTorrentId by remember { mutableStateOf<String?>(null) }
    var torrentPendingDelete by remember { mutableStateOf<TorrentUiItem?>(null) }

    val selectedDetailTorrent = remember(torrents, selectedDetailTorrentId) {
        selectedDetailTorrentId?.let { id -> torrents.firstOrNull { it.id == id } }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Thanh tìm kiếm thu gọn (hiển thị khi bật tìm kiếm hoặc đang có từ khóa)
        AnimatedVisibility(visible = isSearchVisible || searchQuery.isNotEmpty()) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("Tìm torrent theo tên...") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = onClearSearch,
                            modifier = Modifier.testTag("clear_search_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Xóa tìm kiếm",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EmeraldPrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .testTag("torrent_search_input")
            )
        }

        // Thanh điều khiển chung (Chạy tất cả / Tạm dừng tất cả / Dừng tất cả)
        if (totalUnfilteredCount > 0) {
            CompactGlobalControlsBar(
                onStartAll = onStartAll,
                onPauseAll = onPauseAll,
                onStopAll = onStopAll
            )

            // Thanh Bộ lọc trạng thái + Sắp xếp gọn trên 1 hàng
            CompactFilterAndSortBar(
                selectedFilter = selectedFilter,
                filterCounts = filterCounts,
                sortOption = sortOption,
                sortAscending = sortAscending,
                onSelectFilter = onSelectFilter,
                onSelectSort = onSelectSort
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
        }

        // Vùng hiển thị chính: Danh sách Torrent mật độ cao (LazyColumn)
        if (totalUnfilteredCount == 0) {
            EmptyTorrentsView(
                onPickTorrentFile = onPickTorrentFile,
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            )
        } else if (torrents.isEmpty()) {
            FilteredEmptyView(
                onResetFilters = {
                    onClearSearch()
                    onSelectFilter(TorrentFilterCategory.ALL)
                },
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            )
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
                    .testTag("torrent_lazy_list"),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                items(
                    items = torrents,
                    key = { it.id },
                    contentType = { "torrent_row" }
                ) { item ->
                    TorrentCompactRow(
                        item = item,
                        onRowClick = { selectedDetailTorrentId = item.id },
                        onStartOrResume = {
                            if (item.stats.state == FakerState.PAUSED) {
                                onPauseResumeTorrent(item.id)
                            } else {
                                onStartTorrent(item.id)
                            }
                        },
                        onPause = { onPauseTorrent(item.id) },
                        onStop = { onStopTorrent(item.id) },
                        onOpenDetails = { selectedDetailTorrentId = item.id },
                        onRequestDelete = { torrentPendingDelete = item }
                    )
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
            }
        }
    }

    // Bottom Sheet chi tiết kỹ thuật khi chạm vào 1 dòng torrent
    selectedDetailTorrent?.let { detailItem ->
        TorrentDetailSheet(
            torrent = detailItem,
            onDismiss = { selectedDetailTorrentId = null },
            onStartOrResume = {
                if (detailItem.stats.state == FakerState.PAUSED) {
                    onPauseResumeTorrent(detailItem.id)
                } else {
                    onStartTorrent(detailItem.id)
                }
            },
            onPause = { onPauseTorrent(detailItem.id) },
            onStop = { onStopTorrent(detailItem.id) },
            onRequestDelete = {
                selectedDetailTorrentId = null
                torrentPendingDelete = detailItem
            }
        )
    }

    // Hộp thoại xác nhận trước khi xóa torrent
    torrentPendingDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { torrentPendingDelete = null },
            containerColor = MaterialTheme.colorScheme.surface,
            titleContentColor = MaterialTheme.colorScheme.onSurface,
            textContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
            title = {
                Text(
                    text = "Xác nhận xóa torrent",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "Bạn có chắc chắn muốn xóa \"${target.name}\" khỏi danh sách không?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val toDelete = target
                        torrentPendingDelete = null
                        onDeleteTorrent(toDelete)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CoralError),
                    modifier = Modifier.testTag("confirm_delete_torrent_button")
                ) {
                    Text("Xóa", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { torrentPendingDelete = null },
                    modifier = Modifier.testTag("cancel_delete_torrent_button")
                ) {
                    Text("Hủy")
                }
            }
        )
    }
}

@Composable
private fun CompactGlobalControlsBar(
    onStartAll: () -> Unit,
    onPauseAll: () -> Unit,
    onStopAll: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            onClick = onStartAll,
            color = UploadGreen.copy(alpha = 0.14f),
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, UploadGreen.copy(alpha = 0.45f)),
            modifier = Modifier
                .weight(1f)
                .height(36.dp)
                .testTag("start_all_button")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = UploadGreen,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Chạy tất cả",
                    style = MaterialTheme.typography.labelMedium,
                    color = UploadGreen,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Surface(
            onClick = onPauseAll,
            color = AmberWarning.copy(alpha = 0.14f),
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, AmberWarning.copy(alpha = 0.45f)),
            modifier = Modifier
                .weight(1f)
                .height(36.dp)
                .testTag("pause_all_button")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Pause,
                    contentDescription = null,
                    tint = AmberWarning,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Tạm dừng tất cả",
                    style = MaterialTheme.typography.labelMedium,
                    color = AmberWarning,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Surface(
            onClick = onStopAll,
            color = CoralError.copy(alpha = 0.14f),
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, CoralError.copy(alpha = 0.45f)),
            modifier = Modifier
                .weight(1f)
                .height(36.dp)
                .testTag("stop_all_button")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Stop,
                    contentDescription = null,
                    tint = CoralError,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Dừng tất cả",
                    style = MaterialTheme.typography.labelMedium,
                    color = CoralError,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun CompactFilterAndSortBar(
    selectedFilter: TorrentFilterCategory,
    filterCounts: Map<TorrentFilterCategory, Int>,
    sortOption: TorrentSortOption,
    sortAscending: Boolean,
    onSelectFilter: (TorrentFilterCategory) -> Unit,
    onSelectSort: (TorrentSortOption) -> Unit
) {
    var sortMenuExpanded by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TorrentFilterCategory.entries.forEach { category ->
                val count = filterCounts[category] ?: 0
                val isSelected = selectedFilter == category
                FilterChip(
                    selected = isSelected,
                    onClick = { onSelectFilter(category) },
                    label = {
                        Text(
                            text = if (count > 0) "${category.labelVi} ($count)" else category.labelVi,
                            style = MaterialTheme.typography.labelSmall
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EmeraldPrimary.copy(alpha = 0.2f),
                        selectedLabelColor = EmeraldPrimary,
                        containerColor = MaterialTheme.colorScheme.surface,
                        labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier
                        .height(30.dp)
                        .testTag("filter_chip_${category.name.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.width(6.dp))

        Box {
            Surface(
                onClick = { sortMenuExpanded = true },
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier
                    .height(30.dp)
                    .testTag("sort_dropdown_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Sort,
                        contentDescription = "Sắp xếp",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = sortOption.labelVi,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Icon(
                        imageVector = if (sortAscending) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                        contentDescription = null,
                        tint = EmeraldPrimary,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }

            DropdownMenu(
                expanded = sortMenuExpanded,
                onDismissRequest = { sortMenuExpanded = false }
            ) {
                TorrentSortOption.entries.forEach { option ->
                    DropdownMenuItem(
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = option.labelVi,
                                    fontWeight = if (option == sortOption) FontWeight.Bold else FontWeight.Normal,
                                    color = if (option == sortOption) EmeraldPrimary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        },
                        onClick = {
                            sortMenuExpanded = false
                            onSelectSort(option)
                        },
                        modifier = Modifier.testTag("sort_option_${option.name.lowercase()}")
                    )
                }
            }
        }
    }
}

/**
 * Dòng hiển thị Torrent mật độ cao (Compact Row):
 * - Dòng 1: Chấm màu trạng thái + Tên Torrent (1 dòng, rút gọn dấu ...) + nút ⋮ mở menu ngữ cảnh.
 * - Dòng 2: CHỈ hiển thị 3 thông số với biểu tượng & màu sắc riêng biệt (↑ Đã tải lên, ↓ Đã tải xuống, ⇅ Tốc độ),
 *   tuyệt đối KHÔNG kèm nhãn chữ rườm rà hay thông tin Client/OS/Port/Preset/Tracker.
 */
@Composable
private fun TorrentCompactRow(
    item: TorrentUiItem,
    onRowClick: () -> Unit,
    onStartOrResume: () -> Unit,
    onPause: () -> Unit,
    onStop: () -> Unit,
    onOpenDetails: () -> Unit,
    onRequestDelete: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val stats = item.stats
    val isRunning = stats.state == FakerState.RUNNING || stats.state == FakerState.STARTING
    val isPaused = stats.state == FakerState.PAUSED
    val isStopped = stats.state == FakerState.STOPPED || stats.state == FakerState.STOPPING

    val statusDotColor = when {
        !stats.lastError.isNullOrBlank() -> StatusErrorRed
        stats.state == FakerState.STARTING -> StatusConnectingOrange
        item.filterCategory == TorrentFilterCategory.DOWNLOADING -> StatusDownloadingBlue
        item.filterCategory == TorrentFilterCategory.SEEDING -> StatusSeedingGreen
        else -> StatusStoppedGrey
    }

    val statusSemanticsLabel = when {
        !stats.lastError.isNullOrBlank() -> "Trạng thái: Lỗi"
        stats.state == FakerState.STARTING -> "Trạng thái: Đang kết nối"
        item.filterCategory == TorrentFilterCategory.DOWNLOADING -> "Trạng thái: Đang tải"
        item.filterCategory == TorrentFilterCategory.SEEDING -> "Trạng thái: Đang chia sẻ"
        isPaused -> "Trạng thái: Tạm dừng"
        else -> "Trạng thái: Đã dừng"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onRowClick)
            .padding(start = 14.dp, end = 4.dp, top = 8.dp, bottom = 8.dp)
            .testTag("torrent_item_card_${item.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            // Dòng 1: Chấm trạng thái + Tên Torrent (1 dòng)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(9.dp)
                        .clip(CircleShape)
                        .background(statusDotColor)
                        .semantics { contentDescription = statusSemanticsLabel }
                )

                Text(
                    text = item.name,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("torrent_name_${item.id}")
                )
            }

            // Dòng 2: CHỈ hiển thị ↑ Uploaded | ↓ Downloaded | ⇅ Speed | Seeders/Leechers
            Row(
                modifier = Modifier.padding(start = 17.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "↑ ${item.uploadedFormatted}",
                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                    color = UploadGreen,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    modifier = Modifier.testTag("torrent_uploaded_${item.id}")
                )

                Text(
                    text = "↓ ${item.downloadedFormatted}",
                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                    color = DownloadBlue,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    modifier = Modifier.testTag("torrent_downloaded_${item.id}")
                )

                Text(
                    text = "⇅ ${item.speedFormatted}",
                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                    color = SpeedPurple,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    modifier = Modifier.testTag("torrent_speed_${item.id}")
                )

                Text(
                    text = "${stats.seeders}S / ${stats.leechers}L",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }

        // Nút ⋮ mở Menu ngữ cảnh nhỏ gọn
        Box {
            IconButton(
                onClick = { menuExpanded = true },
                modifier = Modifier
                    .size(48.dp)
                    .testTag("torrent_menu_button_${item.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Tùy chọn cho ${item.name}",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            }

            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false }
            ) {
                if (!isRunning) {
                    DropdownMenuItem(
                        text = { Text(if (isPaused) "Tiếp tục" else "Chạy") },
                        leadingIcon = {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = UploadGreen)
                        },
                        onClick = {
                            menuExpanded = false
                            onStartOrResume()
                        },
                        modifier = Modifier.testTag("menu_start_${item.id}")
                    )
                }

                if (isRunning) {
                    DropdownMenuItem(
                        text = { Text("Tạm dừng") },
                        leadingIcon = {
                            Icon(Icons.Default.Pause, contentDescription = null, tint = AmberWarning)
                        },
                        onClick = {
                            menuExpanded = false
                            onPause()
                        },
                        modifier = Modifier.testTag("menu_pause_${item.id}")
                    )
                }

                if (!isStopped) {
                    DropdownMenuItem(
                        text = { Text("Dừng") },
                        leadingIcon = {
                            Icon(Icons.Default.Stop, contentDescription = null, tint = CoralError)
                        },
                        onClick = {
                            menuExpanded = false
                            onStop()
                        },
                        modifier = Modifier.testTag("menu_stop_${item.id}")
                    )
                }

                DropdownMenuItem(
                    text = { Text("Chi tiết") },
                    leadingIcon = {
                        Icon(
                            Icons.Default.Info,
                            contentDescription = null,
                            tint = DownloadBlue
                        )
                    },
                    onClick = {
                        menuExpanded = false
                        onOpenDetails()
                    },
                    modifier = Modifier.testTag("menu_details_${item.id}")
                )

                DropdownMenuItem(
                    text = { Text("Xóa", color = CoralError) },
                    leadingIcon = {
                        Icon(
                            Icons.Default.DeleteOutline,
                            contentDescription = null,
                            tint = CoralError
                        )
                    },
                    onClick = {
                        menuExpanded = false
                        onRequestDelete()
                    },
                    modifier = Modifier.testTag("menu_delete_${item.id}")
                )
            }
        }
    }
}

@Composable
private fun EmptyTorrentsView(
    onPickTorrentFile: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .padding(24.dp)
            .testTag("empty_torrents_card"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(EmeraldPrimary.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CloudUpload,
                    contentDescription = null,
                    tint = EmeraldPrimary,
                    modifier = Modifier.size(28.dp)
                )
            }

            Text(
                text = "Danh sách Torrent trống",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "Nhấn nút Thêm .torrent để nạp tệp thực tế từ thiết bị. Tất cả torrent sẽ tự động sử dụng Cấu hình Chung của bạn.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Button(
                onClick = onPickTorrentFile,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("empty_state_add_torrent_button")
            ) {
                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Thêm tệp .torrent", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun FilteredEmptyView(
    onResetFilters: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .padding(24.dp)
            .testTag("filtered_empty_view"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "Không tìm thấy torrent phù hợp",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.SemiBold
            )
            OutlinedButton(
                onClick = onResetFilters,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("reset_filter_button")
            ) {
                Text("Xóa bộ lọc & tìm kiếm")
            }
        }
    }
}
