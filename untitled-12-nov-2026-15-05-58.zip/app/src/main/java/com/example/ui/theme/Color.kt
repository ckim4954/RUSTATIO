package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ==========================================
// 1. LIGHT MODE – SOFT PASTEL NEUMORPHISM
// ==========================================
val LightNeuBg = Color(0xFFF1F5F2)
val LightNeuSurface = Color(0xFFF9FBF9)
val LightNeuSurfaceSecondary = Color(0xFFE9F0EB)
val LightNeuPrimary = Color(0xFF35B889)
val LightNeuPrimaryDark = Color(0xFF168C67)
val LightNeuAccentMint = Color(0xFFD8F2E7)
val LightNeuAccentLavender = Color(0xFFE7E0F5)
val LightNeuAccentPeach = Color(0xFFF8E8DD)
val LightNeuTextPrimary = Color(0xFF26352F)
val LightNeuTextSecondary = Color(0xFF74827A)
val LightNeuDivider = Color(0xFFDCE6DF)

// Light Mode Shadow Tokens
val LightShadowLight = Color(0xFFFFFFFF)
val LightShadowDark = Color(0xFFD1DDD4).copy(alpha = 0.7f)

// ==========================================
// 2. DARK MODE – PREMIUM DARK NEUMORPHISM
// ==========================================
val DarkNeuBg = Color(0xFF171D1B)
val DarkNeuSurface = Color(0xFF202925)
val DarkNeuSurfaceSecondary = Color(0xFF252F2A)
val DarkNeuPrimary = Color(0xFF42C99A)
val DarkNeuPrimaryDark = Color(0xFF209B73)
val DarkNeuAccentMint = Color(0xFF244B3D)
val DarkNeuAccentLavender = Color(0xFF383047)
val DarkNeuAccentPeach = Color(0xFF49362E)
val DarkNeuTextPrimary = Color(0xFFE5EEE8)
val DarkNeuTextSecondary = Color(0xFF9BAAA1)
val DarkNeuDivider = Color(0xFF344039)

// Dark Mode Shadow Tokens
val DarkShadowLight = Color(0xFF28342F).copy(alpha = 0.5f)
val DarkShadowDark = Color(0xFF0E1211).copy(alpha = 0.85f)

// ==========================================
// 3. SEMANTIC STATUS & METRIC ACCENTS
// ==========================================
val UploadGreen = Color(0xFF35B889)      // Upload traffic
val DownloadBlue = Color(0xFF38BDF8)     // Download traffic
val SpeedPurple = Color(0xFFA855F7)      // Combined Speed / Preset highlight
val AmberWarning = Color(0xFFF59E0B)     // Connecting / Announcing / Ratio stop
val CoralError = Color(0xFFEF4444)       // Error / Delete
val SlateStopped = Color(0xFF74827A)     // Stopped / Paused

val StatusSeedingGreen = UploadGreen
val StatusDownloadingBlue = DownloadBlue
val StatusConnectingOrange = AmberWarning
val StatusStoppedGrey = SlateStopped
val StatusErrorRed = CoralError

// Backward-compatible aliases
val EmeraldPrimary = DarkNeuPrimary
val EmeraldDim = DarkNeuAccentMint
val SkySecondary = DownloadBlue
val PurpleTertiary = SpeedPurple
val ObsidianBg = DarkNeuBg
val ObsidianSurface = DarkNeuSurface
val ObsidianSurfaceVariant = DarkNeuSurfaceSecondary
val ObsidianSurfaceElevated = DarkNeuSurfaceSecondary
val ObsidianBorder = DarkNeuDivider
val PurpleDim = DarkNeuAccentLavender
val TextPrimary = DarkNeuTextPrimary
val TextSecondary = DarkNeuTextSecondary
val TextMuted = DarkNeuTextSecondary
val LightBg = LightNeuBg
val LightSurface = LightNeuSurface
val LightSurfaceVariant = LightNeuSurfaceSecondary
val LightBorder = LightNeuDivider
val LightTextPrimary = LightNeuTextPrimary
val LightTextSecondary = LightNeuTextSecondary
