package com.example.data.repository

import android.content.Context
import androidx.annotation.VisibleForTesting
import com.example.core.faker.FakerRuntimeStats
import com.example.core.faker.FakerState
import com.example.core.faker.RatioFakerSession
import com.example.core.presets.BuiltInPresets
import com.example.core.presets.Preset
import com.example.core.presets.PresetSettings
import com.example.core.protocol.PeerListenerService
import com.example.core.torrent.ClientType
import com.example.core.torrent.OperatingSystem
import com.example.core.torrent.TorrentInfo
import com.example.core.util.FormatUtils
import com.example.data.local.AppDatabase
import com.example.data.local.AppPreferenceEntity
import com.example.data.local.CustomPresetEntity
import com.example.data.local.TorrentEntity
import com.example.service.TrackerForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject

enum class TorrentFilterCategory(val labelVi: String) {
    ALL("Tất cả"),
    SEEDING("Đang chia sẻ"),
    DOWNLOADING("Đang tải"),
    PAUSED("Tạm dừng"),
    STOPPED("Đã dừng"),
    ERROR("Lỗi")
}

enum class TorrentSortOption(val labelVi: String) {
    NAME("Tên"),
    UPLOAD_SPEED("Tốc độ tải lên"),
    DOWNLOAD_SPEED("Tốc độ tải xuống"),
    UPLOADED("Đã tải lên"),
    DOWNLOADED("Đã tải xuống")
}

data class GlobalConfig(
    val clientType: ClientType = ClientType.QBITTORRENT,
    val clientVersion: String = ClientType.QBITTORRENT.defaultVersion,
    val operatingSystem: OperatingSystem = OperatingSystem.WIN_10,
    val port: Int = ClientType.QBITTORRENT.defaultPort,
    val presetId: String = "balanced",
    val presetName: String = "Cân Bằng (Balanced)",
    val darkMode: Boolean = true
) {
    fun toJsonObject(): JSONObject = JSONObject().apply {
        put("clientType", clientType.id)
        put("clientVersion", clientVersion)
        put("operatingSystem", operatingSystem.id)
        put("port", port)
        put("presetId", presetId)
        put("presetName", presetName)
        put("darkMode", darkMode)
    }

    companion object {
        fun fromJsonObject(obj: JSONObject?): GlobalConfig {
            if (obj == null) return GlobalConfig()
            val client = ClientType.fromId(obj.optString("clientType", ClientType.QBITTORRENT.id))
            val ver = obj.optString("clientVersion", client.defaultVersion)
                .let { if (it in client.supportedVersions) it else client.defaultVersion }
            val os = OperatingSystem.fromId(obj.optString("operatingSystem", OperatingSystem.WIN_10.id))
            val port = obj.optInt("port", client.defaultPort).coerceIn(1, 65535)
            val presetId = obj.optString("presetId", "balanced").ifBlank { "balanced" }
            val presetName = obj.optString("presetName", "Cân Bằng (Balanced)").ifBlank { "Cân Bằng (Balanced)" }
            val darkMode = obj.optBoolean("darkMode", true)
            return GlobalConfig(
                clientType = client,
                clientVersion = ver,
                operatingSystem = os,
                port = port,
                presetId = presetId,
                presetName = presetName,
                darkMode = darkMode
            )
        }
    }
}

data class AddTorrentOutcome(
    val item: TorrentUiItem,
    val isDuplicate: Boolean
)

data class TorrentUiItem(
    val id: String,
    val name: String,
    val infoHashHex: String,
    val trackerHost: String,
    val primaryTrackerUrl: String,
    val totalSize: Long,
    val fileCount: Int,
    val presetId: String,
    val presetName: String,
    val settings: PresetSettings,
    val clientDisplayName: String,
    val clientVersion: String,
    val operatingSystem: OperatingSystem,
    val port: Int,
    val stats: FakerRuntimeStats,
    val uploadedFormatted: String = FormatUtils.formatBytes(stats.uploadedBytes),
    val downloadedFormatted: String = FormatUtils.formatBytes(stats.downloadedBytes),
    val combinedSpeedKBs: Double = stats.currentUploadRateKBs + stats.currentDownloadRateKBs,
    val speedFormatted: String = FormatUtils.formatSpeedKBs(stats.currentUploadRateKBs + stats.currentDownloadRateKBs),
    val filterCategory: TorrentFilterCategory = computeFilterCategory(stats)
) {
    companion object {
        fun computeFilterCategory(stats: FakerRuntimeStats): TorrentFilterCategory {
            if (!stats.lastError.isNullOrBlank()) {
                return TorrentFilterCategory.ERROR
            }
            return when (stats.state) {
                FakerState.PAUSED -> TorrentFilterCategory.PAUSED
                FakerState.STOPPED, FakerState.STOPPING -> TorrentFilterCategory.STOPPED
                FakerState.STARTING, FakerState.RUNNING -> {
                    if (stats.currentDownloadRateKBs > 0.05 && stats.completionPercent < 100.0) {
                        TorrentFilterCategory.DOWNLOADING
                    } else {
                        TorrentFilterCategory.SEEDING
                    }
                }
            }
        }
    }
}

class RustatioRepository private constructor(
    private val appContext: Context,
    private val db: AppDatabase
) {
    companion object {
        private const val KEY_DEFAULT_PRESET_ID = "default_preset_id"
        private const val KEY_GLOBAL_CONFIG_JSON = "global_config_json"

        @Volatile
        private var INSTANCE: RustatioRepository? = null

        fun getInstance(context: Context): RustatioRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: RustatioRepository(
                    context.applicationContext,
                    AppDatabase.getInstance(context)
                ).also { INSTANCE = it }
            }
        }
    }

    private val dao = db.rustatioDao()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val sessionMutex = Mutex()
    private val activeSessions = LinkedHashMap<String, RatioFakerSession>()

    private val _torrentsState = MutableStateFlow<List<TorrentUiItem>>(emptyList())
    val torrentsState: StateFlow<List<TorrentUiItem>> = _torrentsState.asStateFlow()

    private val _globalConfigState = MutableStateFlow(GlobalConfig())
    val globalConfigState: StateFlow<GlobalConfig> = _globalConfigState.asStateFlow()

    // Dịch vụ lắng nghe cổng TCP trả lời gói bắt tay BitTorrent 68 byte như trên PC
    private val peerListener = PeerListenerService {
        val map = HashMap<String, ByteArray>()
        for (session in activeSessions.values) {
            if (session.isPeerConnectable()) {
                map[session.torrent.infoHashHex] = session.peerIdBytes()
            }
        }
        map
    }

    val customPresetsFlow: Flow<List<Preset>> = dao.observeCustomPresets().map { list ->
        list.map { entity ->
            Preset(
                id = entity.id,
                name = entity.name,
                description = entity.description,
                icon = entity.icon,
                recommended = false,
                custom = true,
                createdAt = entity.createdAt,
                settings = PresetSettings.fromJsonObject(
                    runCatching { JSONObject(entity.settingsJson) }.getOrNull()
                )
            )
        }
    }

    val defaultPresetIdFlow: Flow<String?> = dao.observePreference(KEY_DEFAULT_PRESET_ID)

    val allPresetsFlow: Flow<List<Preset>> = combine(
        customPresetsFlow,
        defaultPresetIdFlow
    ) { customList, _ ->
        BuiltInPresets.all + customList
    }

    init {
        scope.launch {
            hydrateGlobalConfigAndTorrents()
            startInternalSchedulerLoop()
        }
    }

    private suspend fun startInternalSchedulerLoop() {
        while (scope.isActive) {
            try {
                tickAllSessions()
            } catch (_: Exception) {
            }
            delay(1000L)
        }
    }

    private suspend fun resolvePresetById(presetId: String?): Preset {
        val id = presetId ?: "balanced"
        BuiltInPresets.all.firstOrNull { it.id == id }?.let { return it }
        val customEntities = dao.getAllCustomPresetsOnce()
        customEntities.firstOrNull { it.id == id }?.let { entity ->
            return Preset(
                id = entity.id,
                name = entity.name,
                description = entity.description,
                icon = entity.icon,
                recommended = false,
                custom = true,
                createdAt = entity.createdAt,
                settings = PresetSettings.fromJsonObject(
                    runCatching { JSONObject(entity.settingsJson) }.getOrNull()
                )
            )
        }
        return BuiltInPresets.all.first()
    }

    private fun mergePresetWithGlobalConfig(preset: Preset, global: GlobalConfig): PresetSettings {
        return preset.settings.copy(
            selectedClient = global.clientType.id,
            selectedClientVersion = global.clientVersion,
            operatingSystem = global.operatingSystem.id,
            port = global.port.coerceIn(1, 65535)
        )
    }

    private suspend fun hydrateGlobalConfigAndTorrents() {
        sessionMutex.withLock {
            val savedGlobalRaw = dao.getPreferenceOnce(KEY_GLOBAL_CONFIG_JSON)
            val savedDefaultPresetId = dao.getPreferenceOnce(KEY_DEFAULT_PRESET_ID)
            val initialGlobal = if (!savedGlobalRaw.isNullOrBlank()) {
                GlobalConfig.fromJsonObject(runCatching { JSONObject(savedGlobalRaw) }.getOrNull())
            } else {
                val preset = resolvePresetById(savedDefaultPresetId)
                val client = ClientType.fromId(preset.settings.selectedClient)
                val os = OperatingSystem.fromId(preset.settings.operatingSystem)
                GlobalConfig(
                    clientType = client,
                    clientVersion = preset.settings.selectedClientVersion.ifBlank { client.defaultVersion },
                    operatingSystem = os,
                    port = preset.settings.port.coerceIn(1, 65535),
                    presetId = preset.id,
                    presetName = preset.name,
                    darkMode = true
                ).also { cfg ->
                    dao.setPreference(AppPreferenceEntity(KEY_GLOBAL_CONFIG_JSON, cfg.toJsonObject().toString()))
                    dao.setPreference(AppPreferenceEntity(KEY_DEFAULT_PRESET_ID, cfg.presetId))
                }
            }
            _globalConfigState.value = initialGlobal

            val activePreset = resolvePresetById(initialGlobal.presetId)
            val globalSettings = mergePresetWithGlobalConfig(activePreset, initialGlobal)

            val saved = dao.getAllTorrentsOnce()
            for (entity in saved) {
                if (activeSessions.containsKey(entity.id)) continue
                val info = runCatching { TorrentInfo.fromBytes(entity.rawTorrentBytes) }.getOrNull()
                    ?: continue
                val session = RatioFakerSession(
                    instanceId = entity.id,
                    torrent = info,
                    presetId = activePreset.id,
                    presetName = activePreset.name,
                    settings = globalSettings,
                    initialUploadedBytes = entity.cumulativeUploadedBytes,
                    initialDownloadedBytes = entity.cumulativeDownloadedBytes
                )
                activeSessions[entity.id] = session
            }
            publishSnapshotLocked()
        }
    }

    /**
     * Cập nhật Cấu hình Chung (Global Configuration) và đồng bộ ngay lập tức cho tất cả các torrent.
     */
    suspend fun updateGlobalConfig(
        clientType: ClientType = _globalConfigState.value.clientType,
        clientVersion: String = _globalConfigState.value.clientVersion,
        operatingSystem: OperatingSystem = _globalConfigState.value.operatingSystem,
        port: Int = _globalConfigState.value.port,
        preset: Preset? = null,
        darkMode: Boolean = _globalConfigState.value.darkMode
    ): GlobalConfig {
        val activePreset = preset ?: resolvePresetById(_globalConfigState.value.presetId)
        val validVersion = if (clientVersion in clientType.supportedVersions) {
            clientVersion
        } else {
            clientType.defaultVersion
        }
        val validPort = port.coerceIn(1, 65535)
        val updatedGlobal = GlobalConfig(
            clientType = clientType,
            clientVersion = validVersion,
            operatingSystem = operatingSystem,
            port = validPort,
            presetId = activePreset.id,
            presetName = activePreset.name,
            darkMode = darkMode
        )

        val runningSessionsToReannounce = mutableListOf<RatioFakerSession>()

        sessionMutex.withLock {
            _globalConfigState.value = updatedGlobal
            dao.setPreference(AppPreferenceEntity(KEY_GLOBAL_CONFIG_JSON, updatedGlobal.toJsonObject().toString()))
            dao.setPreference(AppPreferenceEntity(KEY_DEFAULT_PRESET_ID, activePreset.id))

            val mergedSettings = mergePresetWithGlobalConfig(activePreset, updatedGlobal)
            val mergedJson = mergedSettings.toJsonObject().toString()

            var anyConnectable = false
            for (session in activeSessions.values) {
                session.updateConfiguration(activePreset.id, activePreset.name, mergedSettings)
                if (session.isPeerConnectable()) {
                    anyConnectable = true
                }
                if (session.stats.state == FakerState.RUNNING || session.stats.state == FakerState.STARTING) {
                    runningSessionsToReannounce.add(session)
                }
                dao.updateTorrentSettings(
                    id = session.instanceId,
                    presetId = activePreset.id,
                    presetName = activePreset.name,
                    settingsJson = mergedJson
                )
            }
            if (anyConnectable) {
                peerListener.ensureListening(validPort)
            }
            publishSnapshotLocked()
        }

        // Gửi Announce cập nhật lập tức tới Tracker cho toàn bộ torrent đang chạy
        for (session in runningSessionsToReannounce) {
            scope.launch {
                try {
                    session.reannounceWithUpdatedConfig()
                    sessionMutex.withLock {
                        publishSnapshotLocked()
                    }
                } catch (_: Exception) {
                }
            }
        }
        return updatedGlobal
    }

    suspend fun setDefaultPreset(presetId: String) {
        val preset = resolvePresetById(presetId)
        updateGlobalConfig(preset = preset)
    }

    suspend fun clearDefaultPreset() {
        val balanced = BuiltInPresets.all.first()
        updateGlobalConfig(preset = balanced)
    }

    /**
     * Thêm tệp .torrent thực tế với Cấu hình Chung (Global Configuration) hiện tại,
     * đồng thời ngăn chặn thêm trùng lặp dựa trên InfoHash.
     */
    suspend fun addRealTorrentWithGlobalConfig(
        rawBytes: ByteArray,
        autoStart: Boolean = true
    ): Result<AddTorrentOutcome> {
        return runCatching {
            val info = TorrentInfo.fromBytes(rawBytes)
            val id = info.infoHashHex
            val global = _globalConfigState.value
            val activePreset = resolvePresetById(global.presetId)
            val mergedSettings = mergePresetWithGlobalConfig(activePreset, global)

            val outcome = sessionMutex.withLock {
                val existing = activeSessions[id]
                if (existing != null) {
                    return@withLock AddTorrentOutcome(
                        item = existing.toUiItem(),
                        isDuplicate = true
                    )
                }

                val session = RatioFakerSession(
                    instanceId = id,
                    torrent = info,
                    presetId = activePreset.id,
                    presetName = activePreset.name,
                    settings = mergedSettings,
                    initialUploadedBytes = 0L,
                    initialDownloadedBytes = 0L
                )
                activeSessions[id] = session

                dao.upsertTorrent(
                    TorrentEntity(
                        id = id,
                        infoHashHex = info.infoHashHex,
                        name = info.name,
                        totalSize = info.totalSize,
                        rawTorrentBytes = rawBytes,
                        presetId = activePreset.id,
                        presetName = activePreset.name,
                        settingsJson = mergedSettings.toJsonObject().toString(),
                        cumulativeUploadedBytes = 0L,
                        cumulativeDownloadedBytes = 0L,
                        addedAtMs = System.currentTimeMillis()
                    )
                )
                publishSnapshotLocked()
                AddTorrentOutcome(
                    item = session.toUiItem(),
                    isDuplicate = false
                )
            }

            if (!outcome.isDuplicate && autoStart) {
                scope.launch {
                    startTorrent(id)
                }
            }
            outcome
        }
    }

    /**
     * Giữ tương thích với các lệnh gọi truyền trực tiếp cấu hình.
     */
    suspend fun addRealTorrent(
        rawBytes: ByteArray,
        chosenPreset: Preset = BuiltInPresets.all.first(),
        clientType: ClientType = _globalConfigState.value.clientType,
        clientVersion: String = _globalConfigState.value.clientVersion,
        port: Int = _globalConfigState.value.port,
        operatingSystem: OperatingSystem = _globalConfigState.value.operatingSystem,
        autoStart: Boolean = true
    ): Result<TorrentUiItem> {
        updateGlobalConfig(
            clientType = clientType,
            clientVersion = clientVersion,
            operatingSystem = operatingSystem,
            port = port,
            preset = chosenPreset
        )
        return addRealTorrentWithGlobalConfig(rawBytes = rawBytes, autoStart = autoStart)
            .map { it.item }
    }

    suspend fun startTorrent(id: String) {
        val session = sessionMutex.withLock { activeSessions[id] } ?: return
        peerListener.ensureListening(session.settings.port)
        TrackerForegroundService.ensureRunning(appContext)

        session.start()

        sessionMutex.withLock {
            dao.updateTorrentTraffic(id, session.stats.uploadedBytes, session.stats.downloadedBytes)
            publishSnapshotLocked()
        }
    }

    suspend fun pauseOrResumeTorrent(id: String) {
        sessionMutex.withLock {
            val session = activeSessions[id] ?: return
            when (session.stats.state) {
                FakerState.RUNNING, FakerState.STARTING -> session.pause()
                FakerState.PAUSED -> {
                    peerListener.ensureListening(session.settings.port)
                    TrackerForegroundService.ensureRunning(appContext)
                    session.resume()
                }
                else -> {}
            }
            publishSnapshotLocked()
        }
    }

    suspend fun pauseTorrent(id: String) {
        sessionMutex.withLock {
            val session = activeSessions[id] ?: return
            if (session.stats.state == FakerState.RUNNING || session.stats.state == FakerState.STARTING) {
                session.pause()
                publishSnapshotLocked()
            }
        }
    }

    suspend fun stopTorrent(id: String) {
        val session = sessionMutex.withLock { activeSessions[id] } ?: return
        session.stop()
        sessionMutex.withLock {
            dao.updateTorrentTraffic(id, session.stats.uploadedBytes, session.stats.downloadedBytes)
            publishSnapshotLocked()
            val anyConnectable = activeSessions.values.any { it.isPeerConnectable() }
            if (!anyConnectable) {
                peerListener.stop()
            }
        }
    }

    suspend fun startAllTorrents() {
        val ids = sessionMutex.withLock { activeSessions.keys.toList() }
        if (ids.isEmpty()) return
        TrackerForegroundService.ensureRunning(appContext)
        for (id in ids) {
            scope.launch {
                startTorrent(id)
            }
        }
    }

    suspend fun pauseAllTorrents() {
        sessionMutex.withLock {
            activeSessions.values.forEach { session ->
                if (session.stats.state == FakerState.RUNNING || session.stats.state == FakerState.STARTING) {
                    session.pause()
                }
            }
            publishSnapshotLocked()
        }
    }

    suspend fun stopAllTorrents() {
        val ids = sessionMutex.withLock { activeSessions.keys.toList() }
        for (id in ids) {
            stopTorrent(id)
        }
    }

    suspend fun deleteTorrent(id: String) {
        val session = sessionMutex.withLock { activeSessions.remove(id) }
        if (session != null && (session.stats.state == FakerState.RUNNING || session.stats.state == FakerState.PAUSED)) {
            runCatching { session.stop() }
        }
        sessionMutex.withLock {
            dao.deleteTorrentById(id)
            publishSnapshotLocked()
        }
    }

    /**
     * Áp dụng một Preset làm Cấu hình Chung cho toàn bộ danh sách Torrent.
     */
    suspend fun applyPresetToTorrents(preset: Preset, targetTorrentId: String? = null): Int {
        updateGlobalConfig(preset = preset)
        return sessionMutex.withLock {
            activeSessions.size
        }
    }

    suspend fun saveCustomPreset(
        name: String,
        description: String,
        settings: PresetSettings,
        existingId: String? = null
    ): Preset {
        val cleanName = name.trim().ifEmpty { "Preset Tùy Chỉnh" }
        val cleanDesc = description.trim().ifEmpty {
            "Tốc độ ↑ ${settings.uploadRate.toInt()} KB/s · ↓ ${settings.downloadRate.toInt()} KB/s"
        }
        val id = existingId ?: "custom-${System.currentTimeMillis()}"
        val nowIso = Preset.currentIsoTimestamp()
        val entity = CustomPresetEntity(
            id = id,
            name = cleanName,
            description = cleanDesc,
            icon = "star",
            createdAt = nowIso,
            settingsJson = settings.toJsonObject().toString(),
            updatedAtMs = System.currentTimeMillis()
        )
        dao.upsertCustomPreset(entity)

        val savedPreset = Preset(
            id = id,
            name = cleanName,
            description = cleanDesc,
            icon = "star",
            recommended = false,
            custom = true,
            createdAt = nowIso,
            settings = settings
        )

        if (_globalConfigState.value.presetId == id) {
            updateGlobalConfig(preset = savedPreset)
        }
        return savedPreset
    }

    suspend fun duplicatePreset(source: Preset): Preset {
        val copyName = "${source.name} (Bản sao)"
        return saveCustomPreset(
            name = copyName,
            description = source.description,
            settings = source.settings,
            existingId = null
        )
    }

    suspend fun deleteCustomPreset(id: String) {
        dao.deleteCustomPresetById(id)
        if (_globalConfigState.value.presetId == id) {
            clearDefaultPreset()
        }
    }

    suspend fun importPresetsFromJson(jsonContent: String): Result<Int> {
        return runCatching {
            val imported = Preset.parseImportedJson(jsonContent)
            for (preset in imported) {
                dao.upsertCustomPreset(
                    CustomPresetEntity(
                        id = preset.id,
                        name = preset.name,
                        description = preset.description,
                        icon = preset.icon,
                        createdAt = preset.createdAt ?: Preset.currentIsoTimestamp(),
                        settingsJson = preset.settings.toJsonObject().toString(),
                        updatedAtMs = System.currentTimeMillis()
                    )
                )
            }
            imported.size
        }
    }

    fun exportAllCustomPresetsJson(customPresets: List<Preset>): String {
        if (customPresets.size == 1) {
            return customPresets.first().toExportJsonString()
        }
        val arr = JSONArray()
        for (p in customPresets) {
            arr.put(JSONObject(p.toExportJsonString()))
        }
        return JSONObject().apply {
            put("version", 1)
            put("type", "rustatio-preset-bundle")
            put("exportedAt", Preset.currentIsoTimestamp())
            put("presets", arr)
        }.toString(2)
    }

    suspend fun tickAllSessions(): Boolean {
        val sessions = sessionMutex.withLock { activeSessions.values.toList() }
        if (sessions.isEmpty()) return false

        val toDelete = mutableListOf<String>()
        var anyActive = false

        for (session in sessions) {
            val shouldDelete = session.tick()
            if (shouldDelete) {
                toDelete.add(session.instanceId)
            } else if (
                session.stats.state == FakerState.RUNNING ||
                session.stats.state == FakerState.STARTING ||
                session.stats.state == FakerState.PAUSED
            ) {
                anyActive = true
            }
        }

        sessionMutex.withLock {
            for (delId in toDelete) {
                activeSessions.remove(delId)
                dao.deleteTorrentById(delId)
            }
            for (session in activeSessions.values) {
                if (session.stats.state == FakerState.RUNNING && session.stats.elapsedTimeSecs % 5L == 0L) {
                    dao.updateTorrentTraffic(
                        session.instanceId,
                        session.stats.uploadedBytes,
                        session.stats.downloadedBytes
                    )
                }
            }
            publishSnapshotLocked()
        }

        return anyActive
    }

    /**
     * Chỉ sử dụng trong môi trường kiểm thử Robolectric (Stage 4) để kiểm tra hiệu năng
     * danh sách 500 Torrent mà không làm ảnh hưởng đến dữ liệu thực tế của ứng dụng.
     */
    @VisibleForTesting
    suspend fun seedSyntheticTorrentsForTest(count: Int, initialState: FakerState = FakerState.STOPPED) {
        val global = _globalConfigState.value
        val activePreset = resolvePresetById(global.presetId)
        val mergedSettings = mergePresetWithGlobalConfig(activePreset, global)

        sessionMutex.withLock {
            activeSessions.clear()
            for (i in 1..count) {
                val hashHex = "%040x".format(i)
                val hashBytes = ByteArray(20) { idx -> ((i + idx) and 0xFF).toByte() }
                val info = TorrentInfo(
                    infoHash = hashBytes,
                    infoHashHex = hashHex,
                    announce = "https://tracker.rustatio.test/announce",
                    announceList = listOf(listOf("https://tracker.rustatio.test/announce")),
                    name = "Ubuntu-24.04-Server-Release-Build-%03d.iso".format(i),
                    totalSize = 4_294_967_296L + (i * 10_485_760L),
                    pieceLength = 262_144L,
                    numPieces = 16384,
                    creationDate = 1710000000L,
                    comment = null,
                    createdBy = "mktorrent",
                    isSingleFile = true,
                    fileCount = 1,
                    files = emptyList()
                )
                val upBytes = (i.toLong() * 52_428_800L) // i * 50 MB
                val downBytes = (i.toLong() * 104_857_600L) // i * 100 MB
                val session = RatioFakerSession(
                    instanceId = hashHex,
                    torrent = info,
                    presetId = activePreset.id,
                    presetName = activePreset.name,
                    settings = mergedSettings,
                    initialUploadedBytes = upBytes,
                    initialDownloadedBytes = downBytes
                )
                if (initialState != FakerState.STOPPED) {
                    session.stats = session.stats.copy(state = initialState)
                }
                activeSessions[hashHex] = session
            }
            publishSnapshotLocked()
        }
    }

    private fun publishSnapshotLocked() {
        _torrentsState.value = activeSessions.values.map { it.toUiItem() }
    }

    private fun RatioFakerSession.toUiItem(): TorrentUiItem {
        val clientType = ClientType.fromId(settings.selectedClient)
        val os = OperatingSystem.fromId(settings.operatingSystem)
        val ver = settings.selectedClientVersion.ifBlank { clientType.defaultVersion }
        val currentStats = stats
        val combinedSpeed = currentStats.currentUploadRateKBs + currentStats.currentDownloadRateKBs
        return TorrentUiItem(
            id = instanceId,
            name = torrent.name,
            infoHashHex = torrent.infoHashHex,
            trackerHost = torrent.trackerHost(),
            primaryTrackerUrl = torrent.announce,
            totalSize = torrent.totalSize,
            fileCount = torrent.fileCount,
            presetId = presetId,
            presetName = presetName,
            settings = settings,
            clientDisplayName = clientType.displayName,
            clientVersion = ver,
            operatingSystem = os,
            port = settings.port,
            stats = currentStats,
            uploadedFormatted = FormatUtils.formatBytes(currentStats.uploadedBytes),
            downloadedFormatted = FormatUtils.formatBytes(currentStats.downloadedBytes),
            combinedSpeedKBs = combinedSpeed,
            speedFormatted = FormatUtils.formatSpeedKBs(combinedSpeed),
            filterCategory = TorrentUiItem.computeFilterCategory(currentStats)
        )
    }
}
