package com.example.core.torrent

import kotlin.random.Random

enum class OperatingSystem(
    val id: String,
    val displayName: String,
    val shortBadge: String,
    val ntSignature: String,
    val platformVersion: String,
    val buildLabel: String
) {
    WINDOWS_7(
        id = "win7",
        displayName = "Windows 7 SP1 (64-bit)",
        shortBadge = "Windows 7",
        ntSignature = "Windows NT 6.1; Win64; x64",
        platformVersion = "6.1.0",
        buildLabel = "NT 6.1 · Build 7601"
    ),
    WINDOWS_10(
        id = "win10",
        displayName = "Windows 10 Pro 22H2",
        shortBadge = "Windows 10",
        ntSignature = "Windows NT 10.0; Win64; x64",
        platformVersion = "10.0.0",
        buildLabel = "NT 10.0 · Build 19045"
    ),
    WINDOWS_12(
        id = "win12",
        displayName = "Windows 12 Enterprise",
        shortBadge = "Windows 12",
        ntSignature = "Windows NT 12.0; Win64; x64",
        platformVersion = "12.0.0",
        buildLabel = "NT 12.0 · Build 27500"
    );

    val ntToken: String get() = ntSignature

    companion object {
        val WIN_7: OperatingSystem get() = WINDOWS_7
        val WIN_10: OperatingSystem get() = WINDOWS_10
        val WIN_12: OperatingSystem get() = WINDOWS_12

        fun fromId(id: String?): OperatingSystem {
            return entries.firstOrNull {
                it.id.equals(id, ignoreCase = true) || it.name.equals(id, ignoreCase = true)
            } ?: WINDOWS_10
        }
    }
}

enum class ClientType(
    val id: String,
    val displayName: String,
    val defaultVersion: String,
    val versions: List<String>,
    val defaultPort: Int,
    val numWant: Int,
    val supportsCrypto: Boolean
) {
    QBITTORRENT(
        id = "qbittorrent",
        displayName = "qBittorrent",
        defaultVersion = "5.3.0",
        versions = listOf(
            "5.3.0", "5.2.4", "5.2.3", "5.2.2", "5.2.1", "5.2.0",
            "5.1.4", "5.1.3", "5.0.2", "4.6.7", "4.5.5", "4.4.5"
        ),
        defaultPort = 6881,
        numWant = 200,
        supportsCrypto = true
    ),
    UTORRENT(
        id = "utorrent",
        displayName = "uTorrent",
        defaultVersion = "3.5.5",
        versions = listOf("3.5.5", "3.5.4", "3.5.3", "3.4.9", "3.4.8", "2.2.1"),
        defaultPort = 6881,
        numWant = 200,
        supportsCrypto = true
    ),
    TRANSMISSION(
        id = "transmission",
        displayName = "Transmission",
        defaultVersion = "4.1.4",
        versions = listOf(
            "4.1.4", "4.1.3", "4.1.2", "4.1.1", "4.1.0",
            "4.0.6", "4.0.5", "4.0.4", "4.0.3", "3.00", "2.94", "2.93"
        ),
        defaultPort = 51413,
        numWant = 80,
        supportsCrypto = false
    ),
    DELUGE(
        id = "deluge",
        displayName = "Deluge",
        defaultVersion = "2.2.0",
        versions = listOf("2.2.0", "2.1.1", "2.0.5", "2.0.3", "1.3.15"),
        defaultPort = 6881,
        numWant = 200,
        supportsCrypto = true
    ),
    BITTORRENT(
        id = "bittorrent",
        displayName = "BitTorrent",
        defaultVersion = "7.11.0",
        versions = listOf(
            "7.11.0", "7.10.5", "7.10.4", "7.10.3",
            "7.10.0", "7.9.9", "7.9.8", "7.9.7"
        ),
        defaultPort = 6881,
        numWant = 200,
        supportsCrypto = true
    ),
    RTORRENT(
        id = "rtorrent",
        displayName = "rTorrent",
        defaultVersion = "0.16.26",
        versions = listOf(
            "0.16.26", "0.16.25", "0.16.24", "0.16.23", "0.16.22",
            "0.16.21", "0.16.20", "0.16.19", "0.16.18", "0.16.17",
            "0.16.16", "0.16.15", "0.16.14", "0.16.13", "0.16.12",
            "0.16.11", "0.16.10", "0.16.9", "0.16.8", "0.16.7",
            "0.16.6", "0.16.5", "0.16.4", "0.16.2", "0.16.1",
            "0.16.0", "0.15.7", "0.15.6", "0.15.5", "0.15.4",
            "0.15.3", "0.15.2", "0.15.1", "0.15.0", "0.10.0",
            "0.9.8", "0.9.7", "0.9.6"
        ),
        defaultPort = 6881,
        numWant = 50,
        supportsCrypto = true
    );

    val supportedVersions: List<String> get() = versions

    companion object {
        fun fromId(id: String?): ClientType {
            return entries.firstOrNull {
                it.id.equals(id, ignoreCase = true) || it.name.equals(id, ignoreCase = true)
            } ?: QBITTORRENT
        }
    }
}

data class ClientConfig(
    val clientType: ClientType,
    val version: String,
    val operatingSystem: OperatingSystem,
    val peerIdPrefix: String,
    val userAgent: String,
    val osHeaderValue: String,
    val numWant: Int,
    val supportsCompact: Boolean = true,
    val supportsCrypto: Boolean = true
) {
    val httpUserAgent: String get() = userAgent
    val secondaryOsHeaderValue: String get() = osHeaderValue

    fun generatePeerId(): String {
        val chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
        val suffix = buildString(12) {
            repeat(12) {
                append(chars[Random.nextInt(chars.length)])
            }
        }
        return "$peerIdPrefix$suffix".take(20)
    }

    companion object {
        fun build(
            type: ClientType,
            version: String,
            port: Int = type.defaultPort,
            os: OperatingSystem = OperatingSystem.WINDOWS_10
        ): ClientConfig = create(type, version, os)

        fun generateKey(): String {
            val hex = "0123456789ABCDEF"
            return buildString(8) {
                repeat(8) {
                    append(hex[Random.nextInt(16)])
                }
            }
        }

        fun create(
            clientType: ClientType,
            customVersion: String? = null,
            operatingSystem: OperatingSystem = OperatingSystem.WINDOWS_10
        ): ClientConfig {
            val ver = customVersion?.takeIf { it.isNotBlank() && clientType.versions.contains(it) }
                ?: customVersion?.takeIf { it.isNotBlank() }
                ?: clientType.defaultVersion

            val prefix = when (clientType) {
                ClientType.UTORRENT -> {
                    val code = ver.replace(".", "").padOrTrim4()
                    "-UT$code-"
                }
                ClientType.QBITTORRENT -> {
                    val parts = ver.split(".")
                    val code = if (parts.size >= 3) "${parts[0]}${parts[1]}${parts[2]}" else "514"
                    "-qB${code.padOrTrim4()}-"
                }
                ClientType.TRANSMISSION -> {
                    val parts = ver.split(".")
                    val code = if (parts.size >= 2) "${parts[0]}${parts[1].padOrTrim(2)}" else "400"
                    "-TR${code.padOrTrim4()}-"
                }
                ClientType.DELUGE -> {
                    val parts = ver.split(".")
                    val code = if (parts.size >= 3) "${parts[0]}${parts[1]}${parts[2]}" else "211"
                    "-DE${code.padOrTrim4()}-"
                }
                ClientType.BITTORRENT -> {
                    val parts = ver.split(".")
                    val code = if (parts.size >= 3) "${parts[0]}${parts[1]}${parts[2]}" else "7110"
                    "-BT${code.padOrTrim4()}-"
                }
                ClientType.RTORRENT -> {
                    val parts = ver.split(".")
                    val code = if (parts.size >= 3) "${parts[0]}${parts[1]}${parts[2]}" else "0161"
                    "-RT${code.padOrTrim4()}-"
                }
            }

            // Chuỗi User-Agent chuẩn gốc 100% như rustatio-core trên PC để vượt Whitelist Private Tracker
            val exactPcUserAgent = when (clientType) {
                ClientType.UTORRENT -> "uTorrent/$ver"
                ClientType.QBITTORRENT -> "qBittorrent/$ver"
                ClientType.TRANSMISSION -> "Transmission/$ver"
                ClientType.DELUGE -> "Deluge/$ver"
                ClientType.BITTORRENT -> "BitTorrent/$ver"
                ClientType.RTORRENT -> "rTorrent/$ver"
            }

            return ClientConfig(
                clientType = clientType,
                version = ver,
                operatingSystem = operatingSystem,
                peerIdPrefix = prefix,
                userAgent = exactPcUserAgent,
                osHeaderValue = operatingSystem.ntSignature,
                numWant = clientType.numWant,
                supportsCompact = true,
                supportsCrypto = clientType.supportsCrypto
            )
        }

        private fun String.padOrTrim4(): String = padOrTrim(4)

        private fun String.padOrTrim(width: Int): String {
            return if (length >= width) substring(0, width)
            else this + "0".repeat(width - length)
        }
    }
}
