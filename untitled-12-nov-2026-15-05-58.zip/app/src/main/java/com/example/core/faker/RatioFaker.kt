package com.example.core.faker

import com.example.core.presets.PostStopAction
import com.example.core.presets.PresetSettings
import com.example.core.protocol.AnnounceRequest
import com.example.core.protocol.TrackerClient
import com.example.core.protocol.TrackerEvent
import com.example.core.protocol.TrackerException
import com.example.core.torrent.ClientConfig
import com.example.core.torrent.ClientType
import com.example.core.torrent.OperatingSystem
import com.example.core.torrent.TorrentInfo
import java.nio.charset.StandardCharsets
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

enum class FakerState(val labelVi: String) {
    STOPPED("Đã dừng"),
    STARTING("Đang kết nối..."),
    RUNNING("Đang chạy"),
    PAUSED("Tạm dừng"),
    STOPPING("Đang dừng...")
}

data class FakerRuntimeStats(
    val state: FakerState = FakerState.STOPPED,
    val uploadedBytes: Long = 0L,
    val downloadedBytes: Long = 0L,
    val leftBytes: Long = 0L,
    val sessionUploadedBytes: Long = 0L,
    val sessionDownloadedBytes: Long = 0L,
    val currentUploadRateKBs: Double = 0.0,
    val currentDownloadRateKBs: Double = 0.0,
    val ratio: Double = 0.0,
    val sessionRatio: Double = 0.0,
    val completionPercent: Double = 100.0,
    val seeders: Int = 0,
    val leechers: Int = 0,
    val elapsedTimeSecs: Long = 0L,
    val announceCount: Int = 0,
    val lastAnnounceMs: Long? = null,
    val nextAnnounceMs: Long? = null,
    val announceIntervalSecs: Long = 1800L,
    val isIdling: Boolean = false,
    val idlingReason: String? = null,
    val stopConditionMet: Boolean = false,
    val trackerError: String? = null,
    val trackerWarning: String? = null,
    val trackerRetryAttempt: Int = 0,
    val trackerRetryAtMs: Long? = null,
    val peerId: String = "",
    val keyHex: String = "",
    val userAgent: String = "",
    val osHeader: String = ""
) {
    val lastError: String? get() = trackerError
    val nextAnnounceInSecs: Long get() = (nextAnnounceMs?.let { (it - System.currentTimeMillis()) / 1000L } ?: 0L).coerceAtLeast(0L)
}

/**
 * Chuyển đổi nguyên bản 1:1 từ rustatio-core/src/faker.rs.
 * Đồng bộ hoàn toàn cách tính uploaded, downloaded, left, ratio và cơ chế tự động
 * duy trì phiên chạy + thử lại Tracker theo chu kỳ 30s -> 60s -> 120s -> 300s.
 */
class RatioFakerSession(
    val instanceId: String,
    val torrent: TorrentInfo,
    var presetId: String,
    var presetName: String,
    var settings: PresetSettings,
    initialUploadedBytes: Long = 0L,
    initialDownloadedBytes: Long = 0L,
    private val trackerClient: TrackerClient = TrackerClient()
) {
    companion object {
        private val TRACKER_RETRY_SCHEDULE_SECS = longArrayOf(30L, 60L, 120L, 300L)
    }

    var clientConfig: ClientConfig = buildClientConfig(settings)
        private set

    var peerId: String = clientConfig.generatePeerId()
        private set

    private var keyHex: String = ClientConfig.generateKey()
    private var trackerId: String? = null

    private var lastTickMs: Long = System.currentTimeMillis()
    private var lastScrapeMs: Long = 0L
    private var scrapeSupported: Boolean = true
    private var effectiveStopRatio: Double? = computeEffectiveStopRatio(settings)

    var stats: FakerRuntimeStats = createInitialStats(initialUploadedBytes, initialDownloadedBytes)
        internal set

    fun isPeerConnectable(): Boolean {
        return stats.state == FakerState.RUNNING || stats.state == FakerState.PAUSED
    }

    fun peerIdBytes(): ByteArray {
        return peerId.toByteArray(StandardCharsets.ISO_8859_1).copyOf(20)
    }

    private fun buildClientConfig(cfg: PresetSettings): ClientConfig {
        val type = ClientType.fromId(cfg.selectedClient)
        val os = OperatingSystem.fromId(cfg.operatingSystem)
        return ClientConfig.create(type, cfg.selectedClientVersion, os)
    }

    private fun computeEffectiveStopRatio(cfg: PresetSettings): Double? {
        if (!cfg.stopAtRatioEnabled) return null
        val base = cfg.stopAtRatio
        if (!cfg.randomizeRatio) return base
        val range = (cfg.randomRatioRangePercent.coerceIn(0.0, 100.0)) / 100.0
        val factor = 1.0 + (Random.nextDouble(-1.0, 1.0) * range)
        return kotlin.math.round(base * factor * 10000.0) / 10000.0
    }

    /**
     * Khởi tạo đúng chuẩn rustatio-core/src/faker.rs (dòng 599-620):
     * - uploaded = initial_uploaded (mặc định 0)
     * - downloaded = initial_downloaded (mặc định 0)
     * - left = total_size - (total_size * completion_percent / 100.0)
     * - ratio = uploaded / total_size
     */
    private fun createInitialStats(initUp: Long, initDown: Long): FakerRuntimeStats {
        val completion = settings.completionPercent.coerceIn(0.0, 100.0) / 100.0
        val torrentDownloaded = (torrent.totalSize.toDouble() * completion).toLong()
        val initialLeft = (torrent.totalSize - torrentDownloaded).coerceAtLeast(0L)
        val torrentCompletion = if (torrent.totalSize > 0L) {
            ((torrent.totalSize - initialLeft).toDouble() / torrent.totalSize.toDouble()) * 100.0
        } else {
            100.0
        }
        val ratioVal = if (torrent.totalSize > 0L) {
            initUp.toDouble() / torrent.totalSize.toDouble()
        } else {
            0.0
        }
        return FakerRuntimeStats(
            state = FakerState.STOPPED,
            uploadedBytes = initUp,
            downloadedBytes = initDown,
            leftBytes = initialLeft,
            completionPercent = torrentCompletion,
            ratio = ratioVal,
            peerId = peerId,
            keyHex = keyHex,
            userAgent = clientConfig.userAgent,
            osHeader = clientConfig.osHeaderValue
        )
    }

    fun updateConfiguration(
        newPresetId: String,
        newPresetName: String,
        newSettings: PresetSettings
    ) {
        presetId = newPresetId
        presetName = newPresetName
        settings = newSettings
        clientConfig = buildClientConfig(newSettings)
        effectiveStopRatio = computeEffectiveStopRatio(newSettings)
        
        // Luôn tái tạo Peer-ID chuẩn xác với Client mới (tiền tố -qB, -UT, -TR, -DE, -BT, -RT)
        peerId = clientConfig.generatePeerId()
        keyHex = ClientConfig.generateKey()

        val completion = newSettings.completionPercent.coerceIn(0.0, 100.0) / 100.0
        val torrentDownloaded = (torrent.totalSize.toDouble() * completion).toLong()
        val newLeft = if (stats.leftBytes == 0L && stats.sessionDownloadedBytes > 0L) {
            0L
        } else {
            (torrent.totalSize - torrentDownloaded).coerceAtLeast(0L)
        }
        val newCompletion = if (torrent.totalSize > 0L) {
            ((torrent.totalSize - newLeft).toDouble() / torrent.totalSize.toDouble()) * 100.0
        } else {
            100.0
        }
        stats = stats.copy(
            leftBytes = newLeft,
            completionPercent = newCompletion,
            peerId = peerId,
            keyHex = keyHex,
            userAgent = clientConfig.userAgent,
            osHeader = clientConfig.osHeaderValue
        )
    }

    /**
     * Gửi bản tin Announce cập nhật tới Tracker ngay khi thay đổi Client, Version, OS hoặc Port.
     */
    suspend fun reannounceWithUpdatedConfig() {
        if (stats.state != FakerState.RUNNING && stats.state != FakerState.STARTING) return
        performPeriodicAnnounce()
    }

    /**
     * Khởi chạy phiên giả lập tỷ lệ (begin_start + apply_start_result từ rustatio-core):
     * - Đặt trạng thái sang STARTING, tính ngay tốc độ khởi điểm để phản hồi tức thì trên UI
     * - Gửi gói tin event=started tới Tracker
     * - Nếu thành công: cập nhật Seeders, Leechers, Interval và chuyển sang RUNNING
     * - Nếu lỗi mạng/timeout tạm thời: vẫn giữ trạng thái RUNNING như rustatio-core (dòng 838-845)
     *   và hẹn thử lại Announce sau 30 giây, chỉ dừng hẳn nếu Tracker báo Torrent không tồn tại.
     */
    suspend fun start() {
        if (stats.state == FakerState.RUNNING || stats.state == FakerState.STARTING) return

        peerId = clientConfig.generatePeerId()
        keyHex = ClientConfig.generateKey()
        trackerId = null
        effectiveStopRatio = computeEffectiveStopRatio(settings)

        val now = System.currentTimeMillis()
        lastTickMs = now
        lastScrapeMs = now

        val initialUpRate = calculateEffectiveRate(
            baseRate = settings.uploadRate,
            targetRate = settings.targetUploadRate,
            elapsedSecs = 0L
        )
        val initialDownRate = if (stats.leftBytes <= 0L) 0.0 else calculateEffectiveRate(
            baseRate = settings.downloadRate,
            targetRate = settings.targetDownloadRate,
            elapsedSecs = 0L
        )

        stats = stats.copy(
            state = FakerState.STARTING,
            sessionUploadedBytes = 0L,
            sessionDownloadedBytes = 0L,
            sessionRatio = 0.0,
            elapsedTimeSecs = 0L,
            currentUploadRateKBs = initialUpRate,
            currentDownloadRateKBs = initialDownRate,
            stopConditionMet = false,
            isIdling = false,
            idlingReason = null,
            trackerError = null,
            trackerWarning = null,
            trackerRetryAttempt = 0,
            trackerRetryAtMs = null,
            peerId = peerId,
            keyHex = keyHex,
            userAgent = clientConfig.userAgent,
            osHeader = clientConfig.osHeaderValue
        )

        val req = buildAnnounceRequest(TrackerEvent.STARTED)
        try {
            val resp = trackerClient.announce(torrent.getAllTrackerUrls(), req, clientConfig)
            val intervalSecs = resp.interval.coerceAtLeast(30L)
            trackerId = resp.trackerId
            val doneTime = System.currentTimeMillis()
            lastTickMs = doneTime
            stats = stats.copy(
                state = FakerState.RUNNING,
                seeders = resp.complete,
                leechers = resp.incomplete,
                announceIntervalSecs = intervalSecs,
                lastAnnounceMs = doneTime,
                nextAnnounceMs = doneTime + intervalSecs * 1000L,
                announceCount = stats.announceCount + 1,
                trackerWarning = resp.warning,
                trackerError = null,
                trackerRetryAttempt = 0,
                trackerRetryAtMs = null
            )
        } catch (e: TrackerException) {
            applyStartFailure(e)
        } catch (e: Exception) {
            applyStartFailure(TrackerException(e.message ?: "Tracker phản hồi chậm"))
        }
    }

    private fun applyStartFailure(error: TrackerException) {
        val now = System.currentTimeMillis()
        lastTickMs = now
        if (error.isMissingTorrent) {
            stats = stats.copy(
                state = FakerState.STOPPED,
                currentUploadRateKBs = 0.0,
                currentDownloadRateKBs = 0.0,
                trackerError = "Torrent không tồn tại trên Tracker (${error.message})",
                trackerRetryAttempt = 0,
                trackerRetryAtMs = null,
                nextAnnounceMs = null
            )
        } else {
            // Giữ phiên ở trạng thái RUNNING như rustatio-core (dòng 838-845) và tự động gửi lại Announce sau 30s
            val nextAttempt = stats.trackerRetryAttempt + 1
            val delaySecs = getRetryDelaySecs(nextAttempt)
            stats = stats.copy(
                state = FakerState.RUNNING,
                announceIntervalSecs = delaySecs,
                nextAnnounceMs = now + delaySecs * 1000L,
                trackerRetryAttempt = nextAttempt,
                trackerRetryAtMs = now + delaySecs * 1000L,
                trackerError = null,
                trackerWarning = "Chờ Tracker phản hồi (${error.message}) · Thử lại sau ${delaySecs}s"
            )
        }
    }

    fun pause() {
        if (stats.state != FakerState.RUNNING && stats.state != FakerState.STARTING) return
        stats = stats.copy(
            state = FakerState.PAUSED,
            currentUploadRateKBs = 0.0,
            currentDownloadRateKBs = 0.0,
            isIdling = false,
            idlingReason = null
        )
    }

    fun resume() {
        if (stats.state != FakerState.PAUSED) return
        lastTickMs = System.currentTimeMillis()
        stats = stats.copy(state = FakerState.RUNNING)
    }

    suspend fun stop() {
        if (stats.state == FakerState.STOPPED || stats.state == FakerState.STOPPING) return
        stats = stats.copy(
            state = FakerState.STOPPING,
            currentUploadRateKBs = 0.0,
            currentDownloadRateKBs = 0.0
        )
        val req = buildAnnounceRequest(TrackerEvent.STOPPED)
        try {
            trackerClient.announce(torrent.getAllTrackerUrls(), req, clientConfig)
            stats = stats.copy(announceCount = stats.announceCount + 1)
        } catch (_: Exception) {
        }
        stats = stats.copy(
            state = FakerState.STOPPED,
            currentUploadRateKBs = 0.0,
            currentDownloadRateKBs = 0.0,
            isIdling = false,
            idlingReason = null,
            trackerWarning = null,
            nextAnnounceMs = null,
            trackerRetryAtMs = null
        )
    }

    /**
     * Được gọi định kỳ mỗi giây bởi Scheduler nội tại trong RustatioRepository.
     * Trả về true nếu điều kiện dừng yêu cầu xóa torrent khỏi danh sách.
     */
    suspend fun tick(): Boolean {
        val now = System.currentTimeMillis()

        if (stats.state != FakerState.RUNNING) {
            lastTickMs = now
            return false
        }

        val deltaMs = (now - lastTickMs).coerceAtLeast(0L)
        if (deltaMs < 850L) return false
        lastTickMs = now
        val deltaSecs = deltaMs.toDouble() / 1000.0
        val newElapsedSecs = stats.elapsedTimeSecs + max(1L, Math.round(deltaSecs))

        // Kiểm tra điều kiện dừng (Ratio, Dung lượng tải lên/xuống, Thời gian Seed)
        if (checkStopConditionsMet(newElapsedSecs)) {
            when (PostStopAction.fromWire(settings.postStopAction)) {
                PostStopAction.IDLE -> {
                    stats = stats.copy(
                        elapsedTimeSecs = newElapsedSecs,
                        stopConditionMet = true,
                        isIdling = true,
                        idlingReason = "Đã đạt ngưỡng dừng của Preset (Đang giữ kết nối 0 KB/s)",
                        currentUploadRateKBs = 0.0,
                        currentDownloadRateKBs = 0.0
                    )
                }
                PostStopAction.STOP_SEEDING -> {
                    stats = stats.copy(stopConditionMet = true)
                    stop()
                    return false
                }
                PostStopAction.DELETE_INSTANCE -> {
                    stats = stats.copy(stopConditionMet = true)
                    stop()
                    return true
                }
            }
        } else {
            // Chỉ tạm nghỉ vì 0 Leechers/Seeders khi đã có ít nhất 1 lần Tracker trả về số liệu thành công
            val idleNoLeechers = settings.idleWhenNoLeechers &&
                stats.leechers == 0 &&
                stats.announceCount > 0 &&
                stats.trackerWarning == null
            val idleNoSeeders = settings.idleWhenNoSeeders &&
                stats.seeders == 0 &&
                stats.leftBytes > 0L &&
                stats.announceCount > 0 &&
                stats.trackerWarning == null

            val upRateKBs = if (idleNoLeechers) 0.0 else calculateEffectiveRate(
                baseRate = settings.uploadRate,
                targetRate = settings.targetUploadRate,
                elapsedSecs = newElapsedSecs
            )
            val downRateKBs = if (stats.leftBytes <= 0L || idleNoSeeders) 0.0 else calculateEffectiveRate(
                baseRate = settings.downloadRate,
                targetRate = settings.targetDownloadRate,
                elapsedSecs = newElapsedSecs
            )

            val upDeltaBytes = (upRateKBs * 1024.0 * deltaSecs).toLong().coerceAtLeast(0L)
            val rawDownDeltaBytes = (downRateKBs * 1024.0 * deltaSecs).toLong().coerceAtLeast(0L)
            val downDeltaBytes = min(rawDownDeltaBytes, stats.leftBytes)

            val newUploaded = stats.uploadedBytes + upDeltaBytes
            val newDownloaded = stats.downloadedBytes + downDeltaBytes
            val newLeft = (stats.leftBytes - downDeltaBytes).coerceAtLeast(0L)
            val newSessionUp = stats.sessionUploadedBytes + upDeltaBytes
            val newSessionDown = stats.sessionDownloadedBytes + downDeltaBytes

            // Công thức tính Ratio chuẩn rustatio-core/src/faker.rs (dòng 1532-1539): uploaded / torrent_size
            val denom = torrent.totalSize.toDouble().coerceAtLeast(1.0)
            val currentRatio = newUploaded.toDouble() / denom
            val currentSessionRatio = newSessionUp.toDouble() / denom

            val newCompletion = if (torrent.totalSize > 0L) {
                ((torrent.totalSize - newLeft).toDouble() / torrent.totalSize.toDouble() * 100.0).coerceIn(0.0, 100.0)
            } else {
                100.0
            }

            val justCompleted = stats.leftBytes > 0L && newLeft == 0L

            stats = stats.copy(
                uploadedBytes = newUploaded,
                downloadedBytes = newDownloaded,
                leftBytes = newLeft,
                sessionUploadedBytes = newSessionUp,
                sessionDownloadedBytes = newSessionDown,
                currentUploadRateKBs = upRateKBs,
                currentDownloadRateKBs = downRateKBs,
                ratio = currentRatio,
                sessionRatio = currentSessionRatio,
                completionPercent = newCompletion,
                elapsedTimeSecs = newElapsedSecs,
                isIdling = idleNoLeechers || idleNoSeeders,
                idlingReason = when {
                    idleNoLeechers -> "Đang tạm nghỉ (0 Leechers)"
                    idleNoSeeders -> "Đang tạm nghỉ (0 Seeders)"
                    else -> null
                }
            )

            if (justCompleted) {
                sendCompletedAnnounce()
            }
        }

        // Kiểm tra chu kỳ Scrape (mặc định mỗi 60 giây)
        if (scrapeSupported && now - lastScrapeMs >= settings.scrapeIntervalSeconds * 1000L) {
            lastScrapeMs = now
            performPeriodicScrape()
        }

        // Kiểm tra hạn gửi Announce định kỳ hoặc Retry tới Tracker
        val nextAnn = stats.nextAnnounceMs
        if (nextAnn != null && now >= nextAnn) {
            performPeriodicAnnounce()
        }

        return false
    }

    private suspend fun sendCompletedAnnounce() {
        try {
            val req = buildAnnounceRequest(TrackerEvent.COMPLETED)
            val resp = trackerClient.announce(torrent.getAllTrackerUrls(), req, clientConfig)
            stats = stats.copy(
                seeders = resp.complete,
                leechers = resp.incomplete,
                announceCount = stats.announceCount + 1,
                trackerWarning = null,
                trackerError = null
            )
        } catch (_: Exception) {
        }
    }

    private suspend fun performPeriodicScrape() {
        try {
            val resp = trackerClient.scrape(torrent.getAllTrackerUrls(), torrent.infoHash, clientConfig)
            stats = stats.copy(
                seeders = resp.complete,
                leechers = resp.incomplete,
                trackerError = null
            )
        } catch (_: Exception) {
            scrapeSupported = false
        }
    }

    private suspend fun performPeriodicAnnounce() {
        // Nếu chưa có lần Announce thành công nào trước đó thì gửi event=started, ngược lại gửi event=none
        val ev = if (stats.announceCount == 0) TrackerEvent.STARTED else TrackerEvent.NONE
        val req = buildAnnounceRequest(ev)
        try {
            val resp = trackerClient.announce(torrent.getAllTrackerUrls(), req, clientConfig)
            val intervalSecs = resp.interval.coerceAtLeast(30L)
            resp.trackerId?.let { trackerId = it }
            val doneTime = System.currentTimeMillis()
            stats = stats.copy(
                seeders = resp.complete,
                leechers = resp.incomplete,
                announceIntervalSecs = intervalSecs,
                lastAnnounceMs = doneTime,
                nextAnnounceMs = doneTime + intervalSecs * 1000L,
                announceCount = stats.announceCount + 1,
                trackerWarning = resp.warning,
                trackerError = null,
                trackerRetryAttempt = 0,
                trackerRetryAtMs = null
            )
        } catch (e: TrackerException) {
            handlePeriodicFailure(e)
        } catch (e: Exception) {
            handlePeriodicFailure(TrackerException(e.message ?: "Lỗi kết nối Tracker"))
        }
    }

    private fun handlePeriodicFailure(error: TrackerException) {
        val now = System.currentTimeMillis()
        if (error.isMissingTorrent) {
            stats = stats.copy(
                state = FakerState.STOPPED,
                currentUploadRateKBs = 0.0,
                currentDownloadRateKBs = 0.0,
                trackerError = "Torrent không tồn tại trên Tracker (${error.message})",
                trackerWarning = null,
                trackerRetryAttempt = 0,
                trackerRetryAtMs = null,
                nextAnnounceMs = null
            )
        } else {
            val nextAttempt = stats.trackerRetryAttempt + 1
            val delaySecs = getRetryDelaySecs(nextAttempt)
            stats = stats.copy(
                nextAnnounceMs = now + delaySecs * 1000L,
                trackerRetryAttempt = nextAttempt,
                trackerRetryAtMs = now + delaySecs * 1000L,
                trackerError = null,
                trackerWarning = "Chờ Tracker phản hồi (${error.message}) · Thử lại sau ${delaySecs}s"
            )
        }
    }

    private fun getRetryDelaySecs(attempt: Int): Long {
        val idx = (attempt - 1).coerceIn(0, TRACKER_RETRY_SCHEDULE_SECS.lastIndex)
        return TRACKER_RETRY_SCHEDULE_SECS[idx]
    }

    private fun calculateEffectiveRate(
        baseRate: Double,
        targetRate: Double,
        elapsedSecs: Long
    ): Double {
        if (baseRate <= 0.0 && (!settings.progressiveRatesEnabled || targetRate <= 0.0)) {
            return 0.0
        }
        val rate = if (settings.progressiveRatesEnabled) {
            val durationSecs = (settings.progressiveDurationHours * 3600.0).coerceAtLeast(1.0)
            val progress = (elapsedSecs.toDouble() / durationSecs).coerceIn(0.0, 1.0)
            baseRate + (targetRate - baseRate) * progress
        } else {
            baseRate
        }
        if (!settings.randomizeRates || settings.randomRangePercent <= 0.0) {
            return max(0.0, rate)
        }
        val range = (settings.randomRangePercent.coerceIn(0.0, 100.0)) / 100.0
        val variation = 1.0 + Random.nextDouble(-range, range)
        return max(0.0, rate * variation)
    }

    private fun checkStopConditionsMet(elapsedSecs: Long): Boolean {
        if (stats.stopConditionMet) return true
        effectiveStopRatio?.let { targetRatio ->
            if (stats.ratio >= targetRatio - 0.001) return true
        }
        if (settings.stopAtUploadedEnabled) {
            val maxUpBytes = (settings.stopAtUploadedGB * 1024.0 * 1024.0 * 1024.0).toLong()
            if (stats.uploadedBytes >= maxUpBytes) return true
        }
        if (settings.stopAtDownloadedEnabled) {
            val maxDownBytes = (settings.stopAtDownloadedGB * 1024.0 * 1024.0 * 1024.0).toLong()
            if (stats.downloadedBytes >= maxDownBytes) return true
        }
        if (settings.stopAtSeedTimeEnabled) {
            val maxSeedSecs = (settings.stopAtSeedTimeHours * 3600.0).toLong()
            if (elapsedSecs >= maxSeedSecs) return true
        }
        return false
    }

    /**
     * Xây dựng gói tin Announce chuẩn rustatio-core/src/faker.rs (dòng 1435-1459):
     * gửi uploaded = stats.uploadedBytes, downloaded = stats.downloadedBytes, left = stats.leftBytes.
     */
    private fun buildAnnounceRequest(event: TrackerEvent): AnnounceRequest {
        return AnnounceRequest(
            infoHash = torrent.infoHash,
            peerId = peerId,
            port = settings.port.coerceIn(1, 65535),
            uploaded = stats.uploadedBytes,
            downloaded = stats.downloadedBytes,
            left = stats.leftBytes,
            compact = clientConfig.supportsCompact,
            noPeerId = false,
            event = event,
            numWant = if (event == TrackerEvent.STOPPED) 0 else clientConfig.numWant,
            key = keyHex,
            trackerId = trackerId
        )
    }
}
