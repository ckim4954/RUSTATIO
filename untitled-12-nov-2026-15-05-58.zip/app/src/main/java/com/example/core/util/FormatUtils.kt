package com.example.core.util

import java.util.Locale

object FormatUtils {

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val kb = 1024.0
        val mb = kb * 1024.0
        val gb = mb * 1024.0
        val tb = gb * 1024.0
        val value = bytes.toDouble()
        return when {
            value >= tb -> String.format(Locale.US, "%.2f TB", value / tb)
            value >= gb -> String.format(Locale.US, "%.2f GB", value / gb)
            value >= mb -> String.format(Locale.US, "%.2f MB", value / mb)
            value >= kb -> String.format(Locale.US, "%.1f KB", value / kb)
            else -> "$bytes B"
        }
    }

    fun formatSpeedKBs(rateKBs: Double): String {
        if (rateKBs <= 0.05) return "0 KB/s"
        return if (rateKBs >= 1024.0) {
            String.format(Locale.US, "%.2f MB/s", rateKBs / 1024.0)
        } else {
            String.format(Locale.US, "%.1f KB/s", rateKBs)
        }
    }

    fun formatRatio(ratio: Double): String {
        if (ratio.isNaN() || ratio.isInfinite() || ratio < 0.0) return "0.00"
        return String.format(Locale.US, "%.2f", ratio)
    }

    fun formatCountdown(targetEpochMs: Long?): String {
        if (targetEpochMs == null) return "--:--"
        val diffSecs = ((targetEpochMs - System.currentTimeMillis()) / 1000L).coerceAtLeast(0L)
        val mins = diffSecs / 60L
        val secs = diffSecs % 60L
        return if (mins >= 60L) {
            val hrs = mins / 60L
            val remMins = mins % 60L
            String.format(Locale.US, "%d:%02d:%02d", hrs, remMins, secs)
        } else {
            String.format(Locale.US, "%02d:%02d", mins, secs)
        }
    }

    fun formatDurationSecs(totalSecs: Long): String {
        if (totalSecs <= 0L) return "0s"
        val hours = totalSecs / 3600L
        val mins = (totalSecs % 3600L) / 60L
        val secs = totalSecs % 60L
        return when {
            hours > 0L -> "${hours}g ${mins}p"
            mins > 0L -> "${mins}p ${secs}s"
            else -> "${secs}s"
        }
    }

    fun formatDurationShort(totalSecs: Long): String = formatDurationSecs(totalSecs)
}
