package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.CloudUpload
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.presets.Preset
import com.example.ui.components.CustomPresetEditorDialog
import com.example.ui.components.PasteJsonImportDialog
import com.example.ui.screens.GlobalSettingsScreen
import com.example.ui.screens.PresetsSettingsScreen
import com.example.ui.screens.TorrentListScreen
import com.example.ui.theme.DownloadBlue
import com.example.ui.theme.EmeraldDim
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.UploadGreen
import com.example.ui.viewmodel.RustatioViewModel

enum class RustatioDestination(val titleVi: String) {
    TORRENTS("Torrent"),
    PRESETS("Bộ cấu hình"),
    SETTINGS("Cài đặt")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: RustatioViewModel = viewModel()
            val globalConfig by viewModel.globalConfig.collectAsStateWithLifecycle()

            MyApplicationTheme(darkTheme = globalConfig.darkMode) {
                RustatioApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RustatioApp(
    viewModel: RustatioViewModel = viewModel()
) {
    val torrents by viewModel.torrents.collectAsStateWithLifecycle()
    val filteredTorrents by viewModel.filteredTorrents.collectAsStateWithLifecycle()
    val globalSummary by viewModel.globalSummary.collectAsStateWithLifecycle()
    val filterCounts by viewModel.filterCounts.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val isSearchVisible by viewModel.isSearchVisible.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedFilter.collectAsStateWithLifecycle()
    val sortOption by viewModel.sortOption.collectAsStateWithLifecycle()
    val sortAscending by viewModel.sortAscending.collectAsStateWithLifecycle()

    val globalConfig by viewModel.globalConfig.collectAsStateWithLifecycle()
    val allPresets by viewModel.allPresets.collectAsStateWithLifecycle()
    val customPresets by viewModel.customPresets.collectAsStateWithLifecycle()
    val defaultPresetId by viewModel.defaultPresetId.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
    val pendingExportJson by viewModel.pendingExportJson.collectAsStateWithLifecycle()

    var currentTab by rememberSaveable { mutableStateOf(RustatioDestination.TORRENTS) }
    var editingCustomPreset by remember { mutableStateOf<Preset?>(null) }
    var showCreateCustomPreset by remember { mutableStateOf(false) }
    var showImportJsonDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    // Xin quyền thông báo trên Android 13+ để hiển thị tiến trình chạy nền
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Bộ chọn tệp .torrent thực tế từ bộ nhớ thiết bị (SAF) - Nạp trực tiếp theo Cấu hình Chung
    val pickTorrentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.onTorrentFilesPicked(uris)
        }
    }

    // Bộ chọn tệp .json để Import Custom Preset
    val importPresetJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.importPresetFromUri(uri)
        }
    }

    // Bộ lưu tệp .json để Export Custom Preset
    val exportPresetJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        viewModel.writePendingExportToUri(uri)
    }

    LaunchedEffect(pendingExportJson) {
        val pending = pendingExportJson ?: return@LaunchedEffect
        exportPresetJsonLauncher.launch(pending.first)
    }

    LaunchedEffect(statusMessage) {
        val msg = statusMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(msg)
        viewModel.clearStatusMessage()
    }

    if (currentTab != RustatioDestination.TORRENTS) {
        BackHandler {
            currentTab = RustatioDestination.TORRENTS
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Rustatio",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )

                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(999.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f))
                        ) {
                            Text(
                                text = "v2.14.1",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        // Hiển thị tốc độ tổng nếu đang chạy
                        if (globalSummary.runningCount > 0) {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "↑ ${globalSummary.uploadSpeedFormatted}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                                        color = UploadGreen,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "↓ ${globalSummary.downloadSpeedFormatted}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                                        color = DownloadBlue,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                },
                actions = {
                    // Nút Bật/Tắt tìm kiếm
                    IconButton(
                        onClick = { viewModel.toggleSearchVisibility() },
                        modifier = Modifier.testTag("topbar_search_toggle_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Tìm kiếm torrent",
                            tint = if (isSearchVisible || searchQuery.isNotEmpty()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Nút Nạp .Torrent thực tế từ thiết bị
                    Surface(
                        onClick = {
                            pickTorrentLauncher.launch(
                                arrayOf("application/x-bittorrent", "application/octet-stream", "*/*")
                            )
                        },
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                        modifier = Modifier.testTag("topbar_add_torrent_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Thêm torrent",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = ".Torrent",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Nút chuyển nhanh sang Cài đặt
                    IconButton(
                        onClick = { currentTab = RustatioDestination.SETTINGS },
                        modifier = Modifier.testTag("topbar_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Cài đặt chung",
                            tint = if (currentTab == RustatioDestination.SETTINGS) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurface,
                    actionColor = MaterialTheme.colorScheme.primary,
                    shape = RoundedCornerShape(12.dp)
                )
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                windowInsets = WindowInsets.navigationBars
            ) {
                NavigationBarItem(
                    selected = currentTab == RustatioDestination.TORRENTS,
                    onClick = { currentTab = RustatioDestination.TORRENTS },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (globalSummary.runningCount > 0) {
                                    Badge(
                                        containerColor = MaterialTheme.colorScheme.primary,
                                        contentColor = MaterialTheme.colorScheme.onPrimary
                                    ) {
                                        Text(globalSummary.runningCount.toString())
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = if (currentTab == RustatioDestination.TORRENTS) {
                                    Icons.Filled.CloudUpload
                                } else {
                                    Icons.Outlined.CloudUpload
                                },
                                contentDescription = RustatioDestination.TORRENTS.titleVi
                            )
                        }
                    },
                    label = { Text(RustatioDestination.TORRENTS.titleVi) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("nav_tab_torrents")
                )

                NavigationBarItem(
                    selected = currentTab == RustatioDestination.PRESETS,
                    onClick = { currentTab = RustatioDestination.PRESETS },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == RustatioDestination.PRESETS) {
                                Icons.Filled.Tune
                            } else {
                                Icons.Outlined.Tune
                            },
                            contentDescription = RustatioDestination.PRESETS.titleVi
                        )
                    },
                    label = { Text(RustatioDestination.PRESETS.titleVi) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DownloadBlue,
                        selectedTextColor = DownloadBlue,
                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("nav_tab_presets")
                )

                NavigationBarItem(
                    selected = currentTab == RustatioDestination.SETTINGS,
                    onClick = { currentTab = RustatioDestination.SETTINGS },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == RustatioDestination.SETTINGS) {
                                Icons.Filled.Settings
                            } else {
                                Icons.Outlined.Settings
                            },
                            contentDescription = RustatioDestination.SETTINGS.titleVi
                        )
                    },
                    label = { Text(RustatioDestination.SETTINGS.titleVi) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldPrimary,
                        selectedTextColor = EmeraldPrimary,
                        indicatorColor = EmeraldDim,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("nav_tab_settings")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                RustatioDestination.TORRENTS -> {
                    TorrentListScreen(
                        torrents = filteredTorrents,
                        totalUnfilteredCount = torrents.size,
                        searchQuery = searchQuery,
                        isSearchVisible = isSearchVisible,
                        selectedFilter = selectedFilter,
                        filterCounts = filterCounts,
                        sortOption = sortOption,
                        sortAscending = sortAscending,
                        onSearchQueryChange = { viewModel.setSearchQuery(it) },
                        onClearSearch = { viewModel.clearSearchQuery() },
                        onSelectFilter = { viewModel.setFilterCategory(it) },
                        onSelectSort = { viewModel.setSortOption(it) },
                        onPickTorrentFile = {
                            pickTorrentLauncher.launch(
                                arrayOf("application/x-bittorrent", "application/octet-stream", "*/*")
                            )
                        },
                        onStartTorrent = { viewModel.startTorrent(it) },
                        onPauseResumeTorrent = { viewModel.pauseOrResumeTorrent(it) },
                        onPauseTorrent = { viewModel.pauseTorrent(it) },
                        onStopTorrent = { viewModel.stopTorrent(it) },
                        onDeleteTorrent = { viewModel.deleteTorrent(it.id, it.name) },
                        onStartAll = { viewModel.startAllTorrents() },
                        onPauseAll = { viewModel.pauseAllTorrents() },
                        onStopAll = { viewModel.stopAllTorrents() }
                    )
                }

                RustatioDestination.PRESETS -> {
                    PresetsSettingsScreen(
                        allPresets = allPresets,
                        customPresets = customPresets,
                        defaultPresetId = defaultPresetId,
                        onApplyPreset = { preset -> viewModel.applyPreset(preset) },
                        onToggleDefaultPreset = { preset -> viewModel.toggleDefaultPreset(preset) },
                        onCreateNewCustomPreset = {
                            editingCustomPreset = null
                            showCreateCustomPreset = true
                        },
                        onEditPreset = { preset ->
                            editingCustomPreset = preset
                            showCreateCustomPreset = true
                        },
                        onDuplicatePreset = { preset -> viewModel.duplicatePreset(preset) },
                        onDeleteCustomPreset = { preset -> viewModel.deleteCustomPreset(preset) },
                        onOpenImportJson = { showImportJsonDialog = true },
                        onExportSinglePreset = { preset -> viewModel.prepareExportPreset(preset) },
                        onExportAllCustomPresets = { viewModel.prepareExportAllCustomPresets() }
                    )
                }

                RustatioDestination.SETTINGS -> {
                    GlobalSettingsScreen(
                        globalConfig = globalConfig,
                        allPresets = allPresets,
                        onSelectClient = { viewModel.updateGlobalClient(it) },
                        onSelectVersion = { viewModel.updateGlobalClientVersion(it) },
                        onSelectOperatingSystem = { viewModel.updateGlobalOperatingSystem(it) },
                        onUpdatePort = { viewModel.updateGlobalPort(it) },
                        onSelectDefaultPreset = { viewModel.toggleDefaultPreset(it) },
                        onToggleDarkMode = { viewModel.updateDarkMode(it) },
                        onOpenPresetsScreen = { currentTab = RustatioDestination.PRESETS }
                    )
                }
            }
        }
    }

    // Hộp thoại Tạo mới / Chỉnh sửa Custom Preset
    if (showCreateCustomPreset) {
        CustomPresetEditorDialog(
            initialPreset = editingCustomPreset,
            onDismiss = {
                showCreateCustomPreset = false
                editingCustomPreset = null
            },
            onSave = { name, desc, settings, existingId, setAsDefault ->
                showCreateCustomPreset = false
                editingCustomPreset = null
                viewModel.saveCustomPreset(name, desc, settings, existingId, setAsDefault)
            }
        )
    }

    // Hộp thoại Nhập Preset JSON (Import JSON)
    if (showImportJsonDialog) {
        PasteJsonImportDialog(
            onDismiss = { showImportJsonDialog = false },
            onPickFile = {
                importPresetJsonLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
            },
            onImportRawJson = { rawJson ->
                viewModel.importPresetFromRawText(rawJson)
            }
        )
    }
}
