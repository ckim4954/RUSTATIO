package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.faker.FakerState
import com.example.core.presets.BuiltInPresets
import com.example.core.presets.Preset
import com.example.core.torrent.ClientType
import com.example.core.torrent.OperatingSystem
import com.example.data.repository.RustatioRepository
import com.example.data.repository.TorrentFilterCategory
import com.example.data.repository.TorrentSortOption
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Rustatio", appName)
    }

    @Test
    fun `preset json export and import roundtrip preserves settings`() {
        val original = BuiltInPresets.all.first().copy(
            id = "custom-test",
            name = "Preset Thử Nghiệm",
            custom = true
        )
        val exported = original.toExportJsonString()
        val importedList = Preset.parseImportedJson(exported)
        assertEquals(1, importedList.size)
        assertEquals("Preset Thử Nghiệm", importedList.first().name)
        assertEquals(original.settings.uploadRate, importedList.first().settings.uploadRate, 0.01)
    }

    @Test
    fun `500 torrent list generation, filtering and sorting in test environment`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = RustatioRepository.getInstance(context)

        // Khởi tạo 500 torrent giả lập trong môi trường Robolectric để kiểm tra hiệu năng
        repository.seedSyntheticTorrentsForTest(500)

        val list = repository.torrentsState.first()
        assertEquals(500, list.size)

        // Kiểm tra tính toán các trường định dạng trước (pre-formatted)
        val firstItem = list.first()
        assertNotNull(firstItem.uploadedFormatted)
        assertNotNull(firstItem.downloadedFormatted)
        assertNotNull(firstItem.speedFormatted)
        assertTrue(firstItem.uploadedFormatted.isNotEmpty())

        // Kiểm tra lọc theo danh mục
        val seedingCount = list.count { it.filterCategory == TorrentFilterCategory.SEEDING }
        val allCount = list.count { (it.filterCategory == TorrentFilterCategory.ALL) || true }
        assertEquals(500, allCount)
        assertTrue(seedingCount >= 0)

        // Kiểm tra sắp xếp theo tên
        val sortedByName = list.sortedBy { it.name }
        assertEquals(500, sortedByName.size)
        assertTrue(sortedByName.first().name <= sortedByName.last().name)

        // Kiểm tra sắp xếp theo dung lượng đã tải lên
        val sortedByUploaded = list.sortedByDescending { it.stats.uploadedBytes }
        assertTrue(sortedByUploaded.first().stats.uploadedBytes >= sortedByUploaded.last().stats.uploadedBytes)
    }

    @Test
    fun `global config propagation updates client, version, OS, and port across all torrents`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = RustatioRepository.getInstance(context)

        repository.seedSyntheticTorrentsForTest(5)

        // 1. Cập nhật sang qBittorrent v5.3.0 trên Windows 10
        repository.updateGlobalConfig(
            clientType = ClientType.QBITTORRENT,
            clientVersion = "5.3.0",
            operatingSystem = OperatingSystem.WIN_10,
            port = 6881
        )
        var list = repository.torrentsState.first()
        for (item in list) {
            assertEquals("qBittorrent", item.clientDisplayName)
            assertEquals("5.3.0", item.clientVersion)
            assertEquals(OperatingSystem.WIN_10, item.operatingSystem)
            assertEquals(6881, item.port)
            assertTrue(item.stats.peerId.startsWith("-qB5300-"))
            assertEquals("qBittorrent/5.3.0", item.stats.userAgent)
            assertTrue(item.stats.osHeader.contains("Windows NT 10.0"))
        }

        // 2. Chuyển sang uTorrent v3.5.5 trên Windows 7
        repository.updateGlobalConfig(
            clientType = ClientType.UTORRENT,
            clientVersion = "3.5.5",
            operatingSystem = OperatingSystem.WIN_7,
            port = 6882
        )
        list = repository.torrentsState.first()
        for (item in list) {
            assertEquals("uTorrent", item.clientDisplayName)
            assertEquals("3.5.5", item.clientVersion)
            assertEquals(OperatingSystem.WIN_7, item.operatingSystem)
            assertEquals(6882, item.port)
            assertTrue(item.stats.peerId.startsWith("-UT3550-"))
            assertEquals("uTorrent/3.5.5", item.stats.userAgent)
            assertTrue(item.stats.osHeader.contains("Windows NT 6.1"))
        }

        // 3. Chuyển sang Deluge v2.2.0 trên Windows 12
        repository.updateGlobalConfig(
            clientType = ClientType.DELUGE,
            clientVersion = "2.2.0",
            operatingSystem = OperatingSystem.WIN_12,
            port = 58846
        )
        list = repository.torrentsState.first()
        for (item in list) {
            assertEquals("Deluge", item.clientDisplayName)
            assertEquals("2.2.0", item.clientVersion)
            assertEquals(OperatingSystem.WIN_12, item.operatingSystem)
            assertEquals(58846, item.port)
            assertTrue(item.stats.peerId.startsWith("-DE2200-"))
            assertEquals("Deluge/2.2.0", item.stats.userAgent)
            assertTrue(item.stats.osHeader.contains("Windows NT 12.0"))
        }
    }

    @Test
    fun `batch actions start all, pause all, and stop all execute correctly`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = RustatioRepository.getInstance(context)

        repository.seedSyntheticTorrentsForTest(5, initialState = FakerState.RUNNING)

        // Tạm dừng tất cả
        repository.pauseAllTorrents()
        val pausedList = repository.torrentsState.first()
        for (item in pausedList) {
            assertEquals(FakerState.PAUSED, item.stats.state)
        }

        // Dừng tất cả
        repository.stopAllTorrents()
        val stoppedList = repository.torrentsState.first()
        for (item in stoppedList) {
            assertEquals(FakerState.STOPPED, item.stats.state)
        }
    }

    @Test
    fun `duplicate preset creates a customized clone`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = RustatioRepository.getInstance(context)

        val builtIn = BuiltInPresets.all.first()
        val duplicated = repository.duplicatePreset(builtIn)

        assertTrue(duplicated.name.contains("(Bản sao)"))
        assertTrue(duplicated.custom)
        assertEquals(builtIn.settings.uploadRate, duplicated.settings.uploadRate, 0.01)
    }
}
