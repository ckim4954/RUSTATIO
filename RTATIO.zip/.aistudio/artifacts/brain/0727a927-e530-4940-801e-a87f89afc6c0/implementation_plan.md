# Rustatio Android — Kế Hoạch Khắc Phục Triệt Để Tương Tác Tracker & Đồng Bộ Lõi Rustatio 2.14.1

Nâng cấp tầng giao thức mạng (`TrackerClient`), bộ máy tính toán lưu lượng (`RatioFaker`), dịch vụ lắng nghe cổng kết nối (`PeerListener`) và bộ lập lịch thời gian thực (`Scheduler`) để đảm bảo khi bấm **Bắt đầu (Start)**, ứng dụng tương tác với BitTorrent Tracker chuẩn xác 100% như bản **Rustatio 2.14.1 (Tauri 2 / Rust)** trên máy tính.

---

## Quyết Định Đã Xác Nhận Từ Người Dùng

> [!IMPORTANT]
> Hai lựa chọn kỹ thuật quan trọng đã được bạn xác nhận để đảm bảo tương thích tuyệt đối với mọi Private/Public Tracker:

- **Giữ nguyên `User-Agent` chuẩn PC, truyền Hệ điều hành (Windows 7, 10, 12) qua Header phụ**: Gửi chính xác chuỗi `User-Agent` gốc của từng Client (ví dụ: `qBittorrent/5.3.0`, `uTorrent/3.5.5`, `Transmission/4.1.4`) để vượt qua bộ lọc Whitelist khắt khe của Private Tracker, đồng thời truyền định danh **Windows 7 (`NT 6.1`)**, **Windows 10 (`NT 10.0`)**, **Windows 12 (`NT 12.0`)** qua các trường HTTP Header nền tảng (`Sec-CH-UA-Platform`, `Sec-CH-UA-Platform-Version`, `X-Client-OS`).
- **Hiển thị trạng thái ngắn gọn, trực quan ngay trên thẻ Torrent**: Không thêm hộp thoại nhật ký rườm rà; hiển thị rõ ràng trạng thái kết nối Tracker, số lượng Seeders/Leechers, chu kỳ đếm ngược Announce và tốc độ/dung lượng ngay trên từng thẻ Torrent.

---

## 1. Phân Tích Nguyên Nhân & Giải Pháp Khắc Phục Lõi Tracker

Qua đối chiếu từng dòng mã nguồn giữa `rustatio-core` (`tracker.rs`, `faker.rs`, `peer_listener.rs`, `scheduler.rs`) và bản Android hiện tại, **5 điểm nghẽn** khiến việc bấm `Start` không tương tác chuẩn với Tracker sẽ được xử lý triệt để:

1. **Chuẩn hóa mã hóa `peer_id` và `info_hash` trong URL Announce**:
   - *Nguyên nhân*: Bản trước mã hóa phần trăm (`%XX`) toàn bộ 20 ký tự của `peer_id` (biến `-qB5300-...` thành `%2D%71%42...`), khiến nhiều Tracker từ chối gói tin vì không khớp mẫu Regex `peer_id`.
   - *Khắc phục*: Giữ nguyên chuỗi ASCII của `peer_id` (`peer_id=-qB5300-xxxxxxxxxxxx`) giống hệt `rustatio-core/src/protocol/tracker.rs`, chỉ mã hóa `%XX` cho 20 byte nhị phân của `info_hash` và giữ đúng thứ tự tham số: `info_hash`, `peer_id`, `port`, `uploaded`, `downloaded`, `left`, `compact=1`, `event`, `numwant`, `key`, `trackerid`, `supportcrypto=1`.
2. **Bật tự động giải nén Gzip & hỗ trợ đa tầng Tracker (Multi-tier Announce)**:
   - *Nguyên nhân*: Việc gán cứng header `Accept-Encoding: identity` vô tình tắt bộ giải nén Gzip tự động của OkHttp khi Tracker đứng sau Cloudflare/Nginx trả về dữ liệu nén Bencode.
   - *Khắc phục*: Gỡ bỏ `Accept-Encoding: identity` để kích hoạt giải nén Gzip trong suốt giống `reqwest::Client::builder().gzip(true)` của bản PC, đồng thời tự động duyệt qua toàn bộ danh sách `announce` và `announce-list` (cả HTTP/HTTPS và UDP BEP-15).
3. **Tách biệt Vòng lặp Bộ đếm (In-Process Scheduler) khỏi Ràng buộc Khởi tạo Dịch vụ Nền**:
   - *Nguyên nhân*: Vòng lặp `tick()` cập nhật tốc độ mỗi giây trước đó chỉ chạy bên trong `TrackerForegroundService`. Khi người dùng bấm `Start`, trong lúc đang chờ Tracker phản hồi (`STARTING`), dịch vụ kiểm tra thấy chưa có phiên `RUNNING` nên tự đóng (`stopSelf()`), dẫn đến việc sau khi kết nối xong thì tốc độ vẫn đứng yên ở `0 KB/s`.
   - *Khắc phục*: Đặt bộ lập lịch Coroutine 1 giây (`Scheduler`) chạy thường trực ngay trong `RustatioRepository` (tương đương `rustatio-desktop/src/scheduler.rs`), kết hợp với `TrackerForegroundService` chỉ đóng khi không còn bất kỳ torrent nào ở trạng thái `STARTING`, `RUNNING` hoặc `PAUSED`.
4. **Đồng bộ Công thức `uploaded`, `downloaded`, `left` và `ratio` theo `rustatio-core`**:
   - *Nguyên nhân*: Khi ở chế độ Seeder (`completion_percent = 100%`), `rustatio-core` khởi tạo `uploaded = 0`, `downloaded = 0`, `left = 0` và tính `ratio = uploaded / torrent.total_size`. Bản trước gán sẵn `downloaded = total_size` ngay từ đầu và gửi `sessionUploadedBytes` thay vì tổng `uploaded` tích lũy.
   - *Khắc phục*: Áp dụng chính xác 100% công thức của `rustatio-core/src/faker.rs` cho cả gói tin `started`, `completed`, `stopped`, `periodic announce` và cách tính Ratio.
5. **Bổ sung dịch vụ lắng nghe cổng TCP (`PeerListener`) như trên PC**:
   - *Nguyên nhân*: Một số Tracker kiểm tra cổng (`port`) của Client bằng cách mở kết nối TCP và gửi gói bắt tay BitTorrent 68 byte (`\x13BitTorrent protocol`).
   - *Khắc phục*: Chuyển đổi `rustatio-core/src/peer_listener.rs` sang Android để lắng nghe và phản hồi gói bắt tay 68 byte với đúng `info_hash` và `peer_id` của phiên đang chạy.

---

## 2. Trải Nghiệm Người Dùng & Giao Diện (100% Tiếng Việt)

- **Danh sách Torrent thông minh**:
  - Khi bấm **Bắt đầu (Start)** trên một Torrent:
    1. Trạng thái chuyển ngay sang **Đang kết nối...**, đồng thời bộ đếm tốc độ và phiên làm việc kích hoạt tức thì.
    2. Ngay khi Tracker phản hồi (hoặc ngay cả khi Tracker công cộng/riêng tư phản hồi chậm), phiên chuyển sang **Đang chạy**, hiển thị tốc độ tải lên/tải xuống biến thiên theo thời gian thực (`↑ KB/s`, `MB/s`), cộng dồn dung lượng **Đã tải lên (Uploaded)**, **Đã tải xuống (Downloaded)**, **Ratio** và đếm ngược chu kỳ **Announce tiếp theo**.
- **Cấu hình Client · Version · Port & Hệ điều hành (Windows 7, 10, 12)**:
  - Hộp xem trước chữ ký mạng hiển thị rõ:
    - `User-Agent`: Chuẩn gốc theo Client & Version (VD: `qBittorrent/5.3.0`).
    - `OS Header`: Chữ ký nền tảng Windows 7 (`NT 6.1`), Windows 10 (`NT 10.0`), hoặc Windows 12 (`NT 12.0`).
    - `Peer-ID` & `Port`: Tiền tố 20 ký tự chuẩn và cổng lắng nghe TCP.
- **Màn hình Cài đặt — Chỉ giữ lại Full Presets**:
  - Giữ nguyên 4 Built-in Presets chuẩn (*Cân Bằng*, *Tăng Tốc*, *Chế Độ Seedbox*, *Ẩn Danh An Toàn* — không có *Partial Download*), cùng đầy đủ tính năng tạo/sửa/xóa Custom Presets, Nhập/Xuất tệp JSON, Áp dụng và Đặt làm mặc định.

---

## 3. Sơ Đồ Kiến Trúc Tương Tác Tracker & Bộ Lập Lịch Mới

```
┌────────────────────────────────────────────────────────────────────────────┐
│                   GIAO DIỆN NGƯỜI DÙNG (JETPACK COMPOSE)                   │
│  • Thẻ Torrent: Tên, Uploaded, Downloaded, Speed ↑/↓, Ratio, Seeds/Peers   │
│  • Điều khiển: Bắt đầu (Start) / Tạm dừng (Pause) / Dừng (Stop) / Xóa      │
│  • Cấu hình nhanh: Preset + Client + Version + Port + OS (Win 7/10/12)     │
└───────────────────┬───────────────────────────────────────┬────────────────┘
                    │ Lệnh Start / Pause / Stop             │ StateFlow (1s/lần)
                    ▼                                       ▲
┌────────────────────────────────────────────────────────────────────────────┐
│             BỘ ĐIỀU PHỐI TRUNG TÂM & SCHEDULER NỘI TẠI (1 GIÂY)            │
│  • Vòng lặp Coroutine độc lập cập nhật tốc độ & dung lượng mỗi 1000ms      │
│  • Tự động kích hoạt Announce định kỳ, Scrape (60s) & Retry (30-300s)      │
│  • Đồng bộ hai chiều với Foreground Service (Giữ tiến trình khi khóa máy)  │
└─────────┬─────────────────────────────┬──────────────────────────┬─────────┘
          │                             │                          │
          ▼                             ▼                          ▼
┌───────────────────────────┐ ┌──────────────────────────┐ ┌─────────────────┐
│   GIAO THỨC TRACKER THẬT  │ │  TCP PEER LISTENER PORT  │ │ LƯU TRỮ ROOM DB │
│ • User-Agent chuẩn PC     │ │ • Lắng nghe kết nối TCP  │ │ • Lưu Torrent & │
│ • Header phụ OS Win7/10/12│ │ • Phản hồi gói Handshake │ │   lưu lượng     │
│ • Peer-ID ASCII nguyên bản│ │   BitTorrent 68 byte     │ │ • Custom Presets│
│ • Gzip + HTTP/S & UDP     │ │   (\x13BitTorrent...)    │ │   & Mặc định    │
└───────────────────────────┘ └──────────────────────────┘ └─────────────────┘
```
