package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.CloudUpload
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.faker.FakerState
import com.example.core.presets.BuiltInPresets
import com.example.core.presets.Preset
import com.example.data.repository.TorrentUiItem
import com.example.ui.components.AddTorrentConfigDialog
import com.example.ui.components.ApplyPresetTargetDialog
import com.example.ui.components.CustomPresetEditorDialog
import com.example.ui.components.EditTorrentConfigDialog
import com.example.ui.components.PasteJsonImportDialog
import com.example.ui.screens.PresetsSettingsScreen
import com.example.ui.screens.TorrentListScreen
import com.example.ui.theme.EmeraldDim
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.SkySecondary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.RustatioViewModel

enum class RustatioDestination(val titleVi: String) {
    TORRENTS("Danh Sách Torrent"),
    PRESETS("Cài Đặt Presets")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                RustatioApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RustatioApp(
    viewModel: RustatioViewModel = viewModel()
) {
    val torrents by viewModel.torrents.collectAsStateWithLifecycle()
    val allPresets by viewModel.allPresets.collectAsStateWithLifecycle()
    val customPresets by viewModel.customPresets.collectAsStateWithLifecycle()
    val defaultPresetId by viewModel.defaultPresetId.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
    val pendingTorrents by viewModel.pendingTorrents.collectAsStateWithLifecycle()
    val pendingExportJson by viewModel.pendingExportJson.collectAsStateWithLifecycle()

    var currentTab by rememberSaveable { mutableStateOf(RustatioDestination.TORRENTS) }
    var editingTorrent by remember { mutableStateOf<TorrentUiItem?>(null) }
    var editingCustomPreset by remember { mutableStateOf<Preset?>(null) }
    var showCreateCustomPreset by remember { mutableStateOf(false) }
    var presetToApply by remember { mutableStateOf<Preset?>(null) }
    var showImportJsonDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    // Xin quyền thông báo trên Android 13+ để hiển thị tiến trình chạy nền
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Bộ chọn tệp .torrent thực tế từ bộ nhớ thiết bị (SAF)
    val pickTorrentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.onTorrentFilesPicked(uris)
        }
    }

    // Bộ chọn tệp .json để Import Custom Preset
    val importPresetJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.importPresetFromUri(uri)
        }
    }

    // Bộ lưu tệp .json để Export Custom Preset
    val exportPresetJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        viewModel.writePendingExportToUri(uri)
    }

    LaunchedEffect(pendingExportJson) {
        val pending = pendingExportJson ?: return@LaunchedEffect
        exportPresetJsonLauncher.launch(pending.first)
    }

    LaunchedEffect(statusMessage) {
        val msg = statusMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(msg)
        viewModel.clearStatusMessage()
    }

    if (currentTab != RustatioDestination.TORRENTS) {
        BackHandler {
            currentTab = RustatioDestination.TORRENTS
        }
    }

    val activeDefaultPreset = remember(allPresets, defaultPresetId) {
        allPresets.firstOrNull { it.id == defaultPresetId } ?: BuiltInPresets.all.first()
    }

    val runningTorrentsCount = remember(torrents) {
        torrents.count { it.stats.state == FakerState.RUNNING || it.stats.state == FakerState.STARTING }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = ObsidianBg,
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Rustatio",
                            style = MaterialTheme.typography.titleLarge,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            color = ObsidianSurfaceVariant,
                            shape = RoundedCornerShape(999.dp),
                            border = BorderStroke(1.dp, ObsidianBorder)
                        ) {
                            Text(
                                text = "v2.14.1 · VN",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldPrimary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                },
                actions = {
                    Surface(
                        onClick = {
                            pickTorrentLauncher.launch(
                                arrayOf("application/x-bittorrent", "application/octet-stream", "*/*")
                            )
                        },
                        color = EmeraldDim,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .testTag("topbar_add_torrent_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudUpload,
                                contentDescription = "Nạp tệp .torrent",
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Nạp .Torrent",
                                style = MaterialTheme.typography.labelLarge,
                                color = EmeraldPrimary
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ObsidianBg,
                    titleContentColor = TextPrimary
                )
            )
        },
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = ObsidianSurfaceVariant,
                    contentColor = TextPrimary,
                    actionColor = EmeraldPrimary,
                    shape = RoundedCornerShape(14.dp)
                )
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = ObsidianSurface,
                tonalElevation = 8.dp,
                windowInsets = WindowInsets.navigationBars
            ) {
                NavigationBarItem(
                    selected = currentTab == RustatioDestination.TORRENTS,
                    onClick = { currentTab = RustatioDestination.TORRENTS },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (runningTorrentsCount > 0) {
                                    Badge(
                                        containerColor = EmeraldPrimary,
                                        contentColor = ObsidianBg
                                    ) {
                                        Text(runningTorrentsCount.toString())
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = if (currentTab == RustatioDestination.TORRENTS) {
                                    Icons.Filled.CloudUpload
                                } else {
                                    Icons.Outlined.CloudUpload
                                },
                                contentDescription = RustatioDestination.TORRENTS.titleVi
                            )
                        }
                    },
                    label = { Text(RustatioDestination.TORRENTS.titleVi) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldPrimary,
                        selectedTextColor = EmeraldPrimary,
                        indicatorColor = EmeraldDim,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("nav_tab_torrents")
                )

                NavigationBarItem(
                    selected = currentTab == RustatioDestination.PRESETS,
                    onClick = { currentTab = RustatioDestination.PRESETS },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == RustatioDestination.PRESETS) {
                                Icons.Filled.Tune
                            } else {
                                Icons.Outlined.Tune
                            },
                            contentDescription = RustatioDestination.PRESETS.titleVi
                        )
                    },
                    label = { Text(RustatioDestination.PRESETS.titleVi) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SkySecondary,
                        selectedTextColor = SkySecondary,
                        indicatorColor = ObsidianSurfaceVariant,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("nav_tab_presets")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                RustatioDestination.TORRENTS -> {
                    TorrentListScreen(
                        torrents = torrents,
                        defaultPreset = activeDefaultPreset,
                        onPickTorrentFile = {
                            pickTorrentLauncher.launch(
                                arrayOf("application/x-bittorrent", "application/octet-stream", "*/*")
                            )
                        },
                        onStartTorrent = { viewModel.startTorrent(it) },
                        onPauseResumeTorrent = { viewModel.pauseOrResumeTorrent(it) },
                        onStopTorrent = { viewModel.stopTorrent(it) },
                        onDeleteTorrent = { viewModel.deleteTorrent(it.id, it.name) },
                        onConfigureTorrent = { editingTorrent = it },
                        onStartAll = { viewModel.startAllTorrents() },
                        onPauseAll = { viewModel.pauseAllTorrents() },
                        onStopAll = { viewModel.stopAllTorrents() },
                        onNavigateToPresets = { currentTab = RustatioDestination.PRESETS }
                    )
                }

                RustatioDestination.PRESETS -> {
                    PresetsSettingsScreen(
                        allPresets = allPresets,
                        customPresets = customPresets,
                        defaultPresetId = defaultPresetId,
                        onApplyPreset = { preset ->
                            if (torrents.size > 1) {
                                presetToApply = preset
                            } else {
                                viewModel.applyPreset(preset, torrents.firstOrNull()?.id)
                            }
                        },
                        onToggleDefaultPreset = { viewModel.toggleDefaultPreset(it) },
                        onCreateNewCustomPreset = {
                            editingCustomPreset = null
                            showCreateCustomPreset = true
                        },
                        onEditOrClonePreset = { preset ->
                            editingCustomPreset = preset
                            showCreateCustomPreset = true
                        },
                        onDeleteCustomPreset = { viewModel.deleteCustomPreset(it) },
                        onOpenImportJson = { showImportJsonDialog = true },
                        onExportSinglePreset = { viewModel.prepareExportPreset(it) },
                        onExportAllCustomPresets = { viewModel.prepareExportAllCustomPresets() }
                    )
                }
            }
        }
    }

    // Hộp thoại cấu hình Client - Version - Port - OS (Win 7/10/12) ngay khi nạp tệp .torrent
    if (pendingTorrents.isNotEmpty()) {
        AddTorrentConfigDialog(
            drafts = pendingTorrents,
            allPresets = allPresets,
            defaultPresetId = defaultPresetId,
            onDismiss = { viewModel.dismissPendingTorrents() },
            onConfirm = { preset, clientType, version, port, os, autoStart ->
                viewModel.confirmAddPendingTorrents(
                    preset = preset,
                    clientType = clientType,
                    clientVersion = version,
                    port = port,
                    operatingSystem = os,
                    autoStart = autoStart
                )
            }
        )
    }

    // Hộp thoại chỉnh sửa Client - Version - Port - OS cho một torrent đang có trong danh sách
    editingTorrent?.let { target ->
        EditTorrentConfigDialog(
            torrent = target,
            allPresets = allPresets,
            defaultPresetId = defaultPresetId,
            onDismiss = { editingTorrent = null },
            onSave = { preset, clientType, version, port, os ->
                val id = target.id
                editingTorrent = null
                viewModel.updateTorrentClientOsPort(
                    torrentId = id,
                    preset = preset,
                    clientType = clientType,
                    clientVersion = version,
                    port = port,
                    operatingSystem = os
                )
            }
        )
    }

    // Hộp thoại Tạo mới / Chỉnh sửa Custom Preset
    if (showCreateCustomPreset) {
        CustomPresetEditorDialog(
            initialPreset = editingCustomPreset,
            onDismiss = {
                showCreateCustomPreset = false
                editingCustomPreset = null
            },
            onSave = { name, desc, settings, existingId, setAsDefault ->
                showCreateCustomPreset = false
                editingCustomPreset = null
                viewModel.saveCustomPreset(name, desc, settings, existingId, setAsDefault)
            }
        )
    }

    // Hộp thoại chọn phạm vi áp dụng Preset (Khi có nhiều torrent)
    presetToApply?.let { preset ->
        ApplyPresetTargetDialog(
            preset = preset,
            torrents = torrents,
            onDismiss = { presetToApply = null },
            onApply = { targetId ->
                val p = preset
                presetToApply = null
                viewModel.applyPreset(p, targetId)
            }
        )
    }

    // Hộp thoại Nhập Preset JSON (Import JSON)
    if (showImportJsonDialog) {
        PasteJsonImportDialog(
            onDismiss = { showImportJsonDialog = false },
            onPickFile = {
                importPresetJsonLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
            },
            onImportRawJson = { rawJson ->
                viewModel.importPresetFromRawText(rawJson)
            }
        )
    }
}
