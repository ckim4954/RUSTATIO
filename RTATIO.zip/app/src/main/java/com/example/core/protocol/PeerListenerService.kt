package com.example.core.protocol

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.DataInputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.charset.StandardCharsets

/**
 * Chuyển đổi nguyên bản rustatio-core/src/peer_listener.rs & protocol/peer.rs.
 * Mở cổng TCP lắng nghe và phản hồi gói bắt tay BitTorrent 68 byte (\x13BitTorrent protocol)
 * khi Tracker hoặc Peer kiểm tra khả năng kết nối (Connectable check).
 */
class PeerListenerService(
    private val peerCatalogLookup: () -> Map<String, ByteArray>
) {
    companion object {
        private const val PROTOCOL_STR = "BitTorrent protocol"
        private const val HANDSHAKE_LEN = 68
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var listenerJob: Job? = null
    @Volatile
    var boundPort: Int? = null
        private set

    private var serverSocket: ServerSocket? = null

    fun ensureListening(desiredPort: Int) {
        val validPort = desiredPort.coerceIn(1024, 65535)
        if (boundPort == validPort && listenerJob?.isActive == true && serverSocket?.isClosed == false) {
            return
        }
        stop()
        listenerJob = scope.launch {
            try {
                val sock = ServerSocket()
                sock.reuseAddress = true
                sock.bind(InetSocketAddress("0.0.0.0", validPort))
                serverSocket = sock
                boundPort = validPort

                while (isActive && !sock.isClosed) {
                    val client = try {
                        sock.accept()
                    } catch (_: Exception) {
                        if (!isActive || sock.isClosed) break
                        delay(200L)
                        continue
                    }
                    launch {
                        handlePeerSocket(client)
                    }
                }
            } catch (_: Exception) {
                boundPort = null
            }
        }
    }

    private suspend fun handlePeerSocket(socket: Socket) {
        try {
            socket.use { sock ->
                sock.soTimeout = 5_000
                val input = DataInputStream(sock.getInputStream())
                val incoming = ByteArray(HANDSHAKE_LEN)
                input.readFully(incoming)

                // Kiểm tra byte đầu tiên = 19 và chuỗi "BitTorrent protocol"
                if (incoming[0].toInt() != 19) return
                val proto = String(incoming, 1, 19, StandardCharsets.US_ASCII)
                if (proto != PROTOCOL_STR) return

                val infoHashBytes = incoming.copyOfRange(28, 48)
                val infoHashHex = infoHashBytes.joinToString("") { "%02x".format(it) }

                val catalog = peerCatalogLookup()
                val ourPeerIdBytes = catalog[infoHashHex] ?: return

                // Tạo gói phản hồi 68 byte chuẩn BitTorrent Handshake
                val reply = ByteArray(HANDSHAKE_LEN)
                reply[0] = 19
                System.arraycopy(
                    PROTOCOL_STR.toByteArray(StandardCharsets.US_ASCII),
                    0,
                    reply,
                    1,
                    19
                )
                // 8 byte reserved = 0 (vị trí 20..27)
                System.arraycopy(infoHashBytes, 0, reply, 28, 20)
                System.arraycopy(ourPeerIdBytes.copyOf(20), 0, reply, 48, 20)

                val out = sock.getOutputStream()
                out.write(reply)
                out.flush()
                delay(250L)
            }
        } catch (_: Exception) {
        }
    }

    fun stop() {
        listenerJob?.cancel()
        listenerJob = null
        boundPort = null
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        serverSocket = null
    }
}
