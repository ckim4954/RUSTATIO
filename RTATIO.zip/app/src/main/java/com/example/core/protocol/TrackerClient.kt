package com.example.core.protocol

import com.example.core.torrent.ClientConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.URI
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit
import kotlin.random.Random

enum class TrackerEvent(val wireValue: String?, val udpId: Int) {
    NONE(null, 0),
    COMPLETED("completed", 1),
    STARTED("started", 2),
    STOPPED("stopped", 3)
}

data class AnnounceRequest(
    val infoHash: ByteArray,
    val peerId: String,
    val port: Int,
    val uploaded: Long,
    val downloaded: Long,
    val left: Long,
    val compact: Boolean = true,
    val noPeerId: Boolean = false,
    val event: TrackerEvent = TrackerEvent.NONE,
    val numWant: Int = 200,
    val key: String,
    val trackerId: String? = null
)

data class AnnounceResponse(
    val interval: Long,
    val minInterval: Long? = null,
    val trackerId: String? = null,
    val complete: Int,
    val incomplete: Int,
    val warning: String? = null
)

data class ScrapeResponse(
    val complete: Int,
    val incomplete: Int,
    val downloaded: Int,
    val name: String? = null
)

class TrackerException(message: String, val isMissingTorrent: Boolean = false) : Exception(message)

class TrackerClient(
    private val httpClient: OkHttpClient = defaultHttpClient
) {
    companion object {
        val defaultHttpClient: OkHttpClient by lazy {
            OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .followRedirects(true)
                .followSslRedirects(true)
                .retryOnConnectionFailure(true)
                .build()
        }

        private const val UDP_PROTOCOL_MAGIC = 0x41727101980L
        private const val UDP_ACTION_CONNECT = 0
        private const val UDP_ACTION_ANNOUNCE = 1
        private const val UDP_ACTION_SCRAPE = 2
        private const val UDP_ACTION_ERROR = 3
    }

    suspend fun announce(
        trackerUrls: List<String>,
        request: AnnounceRequest,
        clientConfig: ClientConfig
    ): AnnounceResponse = withContext(Dispatchers.IO) {
        var lastError: Exception? = null
        val urls = trackerUrls.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        if (urls.isEmpty()) {
            throw TrackerException("Tệp torrent không có URL Tracker hợp lệ")
        }

        // Ưu tiên các HTTP/HTTPS Tracker trước nếu danh sách có cả HTTP và UDP
        val orderedUrls = urls.sortedBy { if (it.startsWith("udp://", ignoreCase = true)) 1 else 0 }

        for (url in orderedUrls) {
            try {
                return@withContext if (url.startsWith("udp://", ignoreCase = true)) {
                    announceUdp(url, request)
                } else {
                    announceHttp(url, request, clientConfig)
                }
            } catch (e: TrackerException) {
                if (e.isMissingTorrent) throw e
                lastError = e
            } catch (e: Exception) {
                lastError = e
            }
        }
        throw lastError ?: TrackerException("Không thể kết nối tới Tracker")
    }

    suspend fun scrape(
        trackerUrls: List<String>,
        infoHash: ByteArray,
        clientConfig: ClientConfig
    ): ScrapeResponse = withContext(Dispatchers.IO) {
        val urls = trackerUrls.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        var lastError: Exception? = null
        val orderedUrls = urls.sortedBy { if (it.startsWith("udp://", ignoreCase = true)) 1 else 0 }

        for (url in orderedUrls) {
            try {
                return@withContext if (url.startsWith("udp://", ignoreCase = true)) {
                    scrapeUdp(url, infoHash)
                } else {
                    scrapeHttp(url, infoHash, clientConfig)
                }
            } catch (e: Exception) {
                lastError = e
            }
        }
        throw lastError ?: TrackerException("Tracker không hỗ trợ Scrape")
    }

    /**
     * Xây dựng URL Announce giống hệt rustatio-core/src/protocol/tracker.rs:
     * - info_hash: mã hóa %XX từng byte
     * - peer_id: giữ nguyên chuỗi ASCII 20 ký tự (-qB5300-xxxxxxxxxxxx)
     */
    fun buildAnnounceUrl(
        trackerUrl: String,
        request: AnnounceRequest,
        clientConfig: ClientConfig
    ): String {
        val infoHashEncoded = encodeRawBytes(request.infoHash)

        val params = mutableListOf(
            "info_hash=$infoHashEncoded",
            "peer_id=${request.peerId}",
            "port=${request.port}",
            "uploaded=${request.uploaded}",
            "downloaded=${request.downloaded}",
            "left=${request.left}",
            "compact=${if (request.compact) "1" else "0"}"
        )
        if (request.noPeerId) {
            params.add("no_peer_id=1")
        }
        request.event.wireValue?.let { params.add("event=$it") }
        params.add("numwant=${request.numWant}")
        params.add("key=${request.key}")
        request.trackerId?.takeIf { it.isNotBlank() }?.let { params.add("trackerid=$it") }
        if (clientConfig.supportsCrypto) {
            params.add("supportcrypto=1")
        }

        val sep = if (trackerUrl.contains('?')) '&' else '?'
        return "$trackerUrl$sep${params.joinToString("&")}"
    }

    private fun announceHttp(
        trackerUrl: String,
        request: AnnounceRequest,
        clientConfig: ClientConfig
    ): AnnounceResponse {
        val fullUrl = buildAnnounceUrl(trackerUrl, request, clientConfig)
        // Không ghi đè Accept-Encoding để OkHttp tự động giải nén Gzip giống reqwest::Client::gzip(true)
        val httpReq = Request.Builder()
            .url(fullUrl)
            .header("User-Agent", clientConfig.userAgent)
            .header("X-Client-OS", clientConfig.osHeaderValue)
            .header("Sec-CH-UA-Platform", "\"Windows\"")
            .header("Sec-CH-UA-Platform-Version", "\"${clientConfig.operatingSystem.platformVersion}\"")
            .get()
            .build()

        httpClient.newCall(httpReq).execute().use { response ->
            if (!response.isSuccessful) {
                throw TrackerException("HTTP ${response.code}")
            }
            val bodyBytes = response.body?.bytes()
                ?: throw TrackerException("Phản hồi từ Tracker trống")
            return parseAnnounceBencode(bodyBytes)
        }
    }

    private fun scrapeHttp(
        trackerUrl: String,
        infoHash: ByteArray,
        clientConfig: ClientConfig
    ): ScrapeResponse {
        if (!trackerUrl.contains("/announce")) {
            throw TrackerException("Tracker không hỗ trợ đường dẫn Scrape")
        }
        val scrapeBase = trackerUrl.replace("/announce", "/scrape")
        val sep = if (scrapeBase.contains('?')) '&' else '?'
        val fullUrl = "$scrapeBase${sep}info_hash=${encodeRawBytes(infoHash)}"

        val httpReq = Request.Builder()
            .url(fullUrl)
            .header("User-Agent", clientConfig.userAgent)
            .header("X-Client-OS", clientConfig.osHeaderValue)
            .header("Sec-CH-UA-Platform", "\"Windows\"")
            .header("Sec-CH-UA-Platform-Version", "\"${clientConfig.operatingSystem.platformVersion}\"")
            .get()
            .build()

        httpClient.newCall(httpReq).execute().use { response ->
            if (!response.isSuccessful) {
                throw TrackerException("Scrape HTTP ${response.code}")
            }
            val bodyBytes = response.body?.bytes()
                ?: throw TrackerException("Phản hồi Scrape trống")
            return parseScrapeBencode(bodyBytes, infoHash)
        }
    }

    fun parseAnnounceBencode(data: ByteArray): AnnounceResponse {
        val dict = try {
            Bencode.parse(data) as? BencodeValue.BDict
        } catch (_: Exception) {
            null
        } ?: throw TrackerException(
            "Tracker trả về phản hồi không đúng chuẩn Bencode (${formatPreview(data)})"
        )

        dict.getString("failure reason")?.let { reason ->
            val missing = isMissingTorrentReason(reason)
            throw TrackerException("Tracker từ chối: $reason", isMissingTorrent = missing)
        }

        val interval = (dict.getLong("interval") ?: dict.getLong("min interval") ?: 1800L).coerceAtLeast(30L)
        val minInterval = dict.getLong("min interval")
        val trackerId = dict.getString("tracker id")
        val warning = dict.getString("warning message")

        var complete = (dict.getLong("complete") ?: dict.getLong("seeders") ?: 0L).toInt().coerceAtLeast(0)
        var incomplete = (dict.getLong("incomplete") ?: dict.getLong("leechers") ?: 0L).toInt().coerceAtLeast(0)

        // Nếu Tracker không trả về trường complete/incomplete mà chỉ trả về danh sách peers/peers6
        if (complete == 0 && incomplete == 0) {
            val peersVal = dict.get("peers")
            val ipv4Count = when (peersVal) {
                is BencodeValue.BBytes -> peersVal.bytes.size / 6
                is BencodeValue.BList -> peersVal.values.size
                else -> 0
            }
            val peers6Bytes = dict.getBytes("peers6")
            val ipv6Count = if (peers6Bytes != null) peers6Bytes.size / 18 else 0
            val totalPeers = ipv4Count + ipv6Count
            if (totalPeers > 0) {
                complete = totalPeers
            }
        }

        return AnnounceResponse(
            interval = interval,
            minInterval = minInterval,
            trackerId = trackerId,
            complete = complete,
            incomplete = incomplete,
            warning = warning
        )
    }

    private fun parseScrapeBencode(data: ByteArray, infoHash: ByteArray): ScrapeResponse {
        val dict = Bencode.parse(data) as? BencodeValue.BDict
            ?: throw TrackerException("Phản hồi Scrape không phải từ điển Bencode")
        val filesDict = dict.getDict("files")
            ?: throw TrackerException("Phản hồi Scrape thiếu mục 'files'")
        val statsDict = filesDict.getByRawBytes(infoHash) as? BencodeValue.BDict
            ?: filesDict.entries.firstOrNull()?.second as? BencodeValue.BDict
            ?: throw TrackerException("Không tìm thấy info_hash trong phản hồi Scrape")

        return ScrapeResponse(
            complete = (statsDict.getLong("complete") ?: 0L).toInt().coerceAtLeast(0),
            incomplete = (statsDict.getLong("incomplete") ?: 0L).toInt().coerceAtLeast(0),
            downloaded = (statsDict.getLong("downloaded") ?: 0L).toInt().coerceAtLeast(0),
            name = statsDict.getString("name")
        )
    }

    private fun announceUdp(trackerUrl: String, request: AnnounceRequest): AnnounceResponse {
        val cleanUrl = trackerUrl.substringBefore("/")
            .let { if (trackerUrl.startsWith("udp://", ignoreCase = true)) trackerUrl else "udp://$trackerUrl" }
        val uri = URI(cleanUrl)
        val host = uri.host ?: throw TrackerException("Địa chỉ UDP Tracker thiếu host")
        val port = if (uri.port > 0) uri.port else 80

        DatagramSocket().use { socket ->
            socket.soTimeout = 8_000
            val address = InetAddress.getByName(host)

            // 1. Connect step (BEP-15)
            val connectTxId = Random.nextInt()
            val connectBuf = ByteBuffer.allocate(16).order(ByteOrder.BIG_ENDIAN).apply {
                putLong(UDP_PROTOCOL_MAGIC)
                putInt(UDP_ACTION_CONNECT)
                putInt(connectTxId)
            }
            socket.send(DatagramPacket(connectBuf.array(), 16, address, port))

            val connectResp = ByteArray(16)
            val connectPacket = DatagramPacket(connectResp, connectResp.size)
            socket.receive(connectPacket)
            if (connectPacket.length < 16) {
                throw TrackerException("Phản hồi kết nối UDP Tracker quá ngắn")
            }
            val respBuf = ByteBuffer.wrap(connectResp).order(ByteOrder.BIG_ENDIAN)
            val action = respBuf.int
            val rxTxId = respBuf.int
            if (action != UDP_ACTION_CONNECT || rxTxId != connectTxId) {
                throw TrackerException("Xác thực kết nối UDP Tracker thất bại")
            }
            val connectionId = respBuf.long

            // 2. Announce step (98 bytes)
            val announceTxId = Random.nextInt()
            val peerIdBytes = request.peerId.toByteArray(StandardCharsets.ISO_8859_1).copyOf(20)
            val keyInt = request.key.toLongOrNull(16)?.toInt() ?: Random.nextInt()

            val annBuf = ByteBuffer.allocate(98).order(ByteOrder.BIG_ENDIAN).apply {
                putLong(connectionId)
                putInt(UDP_ACTION_ANNOUNCE)
                putInt(announceTxId)
                put(request.infoHash.copyOf(20))
                put(peerIdBytes)
                putLong(request.downloaded)
                putLong(request.left)
                putLong(request.uploaded)
                putInt(request.event.udpId)
                putInt(0) // Default IP 0
                putInt(keyInt)
                putInt(request.numWant)
                putShort(request.port.toShort())
            }
            socket.send(DatagramPacket(annBuf.array(), 98, address, port))

            val annResp = ByteArray(1024)
            val annPacket = DatagramPacket(annResp, annResp.size)
            socket.receive(annPacket)
            if (annPacket.length < 8) {
                throw TrackerException("Phản hồi Announce UDP quá ngắn")
            }
            val inBuf = ByteBuffer.wrap(annResp, 0, annPacket.length).order(ByteOrder.BIG_ENDIAN)
            val annAction = inBuf.int
            val annRxTxId = inBuf.int
            if (annRxTxId != announceTxId) {
                throw TrackerException("Mã giao dịch UDP Tracker không khớp")
            }
            if (annAction == UDP_ACTION_ERROR) {
                val errText = String(annResp, 8, annPacket.length - 8, StandardCharsets.UTF_8)
                throw TrackerException(
                    "UDP Tracker: $errText",
                    isMissingTorrent = isMissingTorrentReason(errText)
                )
            }
            if (annAction != UDP_ACTION_ANNOUNCE || annPacket.length < 20) {
                throw TrackerException("Phản hồi Announce UDP không hợp lệ")
            }
            val interval = inBuf.int.toLong().coerceAtLeast(30L)
            val leechers = inBuf.int.coerceAtLeast(0)
            val seeders = inBuf.int.coerceAtLeast(0)

            return AnnounceResponse(
                interval = interval,
                complete = seeders,
                incomplete = leechers
            )
        }
    }

    private fun scrapeUdp(trackerUrl: String, infoHash: ByteArray): ScrapeResponse {
        val uri = URI(trackerUrl)
        val host = uri.host ?: throw TrackerException("Địa chỉ UDP Tracker thiếu host")
        val port = if (uri.port > 0) uri.port else 80

        DatagramSocket().use { socket ->
            socket.soTimeout = 6_000
            val address = InetAddress.getByName(host)

            val connectTxId = Random.nextInt()
            val connectBuf = ByteBuffer.allocate(16).order(ByteOrder.BIG_ENDIAN).apply {
                putLong(UDP_PROTOCOL_MAGIC)
                putInt(UDP_ACTION_CONNECT)
                putInt(connectTxId)
            }
            socket.send(DatagramPacket(connectBuf.array(), 16, address, port))

            val connectResp = ByteArray(16)
            socket.receive(DatagramPacket(connectResp, connectResp.size))
            val respBuf = ByteBuffer.wrap(connectResp).order(ByteOrder.BIG_ENDIAN)
            if (respBuf.int != UDP_ACTION_CONNECT || respBuf.int != connectTxId) {
                throw TrackerException("Kết nối Scrape UDP thất bại")
            }
            val connectionId = respBuf.long

            val scrapeTxId = Random.nextInt()
            val scrapeBuf = ByteBuffer.allocate(36).order(ByteOrder.BIG_ENDIAN).apply {
                putLong(connectionId)
                putInt(UDP_ACTION_SCRAPE)
                putInt(scrapeTxId)
                put(infoHash.copyOf(20))
            }
            socket.send(DatagramPacket(scrapeBuf.array(), 36, address, port))

            val scrapeResp = ByteArray(64)
            val pkt = DatagramPacket(scrapeResp, scrapeResp.size)
            socket.receive(pkt)
            if (pkt.length < 20) throw TrackerException("Phản hồi Scrape UDP quá ngắn")
            val inBuf = ByteBuffer.wrap(scrapeResp, 0, pkt.length).order(ByteOrder.BIG_ENDIAN)
            val action = inBuf.int
            val rxTx = inBuf.int
            if (action != UDP_ACTION_SCRAPE || rxTx != scrapeTxId) {
                throw TrackerException("Phản hồi Scrape UDP không hợp lệ")
            }
            val seeders = inBuf.int.coerceAtLeast(0)
            val completed = inBuf.int.coerceAtLeast(0)
            val leechers = inBuf.int.coerceAtLeast(0)
            return ScrapeResponse(complete = seeders, incomplete = leechers, downloaded = completed)
        }
    }

    private fun isMissingTorrentReason(reason: String): Boolean {
        val lower = reason.lowercase()
        return lower.contains("torrent not found") ||
            lower.contains("not registered") ||
            lower.contains("unregistered torrent") ||
            lower.contains("unknown torrent") ||
            lower.contains("torrent deleted") ||
            lower.contains("torrent does not exist")
    }

    private fun encodeRawBytes(bytes: ByteArray): String {
        val sb = StringBuilder(bytes.size * 3)
        for (b in bytes) {
            sb.append(String.format("%%%02X", b.toInt() and 0xFF))
        }
        return sb.toString()
    }

    private fun formatPreview(data: ByteArray): String {
        if (data.isEmpty()) return "Dữ liệu trống"
        val preview = String(data, 0, minOf(data.size, 80), StandardCharsets.UTF_8)
            .replace("\n", " ")
            .trim()
        return if (preview.isNotEmpty()) preview else "${data.size} byte nhị phân"
    }
}
