package com.example.core.torrent

import com.example.core.protocol.Bencode
import com.example.core.protocol.BencodeException
import com.example.core.protocol.BencodeValue
import java.net.URI
import java.security.MessageDigest

data class TorrentFileEntry(
    val path: List<String>,
    val length: Long
)

data class TorrentInfo(
    val infoHash: ByteArray,
    val infoHashHex: String,
    val announce: String,
    val announceList: List<List<String>>,
    val name: String,
    val totalSize: Long,
    val pieceLength: Long,
    val numPieces: Int,
    val creationDate: Long?,
    val comment: String?,
    val createdBy: String?,
    val isSingleFile: Boolean,
    val fileCount: Int,
    val files: List<TorrentFileEntry> = emptyList()
) {
    fun getAllTrackerUrls(): List<String> {
        val urls = mutableListOf<String>()
        if (announce.isNotBlank()) {
            urls.add(announce.trim())
        }
        announceList.flatten().forEach { url ->
            val trimmed = url.trim()
            if (trimmed.isNotEmpty() && !urls.contains(trimmed)) {
                urls.add(trimmed)
            }
        }
        return urls
    }

    fun trackerHost(): String {
        val primary = getAllTrackerUrls().firstOrNull() ?: return "Không rõ Tracker"
        return try {
            URI(primary).host ?: primary
        } catch (_: Exception) {
            primary.substringAfter("://").substringBefore("/").substringBefore(":")
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is TorrentInfo) return false
        return infoHashHex == other.infoHashHex
    }

    override fun hashCode(): Int = infoHashHex.hashCode()

    companion object {
        fun fromBytes(data: ByteArray): TorrentInfo {
            val root = Bencode.parse(data) as? BencodeValue.BDict
                ?: throw BencodeException("Tệp .torrent không hợp lệ (gốc không phải từ điển)")

            val infoBytes = Bencode.extractInfoBytes(data)
            val infoHash = MessageDigest.getInstance("SHA-1").digest(infoBytes)
            val infoHashHex = infoHash.joinToString("") { "%02x".format(it) }

            val infoDict = root.getDict("info")
                ?: throw BencodeException("Tệp .torrent thiếu mục 'info'")

            val announceList = parseAnnounceList(root)
            val primaryAnnounce = root.getString("announce")?.trim()?.takeIf { it.isNotEmpty() }
                ?: announceList.flatten().firstOrNull { it.isNotBlank() }
                ?: throw BencodeException("Tệp .torrent không chứa địa chỉ Tracker (announce URL)")

            val name = infoDict.getString("name")?.takeIf { it.isNotBlank() }
                ?: "Torrent-$infoHashHex"

            val pieceLength = infoDict.getLong("piece length") ?: 0L
            val piecesBytes = infoDict.getBytes("pieces")
            val numPieces = if (piecesBytes != null) piecesBytes.size / 20 else 0

            val singleLength = infoDict.getLong("length")
            val filesList = mutableListOf<TorrentFileEntry>()
            val totalSize: Long
            val isSingleFile: Boolean
            val fileCount: Int

            if (singleLength != null) {
                totalSize = singleLength.coerceAtLeast(0L)
                isSingleFile = true
                fileCount = 1
                filesList.add(TorrentFileEntry(listOf(name), totalSize))
            } else {
                val rawFiles = infoDict.getList("files")
                    ?: throw BencodeException("Tệp .torrent thiếu kích thước (length hoặc files)")
                var sum = 0L
                for (item in rawFiles) {
                    val fileDict = item as? BencodeValue.BDict ?: continue
                    val len = (fileDict.getLong("length") ?: 0L).coerceAtLeast(0L)
                    val pathParts = fileDict.getList("path")
                        ?.mapNotNull { (it as? BencodeValue.BBytes)?.asUtf8() }
                        ?: emptyList()
                    sum += len
                    filesList.add(TorrentFileEntry(pathParts, len))
                }
                totalSize = sum
                isSingleFile = false
                fileCount = filesList.size.coerceAtLeast(1)
            }

            return TorrentInfo(
                infoHash = infoHash,
                infoHashHex = infoHashHex,
                announce = primaryAnnounce,
                announceList = announceList,
                name = name,
                totalSize = totalSize,
                pieceLength = pieceLength,
                numPieces = numPieces,
                creationDate = root.getLong("creation date"),
                comment = root.getString("comment"),
                createdBy = root.getString("created by"),
                isSingleFile = isSingleFile,
                fileCount = fileCount,
                files = filesList
            )
        }

        private fun parseAnnounceList(root: BencodeValue.BDict): List<List<String>> {
            val rawTiers = root.getList("announce-list") ?: return emptyList()
            return rawTiers.mapNotNull { tierVal ->
                val tierList = (tierVal as? BencodeValue.BList)?.values ?: return@mapNotNull null
                val urls = tierList.mapNotNull { urlVal ->
                    (urlVal as? BencodeValue.BBytes)?.asUtf8()?.trim()?.takeIf { it.isNotEmpty() }
                }
                urls.takeIf { it.isNotEmpty() }
            }
        }
    }
}
