package com.example.core.presets

import com.example.core.torrent.ClientType
import com.example.core.torrent.OperatingSystem
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class PostStopAction(val wireName: String, val labelVi: String) {
    IDLE("idle", "Tạm nghỉ (giữ kết nối 0 KB/s)"),
    STOP_SEEDING("stop_seeding", "Dừng hẳn phiên Torrent"),
    DELETE_INSTANCE("delete_instance", "Tự động xóa khỏi danh sách");

    companion object {
        fun fromWire(value: String?): PostStopAction {
            return entries.firstOrNull { it.wireName.equals(value, ignoreCase = true) } ?: IDLE
        }
    }
}

data class PresetSettings(
    val selectedClient: String = ClientType.QBITTORRENT.id,
    val selectedClientVersion: String = ClientType.QBITTORRENT.defaultVersion,
    val operatingSystem: String = OperatingSystem.WINDOWS_10.id,
    val port: Int = 6881,
    val vpnPortSync: Boolean = false,
    val uploadRate: Double = 500.0, // KB/s
    val downloadRate: Double = 0.0, // KB/s
    val completionPercent: Double = 100.0,
    val randomizeRates: Boolean = true,
    val randomRangePercent: Double = 20.0,
    val updateIntervalSeconds: Long = 5L,
    val scrapeIntervalSeconds: Long = 60L,
    val progressiveRatesEnabled: Boolean = false,
    val targetUploadRate: Double = 1000.0,
    val targetDownloadRate: Double = 0.0,
    val progressiveDurationHours: Double = 1.0,
    val stopAtRatioEnabled: Boolean = false,
    val stopAtRatio: Double = 2.0,
    val randomizeRatio: Boolean = false,
    val randomRatioRangePercent: Double = 10.0,
    val stopAtUploadedEnabled: Boolean = false,
    val stopAtUploadedGB: Double = 10.0,
    val stopAtDownloadedEnabled: Boolean = false,
    val stopAtDownloadedGB: Double = 10.0,
    val stopAtSeedTimeEnabled: Boolean = false,
    val stopAtSeedTimeHours: Double = 24.0,
    val idleWhenNoLeechers: Boolean = false,
    val idleWhenNoSeeders: Boolean = false,
    val postStopAction: String = PostStopAction.IDLE.wireName
) {
    fun toJsonObject(): JSONObject = JSONObject().apply {
        put("selectedClient", selectedClient)
        put("selectedClientVersion", selectedClientVersion)
        put("operatingSystem", operatingSystem)
        put("port", port)
        put("vpnPortSync", vpnPortSync)
        put("uploadRate", uploadRate)
        put("downloadRate", downloadRate)
        put("completionPercent", completionPercent)
        put("randomizeRates", randomizeRates)
        put("randomRangePercent", randomRangePercent)
        put("updateIntervalSeconds", updateIntervalSeconds)
        put("scrapeInterval", scrapeIntervalSeconds)
        put("progressiveRatesEnabled", progressiveRatesEnabled)
        put("targetUploadRate", targetUploadRate)
        put("targetDownloadRate", targetDownloadRate)
        put("progressiveDurationHours", progressiveDurationHours)
        put("stopAtRatioEnabled", stopAtRatioEnabled)
        put("stopAtRatio", stopAtRatio)
        put("randomizeRatio", randomizeRatio)
        put("randomRatioRangePercent", randomRatioRangePercent)
        put("stopAtUploadedEnabled", stopAtUploadedEnabled)
        put("stopAtUploadedGB", stopAtUploadedGB)
        put("stopAtDownloadedEnabled", stopAtDownloadedEnabled)
        put("stopAtDownloadedGB", stopAtDownloadedGB)
        put("stopAtSeedTimeEnabled", stopAtSeedTimeEnabled)
        put("stopAtSeedTimeHours", stopAtSeedTimeHours)
        put("idleWhenNoLeechers", idleWhenNoLeechers)
        put("idleWhenNoSeeders", idleWhenNoSeeders)
        put("postStopAction", postStopAction)
    }

    companion object {
        fun fromJsonObject(obj: JSONObject?): PresetSettings {
            if (obj == null) return PresetSettings()
            val clientType = ClientType.fromId(obj.optString("selectedClient", "qbittorrent"))
            val rawVer = obj.optString("selectedClientVersion", "").takeIf { it.isNotBlank() }
                ?: clientType.defaultVersion
            val os = OperatingSystem.fromId(obj.optString("operatingSystem", "win10"))
            val portVal = obj.optInt("port", clientType.defaultPort).coerceIn(1, 65535)
            return PresetSettings(
                selectedClient = clientType.id,
                selectedClientVersion = rawVer,
                operatingSystem = os.id,
                port = portVal,
                vpnPortSync = obj.optBoolean("vpnPortSync", false),
                uploadRate = obj.optDouble("uploadRate", 500.0).coerceAtLeast(0.0),
                downloadRate = obj.optDouble("downloadRate", 0.0).coerceAtLeast(0.0),
                completionPercent = obj.optDouble("completionPercent", 100.0).coerceIn(0.0, 100.0),
                randomizeRates = obj.optBoolean("randomizeRates", true),
                randomRangePercent = obj.optDouble("randomRangePercent", 20.0).coerceIn(0.0, 100.0),
                updateIntervalSeconds = obj.optLong("updateIntervalSeconds", 5L).coerceAtLeast(1L),
                scrapeIntervalSeconds = obj.optLong("scrapeInterval", 60L).coerceAtLeast(15L),
                progressiveRatesEnabled = obj.optBoolean("progressiveRatesEnabled", false),
                targetUploadRate = obj.optDouble("targetUploadRate", 1000.0).coerceAtLeast(0.0),
                targetDownloadRate = obj.optDouble("targetDownloadRate", 0.0).coerceAtLeast(0.0),
                progressiveDurationHours = obj.optDouble("progressiveDurationHours", 1.0).coerceAtLeast(0.1),
                stopAtRatioEnabled = obj.optBoolean("stopAtRatioEnabled", false),
                stopAtRatio = obj.optDouble("stopAtRatio", 2.0).coerceAtLeast(0.1),
                randomizeRatio = obj.optBoolean("randomizeRatio", false),
                randomRatioRangePercent = obj.optDouble("randomRatioRangePercent", 10.0).coerceIn(0.0, 100.0),
                stopAtUploadedEnabled = obj.optBoolean("stopAtUploadedEnabled", false),
                stopAtUploadedGB = obj.optDouble("stopAtUploadedGB", 10.0).coerceAtLeast(0.1),
                stopAtDownloadedEnabled = obj.optBoolean("stopAtDownloadedEnabled", false),
                stopAtDownloadedGB = obj.optDouble("stopAtDownloadedGB", 10.0).coerceAtLeast(0.1),
                stopAtSeedTimeEnabled = obj.optBoolean("stopAtSeedTimeEnabled", false),
                stopAtSeedTimeHours = obj.optDouble("stopAtSeedTimeHours", 24.0).coerceAtLeast(0.1),
                idleWhenNoLeechers = obj.optBoolean("idleWhenNoLeechers", false),
                idleWhenNoSeeders = obj.optBoolean("idleWhenNoSeeders", false),
                postStopAction = PostStopAction.fromWire(obj.optString("postStopAction", "idle")).wireName
            )
        }
    }
}

data class Preset(
    val id: String,
    val name: String,
    val description: String,
    val icon: String = "scale",
    val recommended: Boolean = false,
    val custom: Boolean = false,
    val createdAt: String? = null,
    val settings: PresetSettings,
    val tips: List<String> = emptyList()
) {
    fun toExportJsonString(): String {
        val root = JSONObject().apply {
            put("version", 1)
            put("type", "rustatio-preset")
            put("id", id)
            put("name", name)
            put("description", description)
            put("icon", icon)
            put("custom", true)
            put("createdAt", createdAt ?: currentIsoTimestamp())
            put("settings", settings.toJsonObject())
            if (tips.isNotEmpty()) {
                put("tips", JSONArray(tips))
            }
        }
        return root.toString(2)
    }

    companion object {
        fun currentIsoTimestamp(): String {
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            return sdf.format(Date())
        }

        fun parseImportedJson(jsonText: String): List<Preset> {
            val trimmed = jsonText.trim()
            if (trimmed.isEmpty()) throw IllegalArgumentException("Nội dung tệp JSON trống")

            return if (trimmed.startsWith("[")) {
                val arr = JSONArray(trimmed)
                val result = mutableListOf<Preset>()
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i) ?: continue
                    result.add(fromJsonObject(item, index = i))
                }
                if (result.isEmpty()) throw IllegalArgumentException("Không tìm thấy Preset hợp lệ trong mảng JSON")
                result
            } else {
                val obj = JSONObject(trimmed)
                if (obj.has("presets") && obj.opt("presets") is JSONArray) {
                    val arr = obj.getJSONArray("presets")
                    val result = mutableListOf<Preset>()
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        result.add(fromJsonObject(item, index = i))
                    }
                    result
                } else {
                    listOf(fromJsonObject(obj, index = 0))
                }
            }
        }

        fun fromJsonObject(obj: JSONObject, index: Int = 0): Preset {
            val settingsObj = obj.optJSONObject("settings") ?: obj
            val name = obj.optString("name", "").trim().takeIf { it.isNotEmpty() }
                ?: "Preset Nhập #${index + 1}"
            val rawId = obj.optString("id", "").trim()
            val safeId = if (rawId.isEmpty() || BuiltInPresets.isBuiltInId(rawId)) {
                "custom-${System.currentTimeMillis()}-$index"
            } else {
                rawId
            }
            val desc = obj.optString("description", "").trim().takeIf { it.isNotEmpty() }
                ?: "Cấu hình tùy chỉnh được nhập từ tệp JSON"
            val icon = obj.optString("icon", "star").takeIf { it.isNotBlank() } ?: "star"
            val createdAt = obj.optString("createdAt", obj.optString("created_at", currentIsoTimestamp()))
            val tipsArr = obj.optJSONArray("tips")
            val tips = mutableListOf<String>()
            if (tipsArr != null) {
                for (i in 0 until tipsArr.length()) {
                    tipsArr.optString(i)?.takeIf { it.isNotBlank() }?.let { tips.add(it) }
                }
            }
            return Preset(
                id = safeId,
                name = name,
                description = desc,
                icon = icon,
                recommended = false,
                custom = true,
                createdAt = createdAt,
                settings = PresetSettings.fromJsonObject(settingsObj),
                tips = tips
            )
        }
    }
}

object BuiltInPresets {
    /**
     * 4 Built-in Presets chuẩn từ Rustatio 2.14.1 (đã loại bỏ hoàn toàn Partial Download theo yêu cầu).
     */
    val all: List<Preset> = listOf(
        Preset(
            id = "balanced",
            name = "Cân Bằng (Balanced Seeder)",
            description = "Tốc độ cày Ratio ổn định với mức độ an toàn cao cho hầu hết Tracker",
            icon = "scale",
            recommended = true,
            custom = false,
            settings = PresetSettings(
                selectedClient = ClientType.QBITTORRENT.id,
                selectedClientVersion = "5.3.0",
                operatingSystem = OperatingSystem.WINDOWS_10.id,
                port = 6881,
                uploadRate = 500.0,
                downloadRate = 0.0,
                randomizeRates = true,
                randomRangePercent = 20.0,
                progressiveRatesEnabled = false,
                updateIntervalSeconds = 5L,
                completionPercent = 100.0,
                stopAtRatioEnabled = true,
                stopAtRatio = 2.0,
                stopAtUploadedEnabled = false,
                stopAtDownloadedEnabled = false,
                stopAtSeedTimeEnabled = false,
                idleWhenNoLeechers = false
            ),
            tips = listOf(
                "Tốc độ tải lên 500 KB/s rất tự nhiên với đường truyền cáp quang hiện đại",
                "Tải xuống 0 KB/s vì bạn đang đóng vai trò Seeder đã hoàn tất 100%",
                "Biến thiên ngẫu nhiên ±20% tái tạo dao động băng thông thực tế",
                "Tự động dừng ở Ratio 2.0 — ngưỡng an toàn cho đa số Private Tracker"
            )
        ),
        Preset(
            id = "fast",
            name = "Tăng Tốc (Fast Seeder)",
            description = "Tăng nhanh chỉ số Ratio với tốc độ lũy tiến — phù hợp Tracker thoáng",
            icon = "rocket",
            recommended = false,
            custom = false,
            settings = PresetSettings(
                selectedClient = ClientType.UTORRENT.id,
                selectedClientVersion = "3.5.5",
                operatingSystem = OperatingSystem.WINDOWS_10.id,
                port = 6881,
                uploadRate = 1000.0,
                downloadRate = 0.0,
                randomizeRates = true,
                randomRangePercent = 15.0,
                progressiveRatesEnabled = true,
                targetUploadRate = 2000.0,
                targetDownloadRate = 0.0,
                progressiveDurationHours = 2.0,
                updateIntervalSeconds = 5L,
                completionPercent = 100.0,
                stopAtRatioEnabled = true,
                stopAtRatio = 3.0,
                stopAtUploadedEnabled = true,
                stopAtUploadedGB = 50.0,
                stopAtDownloadedEnabled = false,
                stopAtSeedTimeEnabled = false,
                idleWhenNoLeechers = false
            ),
            tips = listOf(
                "Tăng tốc mượt mà từ 1 MB/s lên 2 MB/s trong 2 giờ để tránh đột biến",
                "Tự động dừng khi đạt Ratio 3.0 hoặc đã tải lên đủ 50 GB",
                "Khuyên dùng trên các Tracker có cơ chế kiểm duyệt linh hoạt"
            )
        ),
        Preset(
            id = "seedbox",
            name = "Chế Độ Seedbox (Seedbox Mode)",
            description = "Giả lập máy chủ Seedbox chuyên dụng với băng thông tải lên cực cao",
            icon = "server",
            recommended = false,
            custom = false,
            settings = PresetSettings(
                selectedClient = ClientType.TRANSMISSION.id,
                selectedClientVersion = "4.1.4",
                operatingSystem = OperatingSystem.WINDOWS_12.id,
                port = 51413,
                uploadRate = 5000.0,
                downloadRate = 0.0,
                randomizeRates = true,
                randomRangePercent = 10.0,
                progressiveRatesEnabled = false,
                updateIntervalSeconds = 5L,
                completionPercent = 100.0,
                stopAtRatioEnabled = false,
                stopAtUploadedEnabled = false,
                stopAtDownloadedEnabled = false,
                stopAtSeedTimeEnabled = false,
                idleWhenNoLeechers = true
            ),
            tips = listOf(
                "Tốc độ tải lên 5 MB/s tiêu chuẩn của các máy chủ Seedbox tầm trung",
                "Độ dao động thấp (±10%) mô phỏng đường truyền trung tâm dữ liệu ổn định",
                "Tự động tạm nghỉ (0 KB/s) khi không có Leecher tải xuống"
            )
        ),
        Preset(
            id = "stealth",
            name = "Ẩn Danh An Toàn (Stealth Seeder)",
            description = "Tích lũy Ratio chậm rãi, ổn định — độ an toàn tối đa trên Tracker khắt khe",
            icon = "eye-off",
            recommended = false,
            custom = false,
            settings = PresetSettings(
                selectedClient = ClientType.QBITTORRENT.id,
                selectedClientVersion = "5.3.0",
                operatingSystem = OperatingSystem.WINDOWS_7.id,
                port = 6881,
                uploadRate = 100.0,
                downloadRate = 0.0,
                randomizeRates = true,
                randomRangePercent = 25.0,
                progressiveRatesEnabled = true,
                targetUploadRate = 300.0,
                targetDownloadRate = 0.0,
                progressiveDurationHours = 4.0,
                updateIntervalSeconds = 10L,
                completionPercent = 100.0,
                stopAtRatioEnabled = true,
                stopAtRatio = 1.5,
                stopAtUploadedEnabled = false,
                stopAtDownloadedEnabled = false,
                stopAtSeedTimeEnabled = true,
                stopAtSeedTimeHours = 48.0,
                idleWhenNoLeechers = true
            ),
            tips = listOf(
                "Tăng dần từ 100 lên 300 KB/s trong 4 giờ giống hệt hành vi người dùng thật",
                "Biến thiên ngẫu nhiên ±25% mô phỏng mạng gia đình tự nhiên",
                "Giới hạn Ratio 1.5 hoặc dừng sau 48 giờ giúp tránh mọi nghi ngờ"
            )
        )
    )

    fun isBuiltInId(id: String): Boolean = all.any { it.id.equals(id, ignoreCase = true) }

    fun findById(id: String?): Preset? = all.firstOrNull { it.id.equals(id, ignoreCase = true) }
}
