package com.example.core.protocol

import java.nio.charset.StandardCharsets

sealed class BencodeValue {
    class BBytes(val bytes: ByteArray) : BencodeValue() {
        fun asUtf8(): String = String(bytes, StandardCharsets.UTF_8)
    }

    class BInt(val value: Long) : BencodeValue()

    class BList(val values: List<BencodeValue>) : BencodeValue()

    class BDict(
        val entries: List<Pair<ByteArray, BencodeValue>>,
        val rawValueRanges: Map<String, IntRange> = emptyMap()
    ) : BencodeValue() {
        fun get(key: String): BencodeValue? {
            val target = key.toByteArray(StandardCharsets.UTF_8)
            return entries.firstOrNull { it.first.contentEquals(target) }?.second
        }

        fun getByRawBytes(keyBytes: ByteArray): BencodeValue? {
            return entries.firstOrNull { it.first.contentEquals(keyBytes) }?.second
        }

        fun getString(key: String): String? = (get(key) as? BBytes)?.asUtf8()

        fun getLong(key: String): Long? = (get(key) as? BInt)?.value

        fun getBytes(key: String): ByteArray? = (get(key) as? BBytes)?.bytes

        fun getList(key: String): List<BencodeValue>? = (get(key) as? BList)?.values

        fun getDict(key: String): BDict? = get(key) as? BDict
    }
}

class BencodeException(message: String) : Exception(message)

object Bencode {

    fun parse(data: ByteArray): BencodeValue {
        if (data.isEmpty()) {
            throw BencodeException("Dữ liệu Bencode trống")
        }
        val parser = Parser(data)
        return parser.parseValue()
    }

    /**
     * Trích xuất chính xác mảng byte nguyên bản của từ điển "info" trong tệp .torrent
     * để tính mã băm SHA-1 (info_hash 20 byte) chuẩn xác 100% như rustatio-core.
     */
    fun extractInfoBytes(data: ByteArray): ByteArray {
        val root = parse(data) as? BencodeValue.BDict
            ?: throw BencodeException("Cấu trúc tệp .torrent không hợp lệ (gốc không phải từ điển)")
        val range = root.rawValueRanges["info"]
            ?: throw BencodeException("Tệp .torrent thiếu khóa 'info' bắt buộc")
        return data.copyOfRange(range.first, range.last + 1)
    }

    private class Parser(private val data: ByteArray) {
        var pos: Int = 0

        fun parseValue(): BencodeValue {
            if (pos >= data.size) {
                throw BencodeException("Kết thúc dữ liệu bất ngờ tại vị trí $pos")
            }
            return when (val b = data[pos].toInt().toChar()) {
                'i' -> parseInt()
                'l' -> parseList()
                'd' -> parseDict()
                in '0'..'9' -> BencodeValue.BBytes(parseByteArray())
                else -> throw BencodeException("Ký tự Bencode không hợp lệ '$b' tại vị trí $pos")
            }
        }

        private fun parseInt(): BencodeValue.BInt {
            pos++ // skip 'i'
            val end = indexOf('e'.code.toByte(), pos)
            if (end == -1) throw BencodeException("Số nguyên Bencode thiếu ký tự kết thúc 'e'")
            val numStr = String(data, pos, end - pos, StandardCharsets.US_ASCII)
            pos = end + 1
            val value = numStr.toLongOrNull()
                ?: throw BencodeException("Giá trị số nguyên không hợp lệ: $numStr")
            return BencodeValue.BInt(value)
        }

        private fun parseByteArray(): ByteArray {
            val colon = indexOf(':'.code.toByte(), pos)
            if (colon == -1) throw BencodeException("Chuỗi byte Bencode thiếu dấu ':'")
            val lenStr = String(data, pos, colon - pos, StandardCharsets.US_ASCII)
            val length = lenStr.toIntOrNull()
                ?: throw BencodeException("Độ dài chuỗi byte không hợp lệ: $lenStr")
            if (length < 0 || colon + 1 + length > data.size) {
                throw BencodeException("Độ dài chuỗi byte vượt quá kích thước tệp ($length)")
            }
            val start = colon + 1
            val bytes = data.copyOfRange(start, start + length)
            pos = start + length
            return bytes
        }

        private fun parseList(): BencodeValue.BList {
            pos++ // skip 'l'
            val list = mutableListOf<BencodeValue>()
            while (pos < data.size && data[pos] != 'e'.code.toByte()) {
                list.add(parseValue())
            }
            if (pos >= data.size) throw BencodeException("Danh sách Bencode thiếu ký tự kết thúc 'e'")
            pos++ // skip 'e'
            return BencodeValue.BList(list)
        }

        private fun parseDict(): BencodeValue.BDict {
            pos++ // skip 'd'
            val entries = mutableListOf<Pair<ByteArray, BencodeValue>>()
            val rawRanges = mutableMapOf<String, IntRange>()
            while (pos < data.size && data[pos] != 'e'.code.toByte()) {
                val keyBytes = parseByteArray()
                val keyStr = String(keyBytes, StandardCharsets.UTF_8)
                val valStart = pos
                val value = parseValue()
                val valEnd = pos - 1
                entries.add(keyBytes to value)
                rawRanges[keyStr] = valStart..valEnd
            }
            if (pos >= data.size) throw BencodeException("Từ điển Bencode thiếu ký tự kết thúc 'e'")
            pos++ // skip 'e'
            return BencodeValue.BDict(entries, rawRanges)
        }

        private fun indexOf(target: Byte, fromIndex: Int): Int {
            for (i in fromIndex until data.size) {
                if (data[i] == target) return i
            }
            return -1
        }
    }
}
