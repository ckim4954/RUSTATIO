package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.core.presets.Preset
import com.example.core.torrent.ClientConfig
import com.example.core.torrent.ClientType
import com.example.core.torrent.OperatingSystem
import com.example.core.util.FormatUtils
import com.example.data.repository.TorrentUiItem
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.PurpleTertiary
import com.example.ui.theme.SkySecondary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.PendingTorrentDraft
import kotlin.random.Random

@Composable
fun AddTorrentConfigDialog(
    drafts: List<PendingTorrentDraft>,
    allPresets: List<Preset>,
    defaultPresetId: String?,
    onDismiss: () -> Unit,
    onConfirm: (
        preset: Preset,
        clientType: ClientType,
        clientVersion: String,
        port: Int,
        operatingSystem: OperatingSystem,
        autoStart: Boolean
    ) -> Unit
) {
    val initialPreset = remember(allPresets, defaultPresetId) {
        allPresets.firstOrNull { it.id == defaultPresetId } ?: allPresets.first()
    }
    var selectedPreset by remember { mutableStateOf(initialPreset) }
    var selectedClient by remember {
        mutableStateOf(ClientType.fromId(initialPreset.settings.selectedClient))
    }
    var selectedVersion by remember {
        mutableStateOf(
            initialPreset.settings.selectedClientVersion.ifBlank { selectedClient.defaultVersion }
        )
    }
    var portText by remember { mutableStateOf(initialPreset.settings.port.toString()) }
    var selectedOs by remember {
        mutableStateOf(OperatingSystem.fromId(initialPreset.settings.operatingSystem))
    }
    var autoStart by remember { mutableStateOf(true) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .clip(RoundedCornerShape(24.dp)),
            color = ObsidianSurface,
            border = BorderStroke(1.dp, ObsidianBorder)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderOpen,
                        contentDescription = "Thêm Torrent",
                        tint = EmeraldPrimary,
                        modifier = Modifier.size(26.dp)
                    )
                    Column {
                        Text(
                            text = if (drafts.size == 1) "Thêm Tệp .Torrent Thực Tế" else "Thêm ${drafts.size} Tệp .Torrent",
                            style = MaterialTheme.typography.titleLarge,
                            color = TextPrimary
                        )
                        Text(
                            text = "Xác thực SHA-1 InfoHash & cấu hình định danh gửi tới Tracker",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                // Tóm tắt tệp .torrent thật vừa nạp
                Card(
                    colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
                    border = BorderStroke(1.dp, ObsidianBorder),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val first = drafts.first().info
                        Text(
                            text = first.name,
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Kích thước: ${FormatUtils.formatBytes(first.totalSize)} (${first.fileCount} tệp)",
                                style = MaterialTheme.typography.labelMedium,
                                color = EmeraldPrimary
                            )
                            Text(
                                text = first.trackerHost(),
                                style = MaterialTheme.typography.labelMedium,
                                color = SkySecondary
                            )
                        }
                        Text(
                            text = "SHA-1: ${first.infoHashHex}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (drafts.size > 1) {
                            Text(
                                text = "+ ${drafts.size - 1} tệp torrent khác cùng cấu hình này",
                                style = MaterialTheme.typography.bodySmall,
                                color = PurpleTertiary
                            )
                        }
                    }
                }

                PresetQuickSelectorSection(
                    allPresets = allPresets,
                    selectedPreset = selectedPreset,
                    defaultPresetId = defaultPresetId,
                    onSelectPreset = { preset ->
                        selectedPreset = preset
                        val cType = ClientType.fromId(preset.settings.selectedClient)
                        selectedClient = cType
                        selectedVersion = preset.settings.selectedClientVersion.ifBlank { cType.defaultVersion }
                        portText = preset.settings.port.toString()
                        selectedOs = OperatingSystem.fromId(preset.settings.operatingSystem)
                    }
                )

                ClientOsPortConfigSection(
                    selectedClient = selectedClient,
                    selectedVersion = selectedVersion,
                    portText = portText,
                    selectedOs = selectedOs,
                    onClientChange = { client ->
                        selectedClient = client
                        selectedVersion = client.defaultVersion
                        portText = client.defaultPort.toString()
                    },
                    onVersionChange = { selectedVersion = it },
                    onPortChange = { portText = it },
                    onOsChange = { selectedOs = it }
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(ObsidianSurfaceVariant)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Bắt đầu báo cáo Tracker ngay",
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary
                        )
                        Text(
                            text = "Gửi bản tin event=started ngay sau khi thêm",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    Switch(
                        checked = autoStart,
                        onCheckedChange = { autoStart = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = ObsidianSurface, checkedTrackColor = EmeraldPrimary),
                        modifier = Modifier.testTag("switch_auto_start_torrent")
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("cancel_add_torrent_button")
                    ) {
                        Text("Hủy", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val parsedPort = portText.toIntOrNull()?.coerceIn(1, 65535)
                                ?: selectedClient.defaultPort
                            onConfirm(
                                selectedPreset,
                                selectedClient,
                                selectedVersion,
                                parsedPort,
                                selectedOs,
                                autoStart
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier.testTag("confirm_add_torrent_button")
                    ) {
                        Text("Thêm vào danh sách", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun EditTorrentConfigDialog(
    torrent: TorrentUiItem,
    allPresets: List<Preset>,
    defaultPresetId: String?,
    onDismiss: () -> Unit,
    onSave: (
        preset: Preset,
        clientType: ClientType,
        clientVersion: String,
        port: Int,
        operatingSystem: OperatingSystem
    ) -> Unit
) {
    val currentPreset = remember(torrent, allPresets) {
        allPresets.firstOrNull { it.id == torrent.presetId } ?: allPresets.first()
    }
    var selectedPreset by remember { mutableStateOf(currentPreset) }
    var selectedClient by remember {
        mutableStateOf(ClientType.fromId(torrent.settings.selectedClient))
    }
    var selectedVersion by remember { mutableStateOf(torrent.clientVersion) }
    var portText by remember { mutableStateOf(torrent.port.toString()) }
    var selectedOs by remember { mutableStateOf(torrent.operatingSystem) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .clip(RoundedCornerShape(24.dp)),
            color = ObsidianSurface,
            border = BorderStroke(1.dp, ObsidianBorder)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Cấu hình Torrent",
                        tint = SkySecondary,
                        modifier = Modifier.size(26.dp)
                    )
                    Column {
                        Text(
                            text = "Cấu Hình Client · OS · Port",
                            style = MaterialTheme.typography.titleLarge,
                            color = TextPrimary
                        )
                        Text(
                            text = torrent.name,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                PresetQuickSelectorSection(
                    allPresets = allPresets,
                    selectedPreset = selectedPreset,
                    defaultPresetId = defaultPresetId,
                    onSelectPreset = { preset ->
                        selectedPreset = preset
                        val cType = ClientType.fromId(preset.settings.selectedClient)
                        selectedClient = cType
                        selectedVersion = preset.settings.selectedClientVersion.ifBlank { cType.defaultVersion }
                        portText = preset.settings.port.toString()
                        selectedOs = OperatingSystem.fromId(preset.settings.operatingSystem)
                    }
                )

                ClientOsPortConfigSection(
                    selectedClient = selectedClient,
                    selectedVersion = selectedVersion,
                    portText = portText,
                    selectedOs = selectedOs,
                    onClientChange = { client ->
                        selectedClient = client
                        selectedVersion = client.defaultVersion
                        portText = client.defaultPort.toString()
                    },
                    onVersionChange = { selectedVersion = it },
                    onPortChange = { portText = it },
                    onOsChange = { selectedOs = it }
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Đóng", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val parsedPort = portText.toIntOrNull()?.coerceIn(1, 65535)
                                ?: selectedClient.defaultPort
                            onSave(
                                selectedPreset,
                                selectedClient,
                                selectedVersion,
                                parsedPort,
                                selectedOs
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier.testTag("save_torrent_config_button")
                    ) {
                        Text("Lưu cấu hình", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun PresetQuickSelectorSection(
    allPresets: List<Preset>,
    selectedPreset: Preset,
    defaultPresetId: String?,
    onSelectPreset: (Preset) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "1. Bộ thông số tốc độ & điều kiện dừng (Preset)",
            style = MaterialTheme.typography.titleSmall,
            color = TextPrimary
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            allPresets.forEach { preset ->
                val isSelected = preset.id == selectedPreset.id
                val isDefault = preset.id == defaultPresetId
                FilterChip(
                    selected = isSelected,
                    onClick = { onSelectPreset(preset) },
                    label = {
                        Text(
                            text = if (isDefault) "${preset.name} ★" else preset.name,
                            style = MaterialTheme.typography.labelLarge
                        )
                    },
                    leadingIcon = if (isSelected) {
                        {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    } else null,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EmeraldPrimary.copy(alpha = 0.22f),
                        selectedLabelColor = EmeraldPrimary,
                        selectedLeadingIconColor = EmeraldPrimary,
                        containerColor = ObsidianSurfaceVariant,
                        labelColor = TextSecondary
                    )
                )
            }
        }
        Text(
            text = "Tốc độ Preset: ↑ ${FormatUtils.formatSpeedKBs(selectedPreset.settings.uploadRate)} · ↓ ${FormatUtils.formatSpeedKBs(selectedPreset.settings.downloadRate)}" +
                if (selectedPreset.settings.stopAtRatioEnabled) " · Dừng ở Ratio ${selectedPreset.settings.stopAtRatio}" else "",
            style = MaterialTheme.typography.labelMedium,
            color = EmeraldPrimary
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ClientOsPortConfigSection(
    selectedClient: ClientType,
    selectedVersion: String,
    portText: String,
    selectedOs: OperatingSystem,
    onClientChange: (ClientType) -> Unit,
    onVersionChange: (String) -> Unit,
    onPortChange: (String) -> Unit,
    onOsChange: (OperatingSystem) -> Unit
) {
    val previewConfig = remember(selectedClient, selectedVersion, selectedOs) {
        ClientConfig.create(selectedClient, selectedVersion, selectedOs)
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        HorizontalDivider(color = ObsidianBorder)

        // Chọn Hệ điều hành giả lập (Windows 7, Windows 10, Windows 12)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.DesktopWindows,
                    contentDescription = null,
                    tint = SkySecondary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Hệ điều hành giả lập (Operating System)",
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OperatingSystem.entries.forEach { os ->
                    val isSelected = os == selectedOs
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onOsChange(os) }
                            .testTag("os_option_${os.id}"),
                        color = if (isSelected) SkySecondary.copy(alpha = 0.18f) else ObsidianSurfaceVariant,
                        border = BorderStroke(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) SkySecondary else ObsidianBorder
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Computer,
                                contentDescription = os.displayName,
                                tint = if (isSelected) SkySecondary else TextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = os.shortBadge,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (isSelected) SkySecondary else TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = os.buildLabel.substringBefore(" ·"),
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                        }
                    }
                }
            }
        }

        // Chọn BitTorrent Client
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Dns,
                    contentDescription = null,
                    tint = EmeraldPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "BitTorrent Client giả lập",
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary
                )
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ClientType.entries.forEach { client ->
                    val isSelected = client == selectedClient
                    FilterChip(
                        selected = isSelected,
                        onClick = { onClientChange(client) },
                        label = { Text(client.displayName) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldPrimary.copy(alpha = 0.22f),
                            selectedLabelColor = EmeraldPrimary,
                            containerColor = ObsidianSurfaceVariant,
                            labelColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("client_chip_${client.id}")
                    )
                }
            }
        }

        // Chọn Phiên bản (Version) của Client
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "Phiên bản ${selectedClient.displayName} (Version)",
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                selectedClient.versions.forEach { ver ->
                    val isVerSelected = ver == selectedVersion
                    FilterChip(
                        selected = isVerSelected,
                        onClick = { onVersionChange(ver) },
                        label = {
                            Text(
                                text = ver,
                                fontFamily = JetBrainsMonoFontFamily
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PurpleTertiary.copy(alpha = 0.25f),
                            selectedLabelColor = TextPrimary,
                            containerColor = ObsidianSurfaceVariant,
                            labelColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("version_chip_$ver")
                    )
                }
            }
        }

        // Cấu hình Cổng (Port)
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Router,
                    contentDescription = null,
                    tint = PurpleTertiary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Cổng lắng nghe (Port: 1 – 65535)",
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = portText,
                    onValueChange = { input ->
                        val digits = input.filter { it.isDigit() }.take(5)
                        onPortChange(digits)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("port_input_field"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    textStyle = MaterialTheme.typography.labelLarge.copy(
                        fontFamily = JetBrainsMonoFontFamily,
                        color = TextPrimary
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = ObsidianBorder,
                        focusedContainerColor = ObsidianSurfaceVariant,
                        unfocusedContainerColor = ObsidianSurfaceVariant
                    )
                )
                OutlinedButton(
                    onClick = { onPortChange(Random.nextInt(10000, 65000).toString()) },
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier.testTag("random_port_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Shuffle,
                        contentDescription = "Ngẫu nhiên Port",
                        tint = SkySecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Ngẫu nhiên", color = TextPrimary)
                }
            }
        }

        // Hộp xem trước chữ ký mạng thực tế gửi tới Tracker
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(ObsidianSurfaceElevated)
                .padding(12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "CHỮ KÝ GỬI TỚI TRACKER (CHUẨN PC)",
                    style = MaterialTheme.typography.labelSmall,
                    color = SkySecondary
                )
                Text(
                    text = "User-Agent: ${previewConfig.userAgent} (Nguyên bản PC)",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextPrimary
                )
                Text(
                    text = "Header OS: X-Client-OS: ${previewConfig.osHeaderValue}",
                    style = MaterialTheme.typography.labelSmall,
                    color = SkySecondary
                )
                Text(
                    text = "Peer-ID: ${previewConfig.peerIdPrefix}************ · Port: ${portText.ifBlank { selectedClient.defaultPort.toString() }}",
                    style = MaterialTheme.typography.labelSmall,
                    color = EmeraldPrimary
                )
            }
        }
    }
}
