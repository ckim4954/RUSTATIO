package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.core.presets.Preset
import com.example.core.presets.PresetSettings
import com.example.core.torrent.ClientType
import com.example.core.torrent.OperatingSystem
import com.example.data.repository.TorrentUiItem
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.SkySecondary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun CustomPresetEditorDialog(
    initialPreset: Preset? = null,
    onDismiss: () -> Unit,
    onSave: (
        name: String,
        description: String,
        settings: PresetSettings,
        existingId: String?,
        setAsDefault: Boolean
    ) -> Unit
) {
    val baseSettings = initialPreset?.settings ?: PresetSettings()
    var name by remember {
        mutableStateOf(
            if (initialPreset != null && initialPreset.custom) initialPreset.name
            else if (initialPreset != null) "${initialPreset.name} (Bản sao)"
            else ""
        )
    }
    var description by remember {
        mutableStateOf(initialPreset?.description ?: "")
    }
    var uploadRateText by remember { mutableStateOf(baseSettings.uploadRate.toInt().toString()) }
    var downloadRateText by remember { mutableStateOf(baseSettings.downloadRate.toInt().toString()) }
    var randomizeRates by remember { mutableStateOf(baseSettings.randomizeRates) }
    var randomRangeText by remember { mutableStateOf(baseSettings.randomRangePercent.toInt().toString()) }
    var progressiveEnabled by remember { mutableStateOf(baseSettings.progressiveRatesEnabled) }
    var targetUploadText by remember { mutableStateOf(baseSettings.targetUploadRate.toInt().toString()) }
    var progressiveHoursText by remember { mutableStateOf(baseSettings.progressiveDurationHours.toString()) }
    var stopAtRatioEnabled by remember { mutableStateOf(baseSettings.stopAtRatioEnabled) }
    var stopAtRatioText by remember { mutableStateOf(baseSettings.stopAtRatio.toString()) }
    var stopAtUploadedEnabled by remember { mutableStateOf(baseSettings.stopAtUploadedEnabled) }
    var stopAtUploadedGBText by remember { mutableStateOf(baseSettings.stopAtUploadedGB.toString()) }
    var idleWhenNoLeechers by remember { mutableStateOf(baseSettings.idleWhenNoLeechers) }

    var selectedClient by remember { mutableStateOf(ClientType.fromId(baseSettings.selectedClient)) }
    var selectedVersion by remember {
        mutableStateOf(baseSettings.selectedClientVersion.ifBlank { selectedClient.defaultVersion })
    }
    var portText by remember { mutableStateOf(baseSettings.port.toString()) }
    var selectedOs by remember { mutableStateOf(OperatingSystem.fromId(baseSettings.operatingSystem)) }
    var setAsDefault by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .clip(RoundedCornerShape(24.dp)),
            color = ObsidianSurface,
            border = BorderStroke(1.dp, ObsidianBorder)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = if (initialPreset?.custom == true) "Chỉnh Sửa Preset Tùy Chỉnh" else "Tạo Preset Tùy Chỉnh Mới",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Tên Preset (Tiếng Việt)") },
                    placeholder = { Text("VD: Cày Ratio Cáp Quang 2MB/s") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_preset_name_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = ObsidianBorder,
                        focusedContainerColor = ObsidianSurfaceVariant,
                        unfocusedContainerColor = ObsidianSurfaceVariant
                    )
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Mô tả ngắn") },
                    placeholder = { Text("VD: Tối ưu cho Private Tracker, tự dừng ở Ratio 2.5") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_preset_desc_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = ObsidianBorder,
                        focusedContainerColor = ObsidianSurfaceVariant,
                        unfocusedContainerColor = ObsidianSurfaceVariant
                    )
                )

                HorizontalDivider(color = ObsidianBorder)
                Text(
                    text = "Thông số Tốc độ & Biến thiên",
                    style = MaterialTheme.typography.titleSmall,
                    color = EmeraldPrimary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = uploadRateText,
                        onValueChange = { uploadRateText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Tải lên (KB/s)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("preset_upload_rate_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = ObsidianBorder,
                            focusedContainerColor = ObsidianSurfaceVariant,
                            unfocusedContainerColor = ObsidianSurfaceVariant
                        )
                    )
                    OutlinedTextField(
                        value = downloadRateText,
                        onValueChange = { downloadRateText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Tải xuống (KB/s)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("preset_download_rate_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkySecondary,
                            unfocusedBorderColor = ObsidianBorder,
                            focusedContainerColor = ObsidianSurfaceVariant,
                            unfocusedContainerColor = ObsidianSurfaceVariant
                        )
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Biến thiên tốc độ ngẫu nhiên (±%)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary
                    )
                    Switch(
                        checked = randomizeRates,
                        onCheckedChange = { randomizeRates = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = ObsidianSurface, checkedTrackColor = EmeraldPrimary)
                    )
                }

                if (randomizeRates) {
                    OutlinedTextField(
                        value = randomRangeText,
                        onValueChange = { randomRangeText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Biên độ dao động (%) — VD: 20") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = ObsidianBorder,
                            focusedContainerColor = ObsidianSurfaceVariant,
                            unfocusedContainerColor = ObsidianSurfaceVariant
                        )
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Tăng tốc lũy tiến theo thời gian",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary
                    )
                    Switch(
                        checked = progressiveEnabled,
                        onCheckedChange = { progressiveEnabled = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = ObsidianSurface, checkedTrackColor = EmeraldPrimary)
                    )
                }

                if (progressiveEnabled) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = targetUploadText,
                            onValueChange = { targetUploadText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                            label = { Text("Đích tải lên (KB/s)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = EmeraldPrimary,
                                unfocusedBorderColor = ObsidianBorder,
                                focusedContainerColor = ObsidianSurfaceVariant,
                                unfocusedContainerColor = ObsidianSurfaceVariant
                            )
                        )
                        OutlinedTextField(
                            value = progressiveHoursText,
                            onValueChange = { progressiveHoursText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                            label = { Text("Thời gian (Giờ)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = EmeraldPrimary,
                                unfocusedBorderColor = ObsidianBorder,
                                focusedContainerColor = ObsidianSurfaceVariant,
                                unfocusedContainerColor = ObsidianSurfaceVariant
                            )
                        )
                    }
                }

                HorizontalDivider(color = ObsidianBorder)
                Text(
                    text = "Điều kiện tự động dừng & Bảo vệ",
                    style = MaterialTheme.typography.titleSmall,
                    color = SkySecondary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Tự dừng khi đạt Ratio mục tiêu", color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = stopAtRatioEnabled,
                        onCheckedChange = { stopAtRatioEnabled = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = ObsidianSurface, checkedTrackColor = EmeraldPrimary)
                    )
                }
                if (stopAtRatioEnabled) {
                    OutlinedTextField(
                        value = stopAtRatioText,
                        onValueChange = { stopAtRatioText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Ngưỡng Ratio dừng (VD: 2.0)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = ObsidianBorder,
                            focusedContainerColor = ObsidianSurfaceVariant,
                            unfocusedContainerColor = ObsidianSurfaceVariant
                        )
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Tự dừng khi tải lên đủ dung lượng (GB)", color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = stopAtUploadedEnabled,
                        onCheckedChange = { stopAtUploadedEnabled = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = ObsidianSurface, checkedTrackColor = EmeraldPrimary)
                    )
                }
                if (stopAtUploadedEnabled) {
                    OutlinedTextField(
                        value = stopAtUploadedGBText,
                        onValueChange = { stopAtUploadedGBText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Giới hạn tải lên (GB)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = ObsidianBorder,
                            focusedContainerColor = ObsidianSurfaceVariant,
                            unfocusedContainerColor = ObsidianSurfaceVariant
                        )
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Tạm nghỉ (0 KB/s) khi không có Leecher", color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = idleWhenNoLeechers,
                        onCheckedChange = { idleWhenNoLeechers = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = ObsidianSurface, checkedTrackColor = EmeraldPrimary)
                    )
                }

                ClientOsPortConfigSection(
                    selectedClient = selectedClient,
                    selectedVersion = selectedVersion,
                    portText = portText,
                    selectedOs = selectedOs,
                    onClientChange = { client ->
                        selectedClient = client
                        selectedVersion = client.defaultVersion
                        portText = client.defaultPort.toString()
                    },
                    onVersionChange = { selectedVersion = it },
                    onPortChange = { portText = it },
                    onOsChange = { selectedOs = it }
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { setAsDefault = !setAsDefault },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = setAsDefault,
                        onCheckedChange = { setAsDefault = it },
                        colors = CheckboxDefaults.colors(checkedColor = EmeraldPrimary)
                    )
                    Text(
                        text = "Đặt làm Preset mặc định sau khi lưu",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Hủy", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val newSettings = baseSettings.copy(
                                selectedClient = selectedClient.id,
                                selectedClientVersion = selectedVersion,
                                operatingSystem = selectedOs.id,
                                port = portText.toIntOrNull()?.coerceIn(1, 65535) ?: selectedClient.defaultPort,
                                uploadRate = uploadRateText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 500.0,
                                downloadRate = downloadRateText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0,
                                randomizeRates = randomizeRates,
                                randomRangePercent = randomRangeText.toDoubleOrNull()?.coerceIn(0.0, 100.0) ?: 20.0,
                                progressiveRatesEnabled = progressiveEnabled,
                                targetUploadRate = targetUploadText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 1000.0,
                                progressiveDurationHours = progressiveHoursText.toDoubleOrNull()?.coerceAtLeast(0.1) ?: 1.0,
                                stopAtRatioEnabled = stopAtRatioEnabled,
                                stopAtRatio = stopAtRatioText.toDoubleOrNull()?.coerceAtLeast(0.1) ?: 2.0,
                                stopAtUploadedEnabled = stopAtUploadedEnabled,
                                stopAtUploadedGB = stopAtUploadedGBText.toDoubleOrNull()?.coerceAtLeast(0.1) ?: 10.0,
                                idleWhenNoLeechers = idleWhenNoLeechers
                            )
                            onSave(
                                name.ifBlank { "Preset Tùy Chỉnh" },
                                description,
                                newSettings,
                                initialPreset?.takeIf { it.custom }?.id,
                                setAsDefault
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier.testTag("save_custom_preset_button")
                    ) {
                        Text("Lưu Preset", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ApplyPresetTargetDialog(
    preset: Preset,
    torrents: List<TorrentUiItem>,
    onDismiss: () -> Unit,
    onApply: (targetTorrentId: String?) -> Unit
) {
    var selectedTargetId by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp)),
            color = ObsidianSurface,
            border = BorderStroke(1.dp, ObsidianBorder)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Áp Dụng Preset \"${preset.name}\"",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Text(
                    text = "Chọn phạm vi áp dụng bộ thông số tốc độ, điều kiện dừng và định danh Client/OS/Port:",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(ObsidianSurfaceVariant)
                        .clickable { selectedTargetId = null }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedTargetId == null,
                        onClick = { selectedTargetId = null },
                        colors = RadioButtonDefaults.colors(selectedColor = EmeraldPrimary)
                    )
                    Column {
                        Text(
                            text = "Áp dụng cho tất cả Torrent (${torrents.size})",
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary
                        )
                        Text(
                            text = "Đồng bộ toàn bộ danh sách với Preset này",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                torrents.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(ObsidianSurfaceVariant)
                            .clickable { selectedTargetId = item.id }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedTargetId == item.id,
                            onClick = { selectedTargetId = item.id },
                            colors = RadioButtonDefaults.colors(selectedColor = EmeraldPrimary)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.name,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Hiện tại: ${item.presetName} · ${item.clientDisplayName} · ${item.operatingSystem.shortBadge}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Hủy", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onApply(selectedTargetId) },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier.testTag("confirm_apply_preset_button")
                    ) {
                        Text("Áp dụng ngay", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun PasteJsonImportDialog(
    onDismiss: () -> Unit,
    onPickFile: () -> Unit,
    onImportRawJson: (String) -> Unit
) {
    var jsonText by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp)),
            color = ObsidianSurface,
            border = BorderStroke(1.dp, ObsidianBorder)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Nhập Preset (Import JSON)",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Text(
                    text = "Hỗ trợ tệp .json chuẩn rustatio-preset từ PC hoặc dán trực tiếp chuỗi JSON:",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                Button(
                    onClick = {
                        onDismiss()
                        onPickFile()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pick_json_file_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = SkySecondary)
                ) {
                    Text("Chọn tệp .JSON từ thiết bị", color = ObsidianSurface, fontWeight = FontWeight.Bold)
                }

                OutlinedTextField(
                    value = jsonText,
                    onValueChange = { jsonText = it },
                    label = { Text("Hoặc dán nội dung JSON vào đây") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .testTag("raw_json_import_input"),
                    textStyle = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = JetBrainsMonoFontFamily,
                        color = TextPrimary
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = ObsidianBorder,
                        focusedContainerColor = ObsidianSurfaceVariant,
                        unfocusedContainerColor = ObsidianSurfaceVariant
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Đóng", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (jsonText.isNotBlank()) {
                                onImportRawJson(jsonText)
                                onDismiss()
                            }
                        },
                        enabled = jsonText.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier.testTag("confirm_raw_json_import_button")
                    ) {
                        Text("Nhập từ văn bản", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
