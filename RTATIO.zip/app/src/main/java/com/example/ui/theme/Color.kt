package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian Telemetry Dark Palette
val ObsidianBg = Color(0xFF0B0F17)
val ObsidianSurface = Color(0xFF131B2E)
val ObsidianSurfaceVariant = Color(0xFF1A243B)
val ObsidianSurfaceElevated = Color(0xFF212E4A)
val ObsidianBorder = Color(0xFF283655)

// Accents
val EmeraldPrimary = Color(0xFF10B981)
val EmeraldDim = Color(0xFF064E3B)
val EmeraldSoft = Color(0xFF34D399)

val SkySecondary = Color(0xFF38BDF8)
val SkyDim = Color(0xFF0C4A6E)

val PurpleTertiary = Color(0xFFA855F7)
val PurpleDim = Color(0xFF3B0764)

val AmberWarning = Color(0xFFF59E0B)
val AmberDim = Color(0xFF78350F)

val CoralError = Color(0xFFEF4444)
val CoralDim = Color(0xFF7F1D1D)

// Text Hierarchy
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
