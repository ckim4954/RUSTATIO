package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.faker.FakerState
import com.example.core.presets.Preset
import com.example.core.util.FormatUtils
import com.example.data.repository.TorrentUiItem
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CoralError
import com.example.ui.theme.EmeraldDim
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.PurpleTertiary
import com.example.ui.theme.SkyDim
import com.example.ui.theme.SkySecondary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun TorrentListScreen(
    torrents: List<TorrentUiItem>,
    defaultPreset: Preset,
    onPickTorrentFile: () -> Unit,
    onStartTorrent: (String) -> Unit,
    onPauseResumeTorrent: (String) -> Unit,
    onStopTorrent: (String) -> Unit,
    onDeleteTorrent: (TorrentUiItem) -> Unit,
    onConfigureTorrent: (TorrentUiItem) -> Unit,
    onStartAll: () -> Unit,
    onPauseAll: () -> Unit,
    onStopAll: () -> Unit,
    onNavigateToPresets: () -> Unit,
    modifier: Modifier = Modifier
) {
    var torrentToDelete by remember { mutableStateOf<TorrentUiItem?>(null) }

    val totalUploaded = remember(torrents) { torrents.sumOf { it.stats.uploadedBytes } }
    val totalDownloaded = remember(torrents) { torrents.sumOf { it.stats.downloadedBytes } }
    val totalUpSpeed = remember(torrents) { torrents.sumOf { it.stats.currentUploadRateKBs } }
    val totalDownSpeed = remember(torrents) { torrents.sumOf { it.stats.currentDownloadRateKBs } }
    val runningCount = remember(torrents) {
        torrents.count { it.stats.state == FakerState.RUNNING || it.stats.state == FakerState.STARTING }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("torrent_list_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Banner Tổng Quan Lưu Lượng & Trạng Thái
        item(key = "telemetry_header") {
            TelemetryOverviewBanner(
                totalTorrents = torrents.size,
                runningCount = runningCount,
                totalUploaded = totalUploaded,
                totalDownloaded = totalDownloaded,
                totalUpSpeed = totalUpSpeed,
                totalDownSpeed = totalDownSpeed,
                defaultPreset = defaultPreset,
                onAddTorrent = onPickTorrentFile,
                onNavigateToPresets = onNavigateToPresets
            )
        }

        // Thanh điều khiển hàng loạt khi có torrent trong danh sách
        if (torrents.isNotEmpty()) {
            item(key = "batch_controls") {
                BatchControlRow(
                    totalCount = torrents.size,
                    runningCount = runningCount,
                    onStartAll = onStartAll,
                    onPauseAll = onPauseAll,
                    onStopAll = onStopAll
                )
            }
        }

        // Trạng thái trống hoàn toàn (Không có torrent mẫu giả lập)
        if (torrents.isEmpty()) {
            item(key = "empty_state") {
                EmptyTorrentListCard(
                    defaultPreset = defaultPreset,
                    onPickTorrentFile = onPickTorrentFile,
                    onNavigateToPresets = onNavigateToPresets
                )
            }
        } else {
            items(
                items = torrents,
                key = { it.id }
            ) { item ->
                TorrentInstanceCard(
                    item = item,
                    onStart = { onStartTorrent(item.id) },
                    onPauseResume = { onPauseResumeTorrent(item.id) },
                    onStop = { onStopTorrent(item.id) },
                    onConfigure = { onConfigureTorrent(item) },
                    onDelete = { torrentToDelete = item }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(76.dp))
        }
    }

    torrentToDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { torrentToDelete = null },
            containerColor = ObsidianSurface,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary,
            title = { Text("Xóa Torrent khỏi danh sách?") },
            text = {
                Text(
                    "Bạn có chắc chắn muốn xóa \"${target.name}\"? Nếu phiên đang chạy, ứng dụng sẽ gửi bản tin dừng (event=stopped) tới Tracker trước khi xóa."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val item = target
                        torrentToDelete = null
                        onDeleteTorrent(item)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CoralError),
                    modifier = Modifier.testTag("confirm_delete_torrent_button")
                ) {
                    Text("Xóa Torrent", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { torrentToDelete = null }) {
                    Text("Hủy", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun TelemetryOverviewBanner(
    totalTorrents: Int,
    runningCount: Int,
    totalUploaded: Long,
    totalDownloaded: Long,
    totalUpSpeed: Double,
    totalDownSpeed: Double,
    defaultPreset: Preset,
    onAddTorrent: () -> Unit,
    onNavigateToPresets: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, ObsidianBorder),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            ObsidianSurfaceElevated,
                            ObsidianSurface
                        )
                    )
                )
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(9.dp)
                                    .clip(CircleShape)
                                    .background(if (runningCount > 0) EmeraldPrimary else TextMuted)
                            )
                            Text(
                                text = if (runningCount > 0) {
                                    "ĐANG CHẠY $runningCount/$totalTorrents TORRENT"
                                } else {
                                    "TRẠNG THÁI TRACKER · $totalTorrents TORRENT"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = if (runningCount > 0) EmeraldPrimary else TextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Rustatio Telemetry",
                            style = MaterialTheme.typography.headlineMedium,
                            color = TextPrimary
                        )
                    }

                    Button(
                        onClick = onAddTorrent,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                        modifier = Modifier.testTag("header_add_torrent_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Thêm Torrent",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Thêm .Torrent", fontWeight = FontWeight.Bold)
                    }
                }

                // 4 ô thông số tổng hợp: Uploaded, Downloaded, Tốc độ Upload, Tốc độ Download
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TelemetryStatTile(
                        label = "TỔNG ĐÃ TẢI LÊN",
                        value = FormatUtils.formatBytes(totalUploaded),
                        subValue = "↑ ${FormatUtils.formatSpeedKBs(totalUpSpeed)}",
                        accentColor = EmeraldPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryStatTile(
                        label = "TỔNG ĐÃ TẢI XUỐNG",
                        value = FormatUtils.formatBytes(totalDownloaded),
                        subValue = "↓ ${FormatUtils.formatSpeedKBs(totalDownSpeed)}",
                        accentColor = SkySecondary,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Thanh hiển thị Preset mặc định hiện hành
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(ObsidianSurfaceVariant)
                        .clickable { onNavigateToPresets() }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = PurpleTertiary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Preset mặc định: ${defaultPreset.name}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = "Đổi Preset →",
                        style = MaterialTheme.typography.labelSmall,
                        color = SkySecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun TelemetryStatTile(
    label: String,
    value: String,
    subValue: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = ObsidianSurfaceVariant,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, ObsidianBorder)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                color = TextPrimary
            )
            Text(
                text = subValue,
                style = MaterialTheme.typography.labelMedium,
                color = accentColor
            )
        }
    }
}

@Composable
private fun BatchControlRow(
    totalCount: Int,
    runningCount: Int,
    onStartAll: () -> Unit,
    onPauseAll: () -> Unit,
    onStopAll: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FilledTonalButton(
            onClick = onStartAll,
            modifier = Modifier
                .weight(1f)
                .testTag("batch_start_all_button"),
            colors = ButtonDefaults.filledTonalButtonColors(
                containerColor = EmeraldDim,
                contentColor = EmeraldPrimary
            ),
            shape = RoundedCornerShape(12.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Chạy tất cả ($totalCount)", style = MaterialTheme.typography.labelLarge)
        }

        FilledTonalButton(
            onClick = onPauseAll,
            enabled = runningCount > 0,
            modifier = Modifier
                .weight(1f)
                .testTag("batch_pause_all_button"),
            colors = ButtonDefaults.filledTonalButtonColors(
                containerColor = ObsidianSurfaceVariant,
                contentColor = AmberWarning
            ),
            shape = RoundedCornerShape(12.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            Icon(Icons.Default.Pause, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Tạm dừng", style = MaterialTheme.typography.labelLarge)
        }

        FilledTonalButton(
            onClick = onStopAll,
            modifier = Modifier
                .weight(1f)
                .testTag("batch_stop_all_button"),
            colors = ButtonDefaults.filledTonalButtonColors(
                containerColor = ObsidianSurfaceVariant,
                contentColor = CoralError
            ),
            shape = RoundedCornerShape(12.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Dừng hết", style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun EmptyTorrentListCard(
    defaultPreset: Preset,
    onPickTorrentFile: () -> Unit,
    onNavigateToPresets: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("empty_torrent_state_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
        border = BorderStroke(1.dp, ObsidianBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(EmeraldDim),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CloudQueue,
                    contentDescription = "Chưa có Torrent",
                    tint = EmeraldPrimary,
                    modifier = Modifier.size(32.dp)
                )
            }

            Text(
                text = "Danh Sách Torrent Đang Trống",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )

            Text(
                text = "Ứng dụng hoạt động thực tế 100% với BitTorrent Tracker (HTTP/HTTPS & UDP) và đã loại bỏ hoàn toàn các tệp torrent mẫu. Hãy chọn tệp .torrent từ thiết bị của bạn để bắt đầu.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )

            Surface(
                color = ObsidianSurfaceVariant,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, ObsidianBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "CẤU HÌNH MẶC ĐỊNH SẴN SÀNG",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldPrimary
                    )
                    Text(
                        text = "• Preset: ${defaultPreset.name} (↑ ${FormatUtils.formatSpeedKBs(defaultPreset.settings.uploadRate)})",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary
                    )
                    Text(
                        text = "• Tuỳ chỉnh nhanh Client, Version, Port & Hệ điều hành (Windows 7 / 10 / 12) ngay khi nạp tệp .torrent",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onNavigateToPresets,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("empty_state_presets_button"),
                    border = BorderStroke(1.dp, ObsidianBorder),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Tune, contentDescription = null, tint = SkySecondary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Cài đặt Presets", color = TextPrimary)
                }

                Button(
                    onClick = onPickTorrentFile,
                    modifier = Modifier
                        .weight(1.2f)
                        .testTag("empty_state_add_torrent_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Chọn tệp .torrent", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TorrentInstanceCard(
    item: TorrentUiItem,
    onStart: () -> Unit,
    onPauseResume: () -> Unit,
    onStop: () -> Unit,
    onConfigure: () -> Unit,
    onDelete: () -> Unit
) {
    val stats = item.stats
    val stateColor = when (stats.state) {
        FakerState.RUNNING -> EmeraldPrimary
        FakerState.STARTING -> SkySecondary
        FakerState.PAUSED -> AmberWarning
        FakerState.STOPPING -> CoralError
        FakerState.STOPPED -> if (stats.trackerError != null) CoralError else TextMuted
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("torrent_card_${item.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
        border = BorderStroke(
            width = if (stats.state == FakerState.RUNNING) 1.4.dp else 1.dp,
            color = if (stats.state == FakerState.RUNNING) EmeraldPrimary.copy(alpha = 0.55f) else ObsidianBorder
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Hàng 1: Tên Torrent, Tracker domain, Kích thước & Trạng thái
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = item.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = item.trackerHost,
                            style = MaterialTheme.typography.labelMedium,
                            color = SkySecondary
                        )
                        Text(
                            text = "• ${FormatUtils.formatBytes(item.totalSize)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }

                // Huy hiệu trạng thái phiên
                Surface(
                    color = stateColor.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(999.dp),
                    border = BorderStroke(1.dp, stateColor.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(stateColor)
                        )
                        Text(
                            text = stats.state.labelVi,
                            style = MaterialTheme.typography.labelSmall,
                            color = stateColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Hàng 2: 4 Ô thông số bắt buộc (Uploaded, Downloaded, Speed ↑/↓, Ratio & Tracker Info)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Đã tải lên (Uploaded)
                MetricMiniBox(
                    title = "ĐÃ TẢI LÊN",
                    mainValue = FormatUtils.formatBytes(stats.uploadedBytes),
                    subValue = "Phiên: +${FormatUtils.formatBytes(stats.sessionUploadedBytes)}",
                    accentColor = EmeraldPrimary,
                    modifier = Modifier.weight(1f)
                )
                // Đã tải xuống (Downloaded)
                MetricMiniBox(
                    title = "ĐÃ TẢI XUỐNG",
                    mainValue = FormatUtils.formatBytes(stats.downloadedBytes),
                    subValue = "Hoàn tất: ${stats.completionPercent.toInt()}%",
                    accentColor = SkySecondary,
                    modifier = Modifier.weight(1f)
                )
                // Tốc độ tức thời (Speed) & Ratio
                MetricMiniBox(
                    title = "TỐC ĐỘ & RATIO",
                    mainValue = "↑ ${FormatUtils.formatSpeedKBs(stats.currentUploadRateKBs)}",
                    subValue = "↓ ${FormatUtils.formatSpeedKBs(stats.currentDownloadRateKBs)} · R: ${FormatUtils.formatRatio(stats.ratio)}",
                    accentColor = if (stats.currentUploadRateKBs > 0.0) EmeraldPrimary else TextSecondary,
                    modifier = Modifier.weight(1.15f)
                )
            }

            // Hàng 3: Thông tin phản hồi thực tế từ Tracker (Seeders, Leechers, Số lần Announce, Hẹn giờ tiếp theo)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(ObsidianSurfaceVariant)
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Seeds: ${stats.seeders} · Peers: ${stats.leechers}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextPrimary
                )
                Text(
                    text = "Announce: #${stats.announceCount}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Text(
                    text = if (stats.nextAnnounceMs != null) {
                        "Tiếp theo: ${FormatUtils.formatCountdown(stats.nextAnnounceMs)}"
                    } else {
                        "Chu kỳ: ${stats.announceIntervalSecs / 60}p"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = EmeraldPrimary
                )
            }

            // Trạng thái ngắn gọn của Tracker (Cảnh báo thử lại / Tạm nghỉ / Lỗi)
            val statusNotice = stats.trackerError ?: stats.trackerWarning ?: stats.idlingReason
            AnimatedVisibility(visible = statusNotice != null) {
                val isError = stats.trackerError != null
                val msg = statusNotice.orEmpty()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isError) CoralError.copy(alpha = 0.15f) else AmberWarning.copy(alpha = 0.15f))
                        .border(
                            1.dp,
                            if (isError) CoralError.copy(alpha = 0.4f) else AmberWarning.copy(alpha = 0.4f),
                            RoundedCornerShape(10.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = null,
                        tint = if (isError) CoralError else AmberWarning,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isError) CoralError else AmberWarning
                    )
                }
            }

            // Hàng 4: Nhãn cấu hình Client + Version + Hệ điều hành (Win 7 / 10 / 12) + Port + Preset
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ConfigBadgePill(
                    icon = Icons.Default.Dns,
                    text = "${item.clientDisplayName} ${item.clientVersion}",
                    color = EmeraldPrimary,
                    onClick = onConfigure
                )
                ConfigBadgePill(
                    icon = Icons.Default.Computer,
                    text = item.operatingSystem.shortBadge,
                    color = SkySecondary,
                    onClick = onConfigure
                )
                ConfigBadgePill(
                    icon = Icons.Default.Router,
                    text = "Port ${item.port}",
                    color = PurpleTertiary,
                    onClick = onConfigure
                )
                ConfigBadgePill(
                    icon = Icons.Default.Tune,
                    text = item.presetName,
                    color = TextSecondary,
                    onClick = onConfigure
                )
            }

            HorizontalDivider(color = ObsidianBorder)

            // Hàng 5: Cụm điều khiển trực tiếp (Start, Pause/Resume, Stop, Config Client/OS/Port, Delete)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                when (stats.state) {
                    FakerState.STOPPED, FakerState.STOPPING -> {
                        Button(
                            onClick = onStart,
                            enabled = stats.state != FakerState.STOPPING,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                            modifier = Modifier
                                .weight(1.3f)
                                .testTag("start_button_${item.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Bắt đầu",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Bắt đầu", fontWeight = FontWeight.Bold)
                        }
                    }

                    FakerState.RUNNING, FakerState.STARTING -> {
                        FilledTonalButton(
                            onClick = onPauseResume,
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = AmberWarning.copy(alpha = 0.2f),
                                contentColor = AmberWarning
                            ),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("pause_button_${item.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Pause,
                                contentDescription = "Tạm dừng",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Tạm dừng", fontWeight = FontWeight.SemiBold)
                        }

                        FilledTonalButton(
                            onClick = onStop,
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = CoralError.copy(alpha = 0.2f),
                                contentColor = CoralError
                            ),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("stop_button_${item.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Dừng",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Dừng", fontWeight = FontWeight.SemiBold)
                        }
                    }

                    FakerState.PAUSED -> {
                        Button(
                            onClick = onPauseResume,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("resume_button_${item.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Tiếp tục",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Tiếp tục", fontWeight = FontWeight.Bold)
                        }

                        FilledTonalButton(
                            onClick = onStop,
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = CoralError.copy(alpha = 0.2f),
                                contentColor = CoralError
                            ),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("stop_button_${item.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Dừng",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Dừng", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                // Nút cấu hình Client - Version - Port - OS
                OutlinedButton(
                    onClick = onConfigure,
                    border = BorderStroke(1.dp, ObsidianBorder),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("config_button_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Cấu hình Client, OS, Port",
                        tint = SkySecondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Cấu hình", color = TextPrimary, style = MaterialTheme.typography.labelLarge)
                }

                // Nút Xóa Torrent
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(ObsidianSurfaceVariant)
                        .testTag("delete_button_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Xóa Torrent",
                        tint = CoralError
                    )
                }
            }
        }
    }
}

@Composable
private fun MetricMiniBox(
    title: String,
    mainValue: String,
    subValue: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = ObsidianSurfaceVariant,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, ObsidianBorder)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                maxLines = 1
            )
            Text(
                text = mainValue,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Bold
                ),
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subValue,
                style = MaterialTheme.typography.labelSmall,
                color = accentColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ConfigBadgePill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() },
        color = ObsidianSurfaceVariant,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, ObsidianBorder)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(13.dp)
            )
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                color = TextPrimary
            )
        }
    }
}
