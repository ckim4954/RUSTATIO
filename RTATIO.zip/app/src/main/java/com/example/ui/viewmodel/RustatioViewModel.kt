package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.presets.BuiltInPresets
import com.example.core.presets.Preset
import com.example.core.presets.PresetSettings
import com.example.core.torrent.ClientType
import com.example.core.torrent.OperatingSystem
import com.example.core.torrent.TorrentInfo
import com.example.data.repository.RustatioRepository
import com.example.data.repository.TorrentUiItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class PendingTorrentDraft(
    val rawBytes: ByteArray,
    val info: TorrentInfo
)

class RustatioViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = RustatioRepository.getInstance(application)

    val torrents: StateFlow<List<TorrentUiItem>> = repository.torrentsState

    val allPresets: StateFlow<List<Preset>> = repository.allPresetsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BuiltInPresets.all)

    val customPresets: StateFlow<List<Preset>> = repository.customPresetsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val defaultPresetId: StateFlow<String?> = repository.defaultPresetIdFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "balanced")

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _pendingTorrents = MutableStateFlow<List<PendingTorrentDraft>>(emptyList())
    val pendingTorrents: StateFlow<List<PendingTorrentDraft>> = _pendingTorrents.asStateFlow()

    private val _pendingExportJson = MutableStateFlow<Pair<String, String>?>(null)
    val pendingExportJson: StateFlow<Pair<String, String>?> = _pendingExportJson.asStateFlow()

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun showMessage(msg: String) {
        _statusMessage.value = msg
    }

    fun onTorrentFilesPicked(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val drafts = mutableListOf<PendingTorrentDraft>()
            val errors = mutableListOf<String>()
            val resolver = getApplication<Application>().contentResolver

            withContext(Dispatchers.IO) {
                for (uri in uris) {
                    try {
                        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                            ?: throw IllegalArgumentException("Không thể đọc tệp từ bộ nhớ")
                        val info = TorrentInfo.fromBytes(bytes)
                        drafts.add(PendingTorrentDraft(bytes, info))
                    } catch (e: Exception) {
                        errors.add(e.message ?: "Tệp .torrent lỗi định dạng")
                    }
                }
            }

            if (drafts.isNotEmpty()) {
                _pendingTorrents.value = drafts
            }
            if (errors.isNotEmpty()) {
                _statusMessage.value = "Lỗi đọc tệp: ${errors.first()}"
            }
        }
    }

    fun dismissPendingTorrents() {
        _pendingTorrents.value = emptyList()
    }

    fun confirmAddPendingTorrents(
        preset: Preset,
        clientType: ClientType,
        clientVersion: String,
        port: Int,
        operatingSystem: OperatingSystem,
        autoStart: Boolean
    ) {
        val drafts = _pendingTorrents.value
        if (drafts.isEmpty()) return
        _pendingTorrents.value = emptyList()

        viewModelScope.launch {
            var successCount = 0
            var lastErr: String? = null
            for (draft in drafts) {
                val res = repository.addRealTorrent(
                    rawBytes = draft.rawBytes,
                    chosenPreset = preset,
                    clientType = clientType,
                    clientVersion = clientVersion,
                    port = port,
                    operatingSystem = operatingSystem,
                    autoStart = autoStart
                )
                res.onSuccess { successCount++ }
                    .onFailure { lastErr = it.message }
            }
            if (successCount > 0) {
                _statusMessage.value = if (autoStart) {
                    "Đã thêm và kết nối Tracker cho $successCount torrent (${clientType.displayName} · ${operatingSystem.shortBadge})"
                } else {
                    "Đã thêm $successCount torrent vào danh sách"
                }
            } else if (lastErr != null) {
                _statusMessage.value = "Không thể thêm torrent: $lastErr"
            }
        }
    }

    fun startTorrent(id: String) {
        viewModelScope.launch {
            repository.startTorrent(id)
        }
    }

    fun pauseOrResumeTorrent(id: String) {
        viewModelScope.launch {
            repository.pauseOrResumeTorrent(id)
        }
    }

    fun stopTorrent(id: String) {
        viewModelScope.launch {
            repository.stopTorrent(id)
            _statusMessage.value = "Đã gửi tín hiệu dừng (stopped) tới Tracker"
        }
    }

    fun deleteTorrent(id: String, name: String) {
        viewModelScope.launch {
            repository.deleteTorrent(id)
            _statusMessage.value = "Đã xóa torrent \"$name\""
        }
    }

    fun startAllTorrents() {
        viewModelScope.launch {
            repository.startAllTorrents()
            _statusMessage.value = "Đã bắt đầu tất cả torrent"
        }
    }

    fun pauseAllTorrents() {
        viewModelScope.launch {
            repository.pauseAllTorrents()
            _statusMessage.value = "Đã tạm dừng tất cả torrent"
        }
    }

    fun stopAllTorrents() {
        viewModelScope.launch {
            repository.stopAllTorrents()
            _statusMessage.value = "Đã dừng tất cả phiên Tracker"
        }
    }

    fun updateTorrentClientOsPort(
        torrentId: String,
        preset: Preset,
        clientType: ClientType,
        clientVersion: String,
        port: Int,
        operatingSystem: OperatingSystem
    ) {
        viewModelScope.launch {
            repository.updateTorrentClientOsPort(
                id = torrentId,
                preset = preset,
                clientType = clientType,
                clientVersion = clientVersion,
                port = port,
                operatingSystem = operatingSystem
            )
            _statusMessage.value = "Đã cập nhật cấu hình: ${clientType.displayName} $clientVersion · ${operatingSystem.shortBadge} · Port $port"
        }
    }

    fun applyPreset(preset: Preset, targetTorrentId: String? = null) {
        viewModelScope.launch {
            val count = repository.applyPresetToTorrents(preset, targetTorrentId)
            _statusMessage.value = if (count > 0) {
                "Đã áp dụng Preset \"${preset.name}\" cho $count torrent"
            } else {
                "Đã đặt Preset \"${preset.name}\" làm cấu hình mặc định cho torrent tiếp theo"
            }
            if (count == 0) {
                repository.setDefaultPreset(preset.id)
            }
        }
    }

    fun toggleDefaultPreset(preset: Preset) {
        viewModelScope.launch {
            if (defaultPresetId.value == preset.id) {
                repository.clearDefaultPreset()
                _statusMessage.value = "Đã gỡ mặc định cho Preset \"${preset.name}\""
            } else {
                repository.setDefaultPreset(preset.id)
                _statusMessage.value = "Đã đặt \"${preset.name}\" làm Preset mặc định"
            }
        }
    }

    fun saveCustomPreset(
        name: String,
        description: String,
        settings: PresetSettings,
        existingId: String? = null,
        setAsDefault: Boolean = false
    ) {
        viewModelScope.launch {
            val saved = repository.saveCustomPreset(name, description, settings, existingId)
            if (setAsDefault) {
                repository.setDefaultPreset(saved.id)
            }
            _statusMessage.value = "Đã lưu Preset tùy chỉnh \"${saved.name}\""
        }
    }

    fun deleteCustomPreset(preset: Preset) {
        viewModelScope.launch {
            repository.deleteCustomPreset(preset.id)
            _statusMessage.value = "Đã xóa Preset tùy chỉnh \"${preset.name}\""
        }
    }

    fun importPresetFromUri(uri: Uri) {
        viewModelScope.launch {
            val resolver = getApplication<Application>().contentResolver
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val text = resolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: throw IllegalArgumentException("Không thể đọc tệp JSON")
                    repository.importPresetsFromJson(text).getOrThrow()
                }
            }
            result.onSuccess { count ->
                _statusMessage.value = "Đã nhập thành công $count Preset từ tệp JSON"
            }.onFailure { err ->
                _statusMessage.value = "Lỗi nhập JSON: ${err.message}"
            }
        }
    }

    fun importPresetFromRawText(jsonText: String) {
        viewModelScope.launch {
            val res = repository.importPresetsFromJson(jsonText)
            res.onSuccess { count ->
                _statusMessage.value = "Đã nhập thành công $count Preset"
            }.onFailure { err ->
                _statusMessage.value = "JSON không hợp lệ: ${err.message}"
            }
        }
    }

    fun prepareExportPreset(preset: Preset) {
        val safeName = preset.name.lowercase()
            .replace(Regex("[^a-z0-9\\-_]+"), "-")
            .trim('-')
            .ifEmpty { "custom-preset" }
        val fileName = "rustatio-$safeName.json"
        _pendingExportJson.value = fileName to preset.toExportJsonString()
    }

    fun prepareExportAllCustomPresets() {
        val list = customPresets.value
        if (list.isEmpty()) {
            _statusMessage.value = "Chưa có Preset tùy chỉnh nào để xuất"
            return
        }
        val json = repository.exportAllCustomPresetsJson(list)
        _pendingExportJson.value = "rustatio-custom-presets.json" to json
    }

    fun writePendingExportToUri(uri: Uri?) {
        val pending = _pendingExportJson.value
        _pendingExportJson.value = null
        if (uri == null || pending == null) return

        viewModelScope.launch {
            val resolver = getApplication<Application>().contentResolver
            val res = withContext(Dispatchers.IO) {
                runCatching {
                    resolver.openOutputStream(uri)?.use { out ->
                        out.write(pending.second.toByteArray(Charsets.UTF_8))
                        out.flush()
                    } ?: throw IllegalStateException("Không thể ghi vào tệp đã chọn")
                }
            }
            res.onSuccess {
                _statusMessage.value = "Đã xuất tệp JSON thành công (${pending.first})"
            }.onFailure { e ->
                _statusMessage.value = "Lỗi xuất tệp JSON: ${e.message}"
            }
        }
    }
}
