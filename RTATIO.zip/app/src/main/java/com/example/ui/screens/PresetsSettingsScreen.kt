package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Balance
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.presets.Preset
import com.example.core.torrent.ClientType
import com.example.core.torrent.OperatingSystem
import com.example.core.util.FormatUtils
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CoralError
import com.example.ui.theme.EmeraldDim
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.PurpleDim
import com.example.ui.theme.PurpleTertiary
import com.example.ui.theme.SkySecondary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

private enum class PresetFilterTab(val labelVi: String) {
    ALL("Tất cả Presets"),
    BUILT_IN("Tích hợp sẵn (4)"),
    CUSTOM("Tùy chỉnh (Custom)")
}

@Composable
fun PresetsSettingsScreen(
    allPresets: List<Preset>,
    customPresets: List<Preset>,
    defaultPresetId: String?,
    onApplyPreset: (Preset) -> Unit,
    onToggleDefaultPreset: (Preset) -> Unit,
    onCreateNewCustomPreset: () -> Unit,
    onEditOrClonePreset: (Preset) -> Unit,
    onDeleteCustomPreset: (Preset) -> Unit,
    onOpenImportJson: () -> Unit,
    onExportSinglePreset: (Preset) -> Unit,
    onExportAllCustomPresets: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(PresetFilterTab.ALL) }

    val displayedPresets = remember(allPresets, selectedTab) {
        when (selectedTab) {
            PresetFilterTab.ALL -> allPresets
            PresetFilterTab.BUILT_IN -> allPresets.filter { !it.custom }
            PresetFilterTab.CUSTOM -> allPresets.filter { it.custom }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("presets_settings_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Đầu trang Cài đặt: Chỉ giữ lại Full Presets
        item(key = "presets_header") {
            PresetsHeaderPanel(
                customCount = customPresets.size,
                defaultPreset = allPresets.firstOrNull { it.id == defaultPresetId },
                onCreateNew = onCreateNewCustomPreset,
                onImportJson = onOpenImportJson,
                onExportAllJson = onExportAllCustomPresets
            )
        }

        // Bộ lọc Built-in Presets vs Custom Presets
        item(key = "presets_filter_tabs") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PresetFilterTab.entries.forEach { tab ->
                    val isSelected = selectedTab == tab
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        label = { Text(tab.labelVi) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldPrimary.copy(alpha = 0.22f),
                            selectedLabelColor = EmeraldPrimary,
                            containerColor = ObsidianSurface,
                            labelColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("preset_tab_${tab.name.lowercase()}")
                    )
                }
            }
        }

        if (displayedPresets.isEmpty()) {
            item(key = "empty_custom_presets") {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                    border = BorderStroke(1.dp, ObsidianBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Chưa có Preset Tùy Chỉnh nào",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = "Bạn có thể tạo mới Preset tùy chỉnh với tốc độ, điều kiện dừng, Client/OS/Port riêng hoặc nhập tệp .json từ máy tính.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = onOpenImportJson,
                                border = BorderStroke(1.dp, ObsidianBorder)
                            ) {
                                Icon(Icons.Default.FileDownload, contentDescription = null, tint = SkySecondary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Nhập JSON", color = TextPrimary)
                            }
                            Button(
                                onClick = onCreateNewCustomPreset,
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Tạo Preset mới", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        } else {
            items(
                items = displayedPresets,
                key = { it.id }
            ) { preset ->
                PresetDetailCard(
                    preset = preset,
                    isDefault = preset.id == defaultPresetId,
                    onApply = { onApplyPreset(preset) },
                    onToggleDefault = { onToggleDefaultPreset(preset) },
                    onEditOrClone = { onEditOrClonePreset(preset) },
                    onExportJson = { onExportSinglePreset(preset) },
                    onDelete = { onDeleteCustomPreset(preset) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(76.dp))
        }
    }
}

@Composable
private fun PresetsHeaderPanel(
    customCount: Int,
    defaultPreset: Preset?,
    onCreateNew: () -> Unit,
    onImportJson: () -> Unit,
    onExportAllJson: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
        border = BorderStroke(1.dp, ObsidianBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "QUẢN LÝ CẤU HÌNH MẪU (FULL PRESETS)",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldPrimary
                    )
                    Text(
                        text = "Built-in & Custom Presets",
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary
                    )
                }

                Button(
                    onClick = onCreateNew,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("create_custom_preset_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Tạo mới", fontWeight = FontWeight.Bold)
                }
            }

            // Hiển thị trạng thái Preset mặc định hiện tại
            Surface(
                color = ObsidianSurfaceVariant,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, ObsidianBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = null,
                        tint = AmberWarning,
                        modifier = Modifier.size(20.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (defaultPreset != null) {
                                "Mặc định hiện tại: ${defaultPreset.name}"
                            } else {
                                "Chưa đặt Preset mặc định (Dùng Cân Bằng)"
                            },
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary
                        )
                        Text(
                            text = "Tự động áp dụng khi bạn thêm tệp .torrent mới vào danh sách",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            }

            // Cụm nút Nhập JSON (Import) & Xuất JSON (Export)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onImportJson,
                    border = BorderStroke(1.dp, ObsidianBorder),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("import_preset_json_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.FileDownload,
                        contentDescription = "Nhập Preset JSON",
                        tint = SkySecondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Nhập JSON (Import)", color = TextPrimary)
                }

                OutlinedButton(
                    onClick = onExportAllJson,
                    border = BorderStroke(1.dp, ObsidianBorder),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("export_all_presets_json_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.FileUpload,
                        contentDescription = "Xuất Preset JSON",
                        tint = PurpleTertiary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Xuất JSON ($customCount)", color = TextPrimary)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PresetDetailCard(
    preset: Preset,
    isDefault: Boolean,
    onApply: () -> Unit,
    onToggleDefault: () -> Unit,
    onEditOrClone: () -> Unit,
    onExportJson: () -> Unit,
    onDelete: () -> Unit
) {
    var showTips by remember { mutableStateOf(false) }
    val cfg = preset.settings
    val client = ClientType.fromId(cfg.selectedClient)
    val os = OperatingSystem.fromId(cfg.operatingSystem)

    val iconVector = when (preset.icon) {
        "scale" -> Icons.Default.Balance
        "rocket" -> Icons.Default.RocketLaunch
        "server" -> Icons.Default.Storage
        "eye-off" -> Icons.Default.Shield
        else -> Icons.Default.Star
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("preset_card_${preset.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
        border = BorderStroke(
            width = if (isDefault) 1.5.dp else 1.dp,
            color = if (isDefault) AmberWarning.copy(alpha = 0.7f) else ObsidianBorder
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (preset.custom) PurpleDim else EmeraldDim),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = iconVector,
                            contentDescription = null,
                            tint = if (preset.custom) PurpleTertiary else EmeraldPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = preset.name,
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary
                            )
                        }
                        Text(
                            text = preset.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                // Huy hiệu Khuyên dùng / Mặc định / Custom
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (isDefault) {
                        PresetStatusBadge(text = "MẶC ĐỊNH", color = AmberWarning)
                    }
                    if (preset.recommended) {
                        PresetStatusBadge(text = "KHUYÊN DÙNG", color = EmeraldPrimary)
                    } else if (preset.custom) {
                        PresetStatusBadge(text = "TÙY CHỈNH", color = PurpleTertiary)
                    }
                }
            }

            // Tóm tắt thông số kỹ thuật của Preset
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val upLabel = if (cfg.progressiveRatesEnabled) {
                    "↑ ${FormatUtils.formatSpeedKBs(cfg.uploadRate)} → ${FormatUtils.formatSpeedKBs(cfg.targetUploadRate)} (${cfg.progressiveDurationHours}g)"
                } else {
                    "↑ ${FormatUtils.formatSpeedKBs(cfg.uploadRate)}"
                }
                PresetParamChip(text = upLabel, highlightColor = EmeraldPrimary)

                if (cfg.downloadRate > 0.0) {
                    PresetParamChip(
                        text = "↓ ${FormatUtils.formatSpeedKBs(cfg.downloadRate)}",
                        highlightColor = SkySecondary
                    )
                }
                if (cfg.randomizeRates) {
                    PresetParamChip(
                        text = "Ngẫu nhiên ±${cfg.randomRangePercent.toInt()}%",
                        highlightColor = TextSecondary
                    )
                }
                if (cfg.stopAtRatioEnabled) {
                    PresetParamChip(
                        text = "Dừng ở Ratio ${cfg.stopAtRatio}",
                        highlightColor = AmberWarning
                    )
                }
                if (cfg.stopAtUploadedEnabled) {
                    PresetParamChip(
                        text = "Dừng ở ${cfg.stopAtUploadedGB} GB",
                        highlightColor = AmberWarning
                    )
                }
                if (cfg.stopAtSeedTimeEnabled) {
                    PresetParamChip(
                        text = "Dừng sau ${cfg.stopAtSeedTimeHours.toInt()} giờ",
                        highlightColor = AmberWarning
                    )
                }
                if (cfg.idleWhenNoLeechers) {
                    PresetParamChip(
                        text = "Nghỉ khi 0 Leecher",
                        highlightColor = SkySecondary
                    )
                }
                PresetParamChip(
                    text = "${client.displayName} ${cfg.selectedClientVersion.ifBlank { client.defaultVersion }}",
                    highlightColor = TextPrimary
                )
                PresetParamChip(
                    text = "${os.shortBadge} · Port ${cfg.port}",
                    highlightColor = SkySecondary
                )
            }

            // Mẹo sử dụng (cho phép bấm mở rộng nếu có)
            if (preset.tips.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(ObsidianSurfaceVariant)
                        .clickable { showTips = !showTips }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = if (showTips) "▼ Ẩn phân tích kỹ thuật (${preset.tips.size})" else "▶ Xem chi tiết cơ chế hoạt động (${preset.tips.size} lưu ý)",
                        style = MaterialTheme.typography.labelSmall,
                        color = SkySecondary
                    )
                    AnimatedVisibility(visible = showTips) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            preset.tips.forEach { tip ->
                                Text(
                                    text = "• $tip",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            }

            HorizontalDivider(color = ObsidianBorder)

            // Cụm nút hành động chuẩn: Áp dụng (Apply), Đặt mặc định (Set Default), Sửa/Nhân bản, Xuất JSON, Xóa
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onApply,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    modifier = Modifier
                        .weight(1.1f)
                        .testTag("apply_preset_button_${preset.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Áp dụng Preset",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Áp dụng", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onToggleDefault,
                    border = BorderStroke(
                        1.dp,
                        if (isDefault) AmberWarning else ObsidianBorder
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                    modifier = Modifier
                        .weight(1.1f)
                        .testTag("default_preset_button_${preset.id}")
                ) {
                    Icon(
                        imageVector = if (isDefault) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = "Đặt làm mặc định",
                        tint = if (isDefault) AmberWarning else TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isDefault) "Bỏ mặc định" else "Đặt mặc định",
                        color = if (isDefault) AmberWarning else TextPrimary,
                        style = MaterialTheme.typography.labelLarge
                    )
                }

                // Nút sửa (nếu là Custom) hoặc nhân bản sang Custom (nếu là Built-in)
                IconButton(
                    onClick = onEditOrClone,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(ObsidianSurfaceVariant)
                        .testTag("edit_or_clone_preset_${preset.id}")
                ) {
                    Icon(
                        imageVector = if (preset.custom) Icons.Default.Edit else Icons.Default.ContentCopy,
                        contentDescription = if (preset.custom) "Chỉnh sửa Preset" else "Tạo bản sao tùy chỉnh",
                        tint = SkySecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Nút Xuất JSON (Export)
                IconButton(
                    onClick = onExportJson,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(ObsidianSurfaceVariant)
                        .testTag("export_preset_${preset.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.FileUpload,
                        contentDescription = "Xuất Preset ra tệp JSON",
                        tint = PurpleTertiary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Nút Xóa (chỉ dành cho Custom Presets)
                if (preset.custom) {
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(ObsidianSurfaceVariant)
                            .testTag("delete_preset_${preset.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Xóa Preset tùy chỉnh",
                            tint = CoralError,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PresetStatusBadge(text: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.16f),
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.45f))
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
private fun PresetParamChip(
    text: String,
    highlightColor: Color
) {
    Surface(
        color = ObsidianSurfaceVariant,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, ObsidianBorder)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = highlightColor,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}
