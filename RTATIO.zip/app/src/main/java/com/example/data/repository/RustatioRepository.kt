package com.example.data.repository

import android.content.Context
import com.example.core.faker.FakerRuntimeStats
import com.example.core.faker.FakerState
import com.example.core.faker.RatioFakerSession
import com.example.core.presets.BuiltInPresets
import com.example.core.presets.Preset
import com.example.core.presets.PresetSettings
import com.example.core.protocol.PeerListenerService
import com.example.core.torrent.ClientType
import com.example.core.torrent.OperatingSystem
import com.example.core.torrent.TorrentInfo
import com.example.data.local.AppDatabase
import com.example.data.local.AppPreferenceEntity
import com.example.data.local.CustomPresetEntity
import com.example.data.local.TorrentEntity
import com.example.service.TrackerForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject

data class TorrentUiItem(
    val id: String,
    val name: String,
    val infoHashHex: String,
    val trackerHost: String,
    val primaryTrackerUrl: String,
    val totalSize: Long,
    val fileCount: Int,
    val presetId: String,
    val presetName: String,
    val settings: PresetSettings,
    val clientDisplayName: String,
    val clientVersion: String,
    val operatingSystem: OperatingSystem,
    val port: Int,
    val stats: FakerRuntimeStats
)

class RustatioRepository private constructor(
    private val appContext: Context,
    private val db: AppDatabase
) {
    companion object {
        private const val KEY_DEFAULT_PRESET_ID = "default_preset_id"

        @Volatile
        private var INSTANCE: RustatioRepository? = null

        fun getInstance(context: Context): RustatioRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: RustatioRepository(
                    context.applicationContext,
                    AppDatabase.getInstance(context)
                ).also { INSTANCE = it }
            }
        }
    }

    private val dao = db.rustatioDao()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val sessionMutex = Mutex()
    private val activeSessions = LinkedHashMap<String, RatioFakerSession>()

    private val _torrentsState = MutableStateFlow<List<TorrentUiItem>>(emptyList())
    val torrentsState: StateFlow<List<TorrentUiItem>> = _torrentsState.asStateFlow()

    // Dịch vụ lắng nghe cổng TCP trả lời gói bắt tay BitTorrent 68 byte như trên PC
    private val peerListener = PeerListenerService {
        val map = HashMap<String, ByteArray>()
        for (session in activeSessions.values) {
            if (session.isPeerConnectable()) {
                map[session.torrent.infoHashHex] = session.peerIdBytes()
            }
        }
        map
    }

    val customPresetsFlow: Flow<List<Preset>> = dao.observeCustomPresets().map { list ->
        list.map { entity ->
            Preset(
                id = entity.id,
                name = entity.name,
                description = entity.description,
                icon = entity.icon,
                recommended = false,
                custom = true,
                createdAt = entity.createdAt,
                settings = PresetSettings.fromJsonObject(
                    runCatching { JSONObject(entity.settingsJson) }.getOrNull()
                )
            )
        }
    }

    val defaultPresetIdFlow: Flow<String?> = dao.observePreference(KEY_DEFAULT_PRESET_ID)

    val allPresetsFlow: Flow<List<Preset>> = combine(
        customPresetsFlow,
        defaultPresetIdFlow
    ) { customList, _ ->
        BuiltInPresets.all + customList
    }

    init {
        scope.launch {
            hydrateSavedTorrents()
            startInternalSchedulerLoop()
        }
    }

    /**
     * Bộ lập lịch nội tại (1 giây/lần) giống hệt rustatio-desktop/src/scheduler.rs.
     * Đảm bảo tốc độ, dung lượng tải lên/xuống và hạn Announce luôn được tính toán
     * độc lập và tức thì ngay khi có Torrent đang chạy.
     */
    private suspend fun startInternalSchedulerLoop() {
        while (scope.isActive) {
            try {
                tickAllSessions()
            } catch (_: Exception) {
            }
            delay(1000L)
        }
    }

    private suspend fun hydrateSavedTorrents() {
        sessionMutex.withLock {
            val saved = dao.getAllTorrentsOnce()
            for (entity in saved) {
                if (activeSessions.containsKey(entity.id)) continue
                val info = runCatching { TorrentInfo.fromBytes(entity.rawTorrentBytes) }.getOrNull()
                    ?: continue
                val settings = PresetSettings.fromJsonObject(
                    runCatching { JSONObject(entity.settingsJson) }.getOrNull()
                )
                val session = RatioFakerSession(
                    instanceId = entity.id,
                    torrent = info,
                    presetId = entity.presetId,
                    presetName = entity.presetName,
                    settings = settings,
                    initialUploadedBytes = entity.cumulativeUploadedBytes,
                    initialDownloadedBytes = entity.cumulativeDownloadedBytes
                )
                activeSessions[entity.id] = session
            }
            publishSnapshotLocked()
        }
    }

    suspend fun setDefaultPreset(presetId: String) {
        dao.setPreference(AppPreferenceEntity(KEY_DEFAULT_PRESET_ID, presetId))
    }

    suspend fun clearDefaultPreset() {
        dao.deletePreference(KEY_DEFAULT_PRESET_ID)
    }

    /**
     * Thêm tệp .torrent thực tế từ bộ nhớ thiết bị cùng cấu hình Preset + Client + Version + Port + OS.
     */
    suspend fun addRealTorrent(
        rawBytes: ByteArray,
        chosenPreset: Preset,
        clientType: ClientType,
        clientVersion: String,
        port: Int,
        operatingSystem: OperatingSystem,
        autoStart: Boolean = true
    ): Result<TorrentUiItem> {
        return runCatching {
            val info = TorrentInfo.fromBytes(rawBytes)
            val id = info.infoHashHex
            val customizedSettings = chosenPreset.settings.copy(
                selectedClient = clientType.id,
                selectedClientVersion = clientVersion,
                port = port.coerceIn(1, 65535),
                operatingSystem = operatingSystem.id
            )

            val item = sessionMutex.withLock {
                val existing = activeSessions[id]
                val initUp = existing?.stats?.uploadedBytes ?: 0L
                val initDown = existing?.stats?.downloadedBytes ?: 0L

                val session = RatioFakerSession(
                    instanceId = id,
                    torrent = info,
                    presetId = chosenPreset.id,
                    presetName = chosenPreset.name,
                    settings = customizedSettings,
                    initialUploadedBytes = initUp,
                    initialDownloadedBytes = initDown
                )
                activeSessions[id] = session

                dao.upsertTorrent(
                    TorrentEntity(
                        id = id,
                        infoHashHex = info.infoHashHex,
                        name = info.name,
                        totalSize = info.totalSize,
                        rawTorrentBytes = rawBytes,
                        presetId = chosenPreset.id,
                        presetName = chosenPreset.name,
                        settingsJson = customizedSettings.toJsonObject().toString(),
                        cumulativeUploadedBytes = initUp,
                        cumulativeDownloadedBytes = initDown,
                        addedAtMs = System.currentTimeMillis()
                    )
                )
                publishSnapshotLocked()
                session.toUiItem()
            }

            if (autoStart) {
                scope.launch {
                    startTorrent(id)
                }
            }
            item
        }
    }

    suspend fun startTorrent(id: String) {
        val session = sessionMutex.withLock { activeSessions[id] } ?: return
        peerListener.ensureListening(session.settings.port)
        TrackerForegroundService.ensureRunning(appContext)

        // Khởi chạy phiên (gửi event=started và kích hoạt bộ đếm)
        session.start()

        sessionMutex.withLock {
            dao.updateTorrentTraffic(id, session.stats.uploadedBytes, session.stats.downloadedBytes)
            publishSnapshotLocked()
        }
    }

    suspend fun pauseOrResumeTorrent(id: String) {
        sessionMutex.withLock {
            val session = activeSessions[id] ?: return
            when (session.stats.state) {
                FakerState.RUNNING, FakerState.STARTING -> session.pause()
                FakerState.PAUSED -> {
                    peerListener.ensureListening(session.settings.port)
                    TrackerForegroundService.ensureRunning(appContext)
                    session.resume()
                }
                else -> {}
            }
            publishSnapshotLocked()
        }
    }

    suspend fun stopTorrent(id: String) {
        val session = sessionMutex.withLock { activeSessions[id] } ?: return
        session.stop()
        sessionMutex.withLock {
            dao.updateTorrentTraffic(id, session.stats.uploadedBytes, session.stats.downloadedBytes)
            publishSnapshotLocked()
            val anyConnectable = activeSessions.values.any { it.isPeerConnectable() }
            if (!anyConnectable) {
                peerListener.stop()
            }
        }
    }

    suspend fun startAllTorrents() {
        val ids = sessionMutex.withLock { activeSessions.keys.toList() }
        if (ids.isEmpty()) return
        TrackerForegroundService.ensureRunning(appContext)
        for (id in ids) {
            scope.launch {
                startTorrent(id)
            }
        }
    }

    suspend fun pauseAllTorrents() {
        sessionMutex.withLock {
            activeSessions.values.forEach { session ->
                if (session.stats.state == FakerState.RUNNING || session.stats.state == FakerState.STARTING) {
                    session.pause()
                }
            }
            publishSnapshotLocked()
        }
    }

    suspend fun stopAllTorrents() {
        val ids = sessionMutex.withLock { activeSessions.keys.toList() }
        for (id in ids) {
            stopTorrent(id)
        }
    }

    suspend fun deleteTorrent(id: String) {
        val session = sessionMutex.withLock { activeSessions.remove(id) }
        if (session != null && (session.stats.state == FakerState.RUNNING || session.stats.state == FakerState.PAUSED)) {
            runCatching { session.stop() }
        }
        sessionMutex.withLock {
            dao.deleteTorrentById(id)
            publishSnapshotLocked()
        }
    }

    suspend fun updateTorrentClientOsPort(
        id: String,
        preset: Preset,
        clientType: ClientType,
        clientVersion: String,
        port: Int,
        operatingSystem: OperatingSystem
    ) {
        sessionMutex.withLock {
            val session = activeSessions[id] ?: return
            val mergedSettings = preset.settings.copy(
                selectedClient = clientType.id,
                selectedClientVersion = clientVersion,
                port = port.coerceIn(1, 65535),
                operatingSystem = operatingSystem.id
            )
            session.updateConfiguration(preset.id, preset.name, mergedSettings)
            if (session.isPeerConnectable()) {
                peerListener.ensureListening(mergedSettings.port)
            }
            dao.updateTorrentSettings(
                id = id,
                presetId = preset.id,
                presetName = preset.name,
                settingsJson = mergedSettings.toJsonObject().toString()
            )
            publishSnapshotLocked()
        }
    }

    /**
     * Áp dụng một Preset cho một Torrent cụ thể hoặc toàn bộ danh sách Torrent hiện có.
     */
    suspend fun applyPresetToTorrents(preset: Preset, targetTorrentId: String? = null): Int {
        return sessionMutex.withLock {
            val targets = if (targetTorrentId != null) {
                listOfNotNull(activeSessions[targetTorrentId])
            } else {
                activeSessions.values.toList()
            }
            for (session in targets) {
                session.updateConfiguration(preset.id, preset.name, preset.settings)
                dao.updateTorrentSettings(
                    id = session.instanceId,
                    presetId = preset.id,
                    presetName = preset.name,
                    settingsJson = preset.settings.toJsonObject().toString()
                )
            }
            publishSnapshotLocked()
            targets.size
        }
    }

    suspend fun saveCustomPreset(
        name: String,
        description: String,
        settings: PresetSettings,
        existingId: String? = null
    ): Preset {
        val cleanName = name.trim().ifEmpty { "Preset Tùy Chỉnh" }
        val cleanDesc = description.trim().ifEmpty {
            "Tốc độ ↑ ${settings.uploadRate.toInt()} KB/s · ${ClientType.fromId(settings.selectedClient).displayName} · ${OperatingSystem.fromId(settings.operatingSystem).shortBadge}"
        }
        val id = existingId ?: "custom-${System.currentTimeMillis()}"
        val nowIso = Preset.currentIsoTimestamp()
        val entity = CustomPresetEntity(
            id = id,
            name = cleanName,
            description = cleanDesc,
            icon = "star",
            createdAt = nowIso,
            settingsJson = settings.toJsonObject().toString(),
            updatedAtMs = System.currentTimeMillis()
        )
        dao.upsertCustomPreset(entity)
        return Preset(
            id = id,
            name = cleanName,
            description = cleanDesc,
            icon = "star",
            recommended = false,
            custom = true,
            createdAt = nowIso,
            settings = settings
        )
    }

    suspend fun deleteCustomPreset(id: String) {
        dao.deleteCustomPresetById(id)
        val currentDef = dao.getPreferenceOnce(KEY_DEFAULT_PRESET_ID)
        if (currentDef == id) {
            dao.deletePreference(KEY_DEFAULT_PRESET_ID)
        }
    }

    suspend fun importPresetsFromJson(jsonContent: String): Result<Int> {
        return runCatching {
            val imported = Preset.parseImportedJson(jsonContent)
            for (preset in imported) {
                dao.upsertCustomPreset(
                    CustomPresetEntity(
                        id = preset.id,
                        name = preset.name,
                        description = preset.description,
                        icon = preset.icon,
                        createdAt = preset.createdAt ?: Preset.currentIsoTimestamp(),
                        settingsJson = preset.settings.toJsonObject().toString(),
                        updatedAtMs = System.currentTimeMillis()
                    )
                )
            }
            imported.size
        }
    }

    fun exportAllCustomPresetsJson(customPresets: List<Preset>): String {
        if (customPresets.size == 1) {
            return customPresets.first().toExportJsonString()
        }
        val arr = JSONArray()
        for (p in customPresets) {
            arr.put(JSONObject(p.toExportJsonString()))
        }
        return JSONObject().apply {
            put("version", 1)
            put("type", "rustatio-preset-bundle")
            put("exportedAt", Preset.currentIsoTimestamp())
            put("presets", arr)
        }.toString(2)
    }

    suspend fun tickAllSessions(): Boolean {
        val sessions = sessionMutex.withLock { activeSessions.values.toList() }
        if (sessions.isEmpty()) return false

        val toDelete = mutableListOf<String>()
        var anyActive = false

        for (session in sessions) {
            val shouldDelete = session.tick()
            if (shouldDelete) {
                toDelete.add(session.instanceId)
            } else if (
                session.stats.state == FakerState.RUNNING ||
                session.stats.state == FakerState.STARTING ||
                session.stats.state == FakerState.PAUSED
            ) {
                anyActive = true
            }
        }

        sessionMutex.withLock {
            for (delId in toDelete) {
                activeSessions.remove(delId)
                dao.deleteTorrentById(delId)
            }
            for (session in activeSessions.values) {
                if (session.stats.state == FakerState.RUNNING && session.stats.elapsedTimeSecs % 5L == 0L) {
                    dao.updateTorrentTraffic(
                        session.instanceId,
                        session.stats.uploadedBytes,
                        session.stats.downloadedBytes
                    )
                }
            }
            publishSnapshotLocked()
        }

        return anyActive
    }

    private fun publishSnapshotLocked() {
        _torrentsState.value = activeSessions.values.map { it.toUiItem() }
    }

    private fun RatioFakerSession.toUiItem(): TorrentUiItem {
        val clientType = ClientType.fromId(settings.selectedClient)
        val os = OperatingSystem.fromId(settings.operatingSystem)
        val ver = settings.selectedClientVersion.ifBlank { clientType.defaultVersion }
        return TorrentUiItem(
            id = instanceId,
            name = torrent.name,
            infoHashHex = torrent.infoHashHex,
            trackerHost = torrent.trackerHost(),
            primaryTrackerUrl = torrent.announce,
            totalSize = torrent.totalSize,
            fileCount = torrent.fileCount,
            presetId = presetId,
            presetName = presetName,
            settings = settings,
            clientDisplayName = clientType.displayName,
            clientVersion = ver,
            operatingSystem = os,
            port = settings.port,
            stats = stats
        )
    }
}
