package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "torrents")
data class TorrentEntity(
    @PrimaryKey val id: String,
    val infoHashHex: String,
    val name: String,
    val totalSize: Long,
    val rawTorrentBytes: ByteArray,
    val presetId: String,
    val presetName: String,
    val settingsJson: String,
    val cumulativeUploadedBytes: Long,
    val cumulativeDownloadedBytes: Long,
    val addedAtMs: Long
)

@Entity(tableName = "custom_presets")
data class CustomPresetEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val icon: String,
    val createdAt: String,
    val settingsJson: String,
    val updatedAtMs: Long
)

@Entity(tableName = "app_preferences")
data class AppPreferenceEntity(
    @PrimaryKey val prefKey: String,
    val prefValue: String
)

@Dao
interface RustatioDao {
    @Query("SELECT * FROM torrents ORDER BY addedAtMs DESC")
    fun observeTorrents(): Flow<List<TorrentEntity>>

    @Query("SELECT * FROM torrents ORDER BY addedAtMs DESC")
    suspend fun getAllTorrentsOnce(): List<TorrentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTorrent(entity: TorrentEntity)

    @Query(
        "UPDATE torrents SET cumulativeUploadedBytes = :uploaded, cumulativeDownloadedBytes = :downloaded WHERE id = :id"
    )
    suspend fun updateTorrentTraffic(id: String, uploaded: Long, downloaded: Long)

    @Query(
        "UPDATE torrents SET presetId = :presetId, presetName = :presetName, settingsJson = :settingsJson WHERE id = :id"
    )
    suspend fun updateTorrentSettings(id: String, presetId: String, presetName: String, settingsJson: String)

    @Query("DELETE FROM torrents WHERE id = :id")
    suspend fun deleteTorrentById(id: String)

    @Query("SELECT * FROM custom_presets ORDER BY updatedAtMs DESC")
    fun observeCustomPresets(): Flow<List<CustomPresetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCustomPreset(entity: CustomPresetEntity)

    @Query("DELETE FROM custom_presets WHERE id = :id")
    suspend fun deleteCustomPresetById(id: String)

    @Query("SELECT prefValue FROM app_preferences WHERE prefKey = :key LIMIT 1")
    fun observePreference(key: String): Flow<String?>

    @Query("SELECT prefValue FROM app_preferences WHERE prefKey = :key LIMIT 1")
    suspend fun getPreferenceOnce(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setPreference(pref: AppPreferenceEntity)

    @Query("DELETE FROM app_preferences WHERE prefKey = :key")
    suspend fun deletePreference(key: String)
}

@Database(
    entities = [
        TorrentEntity::class,
        CustomPresetEntity::class,
        AppPreferenceEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun rustatioDao(): RustatioDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "rustatio_android.db"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
