package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.core.faker.FakerState
import com.example.core.util.FormatUtils
import com.example.data.repository.RustatioRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class TrackerForegroundService : Service() {

    companion object {
        private const val CHANNEL_ID = "rustatio_tracker_channel"
        private const val NOTIFICATION_ID = 2141
        const val ACTION_START = "com.example.service.ACTION_START"
        const val ACTION_PAUSE_ALL = "com.example.service.ACTION_PAUSE_ALL"
        const val ACTION_STOP_ALL = "com.example.service.ACTION_STOP_ALL"

        fun ensureRunning(context: Context) {
            val intent = Intent(context.applicationContext, TrackerForegroundService::class.java).apply {
                action = ACTION_START
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.applicationContext.startForegroundService(intent)
                } else {
                    context.applicationContext.startService(intent)
                }
            } catch (_: Exception) {
            }
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var monitorJob: Job? = null
    private lateinit var repository: RustatioRepository

    override fun onCreate() {
        super.onCreate()
        repository = RustatioRepository.getInstance(applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PAUSE_ALL -> {
                serviceScope.launch {
                    repository.pauseAllTorrents()
                    updateNotification()
                }
            }
            ACTION_STOP_ALL -> {
                serviceScope.launch {
                    repository.stopAllTorrents()
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
                return START_NOT_STICKY
            }
        }

        startForegroundCompat(buildNotification())
        startMonitorIfNeeded()
        return START_STICKY
    }

    private fun startForegroundCompat(notification: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (_: Exception) {
        }
    }

    private fun startMonitorIfNeeded() {
        if (monitorJob?.isActive == true) return
        monitorJob = serviceScope.launch {
            var idleChecks = 0
            while (isActive) {
                updateNotification()
                val items = repository.torrentsState.value
                val hasActiveOrPaused = items.any {
                    it.stats.state == FakerState.RUNNING ||
                        it.stats.state == FakerState.STARTING ||
                        it.stats.state == FakerState.PAUSED
                }
                if (hasActiveOrPaused) {
                    idleChecks = 0
                } else {
                    idleChecks++
                    // Chờ ít nhất 6 giây không có bất kỳ phiên STARTING/RUNNING/PAUSED nào mới đóng dịch vụ nền
                    if (idleChecks >= 6) {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                        break
                    }
                }
                delay(1000L)
            }
        }
    }

    private fun updateNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        nm.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val items = repository.torrentsState.value
        val runningCount = items.count { it.stats.state == FakerState.RUNNING || it.stats.state == FakerState.STARTING }
        val pausedCount = items.count { it.stats.state == FakerState.PAUSED }
        val totalUpRate = items.sumOf { it.stats.currentUploadRateKBs }
        val totalDownRate = items.sumOf { it.stats.currentDownloadRateKBs }
        val totalUploaded = items.sumOf { it.stats.uploadedBytes }

        val title = when {
            runningCount > 0 -> "Rustatio · Đang chạy $runningCount torrent"
            pausedCount > 0 -> "Rustatio · Tạm dừng $pausedCount torrent"
            else -> "Rustatio · Đang đồng bộ Tracker"
        }

        val content = "↑ ${FormatUtils.formatSpeedKBs(totalUpRate)} · ↓ ${FormatUtils.formatSpeedKBs(totalDownRate)} · Đã tải lên: ${FormatUtils.formatBytes(totalUploaded)}"

        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val pauseIntent = Intent(this, TrackerForegroundService::class.java).apply {
            action = ACTION_PAUSE_ALL
        }
        val pausePending = PendingIntent.getService(
            this,
            1,
            pauseIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, TrackerForegroundService::class.java).apply {
            action = ACTION_STOP_ALL
        }
        val stopPending = PendingIntent.getService(
            this,
            2,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(content)
            .setContentIntent(openPending)
            .setOngoing(runningCount > 0)
            .setOnlyAlertOnce(true)
            .addAction(0, "Tạm dừng", pausePending)
            .addAction(0, "Dừng tất cả", stopPending)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        monitorJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
