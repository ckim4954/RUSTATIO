package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.presets.BuiltInPresets
import com.example.core.presets.Preset
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Rustatio", appName)
    }

    @Test
    fun `preset json export and import roundtrip preserves settings`() {
        val original = BuiltInPresets.all.first().copy(
            id = "custom-test",
            name = "Preset Thử Nghiệm",
            custom = true
        )
        val exported = original.toExportJsonString()
        val importedList = Preset.parseImportedJson(exported)
        assertEquals(1, importedList.size)
        assertEquals("Preset Thử Nghiệm", importedList.first().name)
        assertEquals(original.settings.uploadRate, importedList.first().settings.uploadRate, 0.01)
    }
}
