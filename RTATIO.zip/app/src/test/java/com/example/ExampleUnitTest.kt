package com.example

import com.example.core.presets.BuiltInPresets
import com.example.core.protocol.AnnounceRequest
import com.example.core.protocol.Bencode
import com.example.core.protocol.TrackerClient
import com.example.core.protocol.TrackerEvent
import com.example.core.torrent.ClientConfig
import com.example.core.torrent.ClientType
import com.example.core.torrent.OperatingSystem
import com.example.core.torrent.TorrentInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.charset.StandardCharsets

class ExampleUnitTest {

    @Test
    fun builtInPresets_excludesPartialDownload_andHasFourPresets() {
        val ids = BuiltInPresets.all.map { it.id }
        assertEquals(4, ids.size)
        assertFalse(ids.contains("partial"))
        assertTrue(ids.containsAll(listOf("balanced", "fast", "seedbox", "stealth")))
    }

    @Test
    fun clientAndOperatingSystem_keepsExactPcUserAgent_andSetsOsHeader() {
        val win7 = ClientConfig.create(ClientType.QBITTORRENT, "5.3.0", OperatingSystem.WINDOWS_7)
        val win10 = ClientConfig.create(ClientType.UTORRENT, "3.5.5", OperatingSystem.WINDOWS_10)
        val win12 = ClientConfig.create(ClientType.TRANSMISSION, "4.1.4", OperatingSystem.WINDOWS_12)

        assertEquals(20, win7.generatePeerId().length)
        assertTrue(win7.generatePeerId().startsWith("-qB5300-"))
        assertEquals("qBittorrent/5.3.0", win7.userAgent)
        assertTrue(win7.osHeaderValue.contains("Windows NT 6.1"))

        assertEquals(20, win10.generatePeerId().length)
        assertTrue(win10.generatePeerId().startsWith("-UT3550-"))
        assertEquals("uTorrent/3.5.5", win10.userAgent)
        assertTrue(win10.osHeaderValue.contains("Windows NT 10.0"))

        assertEquals(20, win12.generatePeerId().length)
        assertTrue(win12.generatePeerId().startsWith("-TR4100-"))
        assertEquals("Transmission/4.1.4", win12.userAgent)
        assertTrue(win12.osHeaderValue.contains("Windows NT 12.0"))
    }

    @Test
    fun trackerUrlBuilder_matchesRustatioCoreWireFormat() {
        val clientCfg = ClientConfig.create(ClientType.QBITTORRENT, "5.3.0", OperatingSystem.WINDOWS_10)
        val peerId = clientCfg.generatePeerId()
        val trackerClient = TrackerClient()
        val req = AnnounceRequest(
            infoHash = ByteArray(20) { it.toByte() },
            peerId = peerId,
            port = 6881,
            uploaded = 0L,
            downloaded = 0L,
            left = 0L,
            compact = true,
            noPeerId = false,
            event = TrackerEvent.STARTED,
            numWant = 200,
            key = "A1B2C3D4"
        )
        val url = trackerClient.buildAnnounceUrl("https://tracker.example.com/announce?passkey=xyz", req, clientCfg)
        assertTrue(url.contains("&info_hash=%00%01%02"))
        assertTrue(url.contains("&peer_id=$peerId"))
        assertTrue(url.contains("&event=started"))
        assertTrue(url.contains("&supportcrypto=1"))
    }

    @Test
    fun torrentParser_extractsValidSha1InfoHashAndAnnounce() {
        val sampleBencode = "d8:announce35:https://tracker.ubuntu.com/announce4:infod6:lengthi1048576e4:name14:ubuntu-iso.iso12:piece lengthi262144e6:pieces20:01234567890123456789ee"
            .toByteArray(StandardCharsets.ISO_8859_1)

        val info = TorrentInfo.fromBytes(sampleBencode)
        assertEquals("ubuntu-iso.iso", info.name)
        assertEquals("https://tracker.ubuntu.com/announce", info.announce)
        assertEquals(1048576L, info.totalSize)
        assertEquals(20, info.infoHash.size)
        assertEquals(40, info.infoHashHex.length)
        val rawInfo = Bencode.extractInfoBytes(sampleBencode)
        assertTrue(String(rawInfo, StandardCharsets.ISO_8859_1).startsWith("d6:length"))
    }
}
